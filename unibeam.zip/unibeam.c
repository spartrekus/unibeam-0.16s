

////////////////////////////////
// 
// Convert mrk to tex, and more. 
//
////////////////////////////////

#include <stdio.h>
#if defined(__linux__)
#define MYOS 1
#elif defined(_WIN32)
#define MYOS 2
#elif defined(_WIN64)
#define MYOS 3
#elif defined(__unix__)
#define MYOS 4
#define PATH_MAX 2500
#else
#define MYOS 0
#endif
#include <string.h>
#include <stdlib.h>

#include <dirent.h>
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
#include <unistd.h> 

#include <time.h>


#define VERSIONNBR "0.16s" 


char strlabel[PATH_MAX];
char cursubsection[PATH_MAX];
char lastsubsection[PATH_MAX];
int  pagemark_open = 0;
int  pagemark_mode_active = 1;
int  varset_colors = 1;


/////////////////////////////////////////////////////////
int table_col_nbr     = 0; 
int table_col_nbr_max = 0; 
char doc_version[PATH_MAX];
char slidebufferdata[200][PATH_MAX];
char slidebufferfigfile[PATH_MAX];
char slidebufferfigfile1[PATH_MAX];
char slidebufferfigfile2[PATH_MAX];
char slidebufferfignote[PATH_MAX];
int  slidebufferfig=0;
int  slidebuffernot=0;
int  foxy = 0;
int  mynumber = 1;



int fp_content_eod = 0;  // let to add some embedded endnotes (references) with !fbegin !fend
int fp_content_eof = 0;  // end of file, for more comments

int  slidebufferfoundsection = 0;
char slidemysection[PATH_MAX];
char mygraphicspath[PATH_MAX];
char myinputspath[PATH_MAX];

// for questions, to make active
int list_numbering = 1;
int question_qucounter = 1; 
int question_setpts = 1;


// for !an for answer
int answer_show = 0;  


int markup_output_format = 1; 
int markup_language = 1; // 1:english (standard, international), 2:french, 3:german, 4:en+ english i.e. en+ (for exam, e.g. 3 points)
// with !set lang=en
int markup_item = 1;    //  1:default , 2:3pkt,  //for rapid update
int txtbeginreview = 0; 
int txtrawcode = 0; 
int beamercode = 0; 
int bookcode = 0; 
int notercode  = 0; 
int contentcode = 0; 
int option_system_call = 0;           // this will be 0 by default (depreciated)
int option_strtxt2tex_linefeed = 1;   // this shall be 0 by default for compact documents




/////////////////////////////////
/////////////////////////////////
/////////////////////////////////
int fexist(char *a_option)
{
  char dir1[PATH_MAX]; 
  char *dir2;
  DIR *dip;
  strncpy( dir1 , "",  PATH_MAX  );
  strncpy( dir1 , a_option,  PATH_MAX  );

  struct stat st_buf; 
  int status; 
  int fileordir = 0 ; 

  status = stat ( dir1 , &st_buf);
  if (status != 0) {
    fileordir = 0;
  }

  // this is compatible to check if a file exists
  FILE *fp2check = fopen( dir1  ,"r");
  if( fp2check ) {
  // exists
  fileordir = 1; 
  fclose(fp2check);
  } 

  if (S_ISDIR (st_buf.st_mode)) {
    fileordir = 2; 
  }
return fileordir;
/////////////////////////////
}







//////////////////
//////////////////
//////////////////
void ncp( char *filetarget,  char *  filesource )
{
  // fread
  char            buffer[1];
  size_t          n;
  size_t          m;
  FILE *fp;
  FILE *fp1; 
  FILE *fp2;
  int counter = 0 ; 
  int freader = 1 ; 
  int i , j ,posy, posx ; 
  if ( fexist( filesource ) == 1 )
  {
        fp = fopen( filesource, "rb");
        fp2 = fopen( filetarget, "wb");
        counter = 0; 
        while(  !feof(fp) && ( freader == 1)   ) {
           if (  feof(fp)   ) {
                freader = 0 ; 
            }
            n = fread(  buffer, sizeof(char), 1 , fp);
            m = fwrite( buffer, sizeof(char), 1,  fp2);
        }
        fclose(fp2);
        fclose(fp);
      }
}










/////////////////////////////////
/////////////////////////////////
/////////////////////////////////
char *strampersand2txt(char *str)
{  
      char ptr[ 5* strlen(str)+1];
      int i,j=0;
      for(i=0; str[i]!='\0'; i++)
      {
        if ( str[i] == '&' ) 
	{
          ptr[j++]=':';
	}
        else
	{
          ptr[j++]=str[i];
	}
      } 
      ptr[j]='\0';
      size_t siz = 1 + sizeof ptr ; 
      char *r = malloc( 1 +  sizeof ptr );
      return r ? memcpy(r, ptr, siz ) : NULL;
}






/////////////////////////////////
/////////////////////////////////
/////////////////////////////////
char *strtxt2tex(char *str)
{  
      char ptr[ 5* strlen(str)+1];
      int i,j=0;
      for(i=0; str[i]!='\0'; i++)
      {

        if ( str[i] == '{' ) 
	{
          ptr[j++]='\\';
          ptr[j++]='{';
	}

        else if ( str[i] == '^' ) 
	{
          ptr[j++]='\\';
          ptr[j++]='^';
	}

        else if ( str[i] == '%' ) 
	{
          ptr[j++]='\\';
          ptr[j++]='%';
	}

        else if ( str[i] == '>' ) 
	{
          ptr[j++]='\\';
          ptr[j++]='e';
          ptr[j++]='n';
          ptr[j++]='s';
          ptr[j++]='u';
          ptr[j++]='r';
          ptr[j++]='e';
          ptr[j++]='m';
          ptr[j++]='a';
          ptr[j++]='t';
          ptr[j++]='h';
          ptr[j++]='{';
          ptr[j++]='>';
          ptr[j++]='}';
          //ptr[j++]=' ';
	}

        else if ( str[i] == '<' ) 
	{
          ptr[j++]='\\';
          ptr[j++]='e';
          ptr[j++]='n';
          ptr[j++]='s';
          ptr[j++]='u';
          ptr[j++]='r';
          ptr[j++]='e';
          ptr[j++]='m';
          ptr[j++]='a';
          ptr[j++]='t';
          ptr[j++]='h';
          ptr[j++]='{';
          ptr[j++]='<';
          ptr[j++]='}';
          //ptr[j++]=' ';
	}


        else if ( str[i] == '}' ) 
	{
          ptr[j++]='\\';
          ptr[j++]='}';
	}
        else if ( str[i] == '_' ) 
	{
          ptr[j++]='\\';
          ptr[j++]='_';
	}
        else if ( str[i] == '%' ) 
	{
          ptr[j++]='\\';
          ptr[j++]='%';
	}
        else if ( str[i] == '#' ) 
	{
          ptr[j++]='\\';
          ptr[j++]='#';
	}

        else if ( str[i] == '&' ) 
	{
          ptr[j++]='\\';
          ptr[j++]='&';
	}

        else if ( str[i] == '%' ) 
	{
          ptr[j++]='\\';
          ptr[j++]='%';
	}

        else
	{
          ptr[j++]=str[i];
	}
      } 
      ptr[j]='\0';
      size_t siz = 1 + sizeof ptr ; 
      char *r = malloc( 1 +  sizeof ptr );
      return r ? memcpy(r, ptr, siz ) : NULL;
}






/////////////////////////////////
/////////////////////////////////
/////////////////////////////////
char *strtext2tex(char *str)
{  
      char ptr[ 5* strlen(str)+1];
      int i,j=0;
      for(i=0; str[i]!='\0'; i++)
      {
        if ( str[i] == '&' ) 
	{
          ptr[j++]='\\';
          ptr[j++]='&';
	}
        else if ( str[i] == 9 ) 
	{
          ptr[j++]=';';
          ptr[j++]=' ';
	}
        else if ( str[i] == '_' ) 
	{
          ptr[j++]='\\';
          ptr[j++]='_';
	}
        else if ( str[i] == '%' ) 
	{
          ptr[j++]='\\';
          ptr[j++]='%';
	}
        else
	{
          ptr[j++]=str[i];
	}
      } 
      ptr[j]='\0';
      size_t siz = 1 + sizeof ptr ; 
      char *r = malloc( 1 +  sizeof ptr );
      return r ? memcpy(r, ptr, siz ) : NULL;
}








/////////////////////////////////
/////////////////////////////////
/////////////////////////////////
char *strcsv2tex(char *str)
{  
      char ptr[ 5* strlen(str)+1];
      int i,j=0;

      for(i=0; str[i]!='\0'; i++)
      {
        if ( str[i] == ';' ) 
	{
          ptr[j++]=' ';
          ptr[j++]='&';
          ptr[j++]=' ';
	}

        else if ( str[i] == '|' ) 
	{
          if ( table_col_nbr < table_col_nbr_max-1 ) 
          {
            ptr[j++]=' ';
            ptr[j++]='&';
            ptr[j++]=' ';
            table_col_nbr++;
          }
	}

        else if ( str[i] == 9 ) 
	{
          ptr[j++]=' ';
          ptr[j++]='&';
          ptr[j++]=' ';
	}

        else
	{
          ptr[j++]=str[i];
	}
      } 
      ptr[j]='\0';
      size_t siz = 1 + sizeof ptr ; 
      char *r = malloc( 1 +  sizeof ptr );
      return r ? memcpy(r, ptr, siz ) : NULL;
}












char *fbasewithoutfilename(char* mystr)
{
    char *retstr;
    char *lastdot;
    if (mystr == NULL)
         return NULL;
    if ((retstr = malloc (strlen (mystr) + 1)) == NULL)
        return NULL;
    strcpy (retstr, mystr);
    lastdot = strrchr (retstr, '/');
    if (lastdot != NULL)
        *lastdot = '\0';
    return retstr;
}





char *fbasenoext(char* mystr)
{
    char *retstr;
    char *lastdot;
    if (mystr == NULL)
         return NULL;
    if ((retstr = malloc (strlen (mystr) + 1)) == NULL)
        return NULL;
    strcpy (retstr, mystr);
    lastdot = strrchr (retstr, '.');
    if (lastdot != NULL)
        *lastdot = '\0';
    return retstr;
}








////////////////////////////
////////////////////////////
////////////////////////////
////////////////////////////
////////////////////////////
///// some cat!! 
#include <fcntl.h>
#include <unistd.h>
static int cat_fd(int fd) 
{
  char buf[4096];
  ssize_t nread;

  while ((nread = read(fd, buf, sizeof buf)) > 0) 
  {
    ssize_t ntotalwritten = 0;
    while (ntotalwritten < nread) {
      ssize_t nwritten = write(STDOUT_FILENO, buf + ntotalwritten, nread - ntotalwritten);
      if (nwritten < 1)
        return -1;
      ntotalwritten += nwritten;
    }
  }
  return nread == 0 ? 0 : -1;
}
/////////////////
static int ncat_static(const char *fname) 
{
  int fd, success;
  if ((fd = open(fname, O_RDONLY)) == -1)
    return -1;

  success = cat_fd(fd);

  if (close(fd) != 0)
    return -1;

  return success;
}
////////////////////////////
////////////////////////////
////////////////////////////
////////////////////////////
////////////////////////////














int strcount( char *str , int mychar )
{  
      int return_strcount = 0;
      char ptr[strlen(str)+1];
      int i,j = 0;
      for(i=0; str[i]!='\0'; i++)
      {
        if ( str[i] == mychar ) return_strcount++;
      } 
      return return_strcount;
}






void nrunwith( char *thecmd , char *thefile )
{
       char cmdi[PATH_MAX];
       printf( "<CMD: %s>\n" , thecmd ) ; 
       printf( "<FILE: %s>\n" , thefile ) ; 
       strncpy( cmdi , "  " , PATH_MAX );
       strncat( cmdi , thecmd , PATH_MAX - strlen( cmdi ) -1 );
       strncat( cmdi , " \"" , PATH_MAX - strlen( cmdi ) -1 );
       strncat( cmdi , thefile , PATH_MAX - strlen( cmdi ) -1 );
       strncat( cmdi , "\"" , PATH_MAX - strlen( cmdi ) -1 );
       system( cmdi );
}







char *strcut( char *str , int myposstart, int myposend )
{  
      char ptr[strlen(str)+1];
      int i,j=0;
      for(i=0; str[i]!='\0'; i++)
      {
        if ( ( str[i] != '\0' ) && ( str[i] != '\0') )
         if ( ( i >=  myposstart-1 ) && (  i <= myposend-1 ) )
           ptr[j++]=str[i];
      } 
      ptr[j]='\0';
      size_t siz = sizeof ptr ; 
      char *r = malloc( sizeof ptr );
      return r ? memcpy(r, ptr, siz ) : NULL;
}






char *strtrim(char *str)
{  
      // right side to to finish
      char ptr[strlen(str)+1];
      int strposmax = strlen( str );
      int lastposchar = strposmax;
      int i,j=0;
      int foundspace = 1;

      /// find last char
      foundspace = 1;
      for( i= strposmax-1 ; i >= 0 ; i--)
      {
         //printf( "|%d-%d-%c| ", i , lastposchar , str[i] );
	 // find where to space
         if ( foundspace == 1 ) 
         if ( str[i] == ' ' ) 
   	    lastposchar = i-1;

         if ( str[i] != ' ' ) 
           foundspace = 0;
      } 

      // add the content
      foundspace = 1;
      for(i=0; i <= lastposchar ; i++)
      {
        if ( foundspace == 1 ) 
         if ( ( str[i] != ' ' )  && ( str[i] != 9 ) ) //added! with 9 for a TAB!!
          foundspace = 0;

        if ( foundspace == 0 ) 
           ptr[j++]=str[i];
      } 
      ptr[j]='\0';

      size_t siz = sizeof ptr ; 
      char *r = malloc( sizeof ptr );
      return r ? memcpy(r, ptr, siz ) : NULL;
}







/////////////////////////////////////
void fileappendbegin( char *fileout)
{
    FILE *fp5;
    fp5 = fopen( fileout , "ab+");
      fputs( "\\documentclass{article}\n", fp5 );
      fputs( "\\begin{document}\n", fp5 );
    fclose( fp5 );
}
/////////////////////////////////////
void fileappendend( char *fileout)
{
    FILE *fp5;
    fp5 = fopen( fileout , "ab+");
      fputs( "\\end{document}\n", fp5 );
    fclose( fp5 );
}




/////////////////////////////////////
void filenew_begin( char *fileout)
{
    FILE *fp5;
    fp5 = fopen( fileout , "wb+");
    fputs( "\n", fp5 );
    fputs( "\\documentclass[11pt]{article}\n", fp5 );
    fputs( "\\usepackage{grffile}\n" , fp5 );
    fputs( "\\usepackage{graphicx}\n" , fp5 );
    fputs( "\\usepackage{xcolor}\n" , fp5 );
    fputs( "\\usepackage[utf8]{inputenc}\n", fp5 );
    fputs( "\\begin{document}\n" , fp5 );
    fputs( "\n" , fp5 );
    fputs( "\n", fp5 );
    fclose( fp5 );
}



/////////////////////////////////////
void filenew( char *fileout)
{
    FILE *fp5;
    fp5 = fopen( fileout , "wb+");
    fclose( fp5 );
}








///////////////////////////////////////////////////////////////////
void filerawcat(  char *fileout, char *filein )
{
  int fetchi;
  FILE *fp5;
  FILE *fp6;
  char fetchline[PATH_MAX];
  char fetchlinetmp[PATH_MAX];

  /////////////////////////////////////////////////
  if ( fexist( filein ) == 1 )
  {
    fp5 = fopen( fileout , "ab+");
    fp6 = fopen( filein , "rb");
    while( !feof(fp6) ) 
    {
          fgets(fetchlinetmp, PATH_MAX, fp6); 
          strncpy( fetchline, "" , PATH_MAX );
          for( fetchi = 0 ; ( fetchi <= strlen( fetchlinetmp ) ); fetchi++ )
            if ( fetchlinetmp[ fetchi ] != '\n' )
              fetchline[fetchi]=fetchlinetmp[fetchi];

         if ( !feof(fp6) )
         {
 	      fputs( fetchline , fp5 );
  	      fputs( "\n", fp5 );
	 }
     }
     fclose( fp5 );
     fclose( fp6 );
   }
}







/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
int strcharcount( char *str )
{  
      int rstrcharcount = 0;
      int i,j=0;
      for(i=0; str[i]!='\0'; i++)
         rstrcharcount++;
      return rstrcharcount;
}




/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
char *strrlf(char *str)
{  
      char ptr[strlen(str)+1];
      int i,j=0;
      for(i=0; str[i]!='\0'; i++)
      {
        if (str[i] != '\n' && str[i] != '\n') 
        ptr[j++]=str[i];
      } 
      ptr[j]='\0';
      size_t siz = sizeof ptr ; 
      char *r = malloc( sizeof ptr );
      return r ? memcpy(r, ptr, siz ) : NULL;
}







/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
char *strsplit(char *str , int mychar , int myitemfoo )
{  
      char ptr[strlen(str)+1];
      int myitem = myitemfoo +1;
      int i,j=0;
      int fooitem = 0;
      for(i=0; str[i]!='\0'; i++)
      {
        if ( str[i] == mychar ) 
           fooitem++;
        else if ( str[i] != mychar &&  fooitem == myitem-2  ) 
           ptr[j++]=str[i];
      } 
      ptr[j]='\0';
      size_t siz = sizeof ptr ; 
      char *r = malloc( sizeof ptr );
      return r ? memcpy(r, ptr, siz ) : NULL;
}

/// customed one
char *strdelimit(char *str , int mychar1, int mychar2,  int mycol )
{ 
      char ptr[strlen(str)+1];
      char ptq[strlen(str)+1];
      strncpy( ptr, strsplit( str, mychar1 , mycol+1 ), strlen(str)+1 );
      strncpy( ptq, strsplit( ptr, mychar2 , 1 ), strlen(str)+1 );
      size_t siz = sizeof ptq ; 
      char *r = malloc( sizeof ptq );
      return r ? memcpy(r, ptq, siz ) : NULL;
}










char *fbasename(char *name)
{
  char *base = name;
  while (*name)
    {
      if (*name++ == '/')
	{
	  base = name;
	}
    }
  return (base);
}
















//////////////////////////////////////////////
//////////////////////////////////////////////
//////////////////////////////////////////////
char *cat_returnline( char *thefilefoo, int theline  )
{
  char catfetchlinetmp[PATH_MAX];
  char catfetchline[PATH_MAX];
  char buf[PATH_MAX];
  char ptr[PATH_MAX];
  ssize_t nread;
  int i,j,k;
  double linenbr = 0;
  i = 0; 
  j = 0;
  int beginend = 0;
    FILE *fp9;
    fp9 = fopen( thefilefoo , "rb");
    while( !feof(fp9) ) 
    {
          strncpy( catfetchline, "" , PATH_MAX );
          fgets(catfetchlinetmp, PATH_MAX, fp9); 
          linenbr++;
          for( i = 0 ; ( i <= strlen( catfetchlinetmp ) ); i++ )
            if ( catfetchlinetmp[ i ] != '\n' )
              catfetchline[i]=catfetchlinetmp[i];

         if ( !feof(fp9) )
         {
              if ( linenbr == theline ) 
                 strncpy( ptr, catfetchline, PATH_MAX );
	 }
     }
     fclose( fp9 );

     size_t siz = 1 + sizeof ptr ; 
     char *r = malloc( 1 +  sizeof ptr );
     return r ? memcpy(r, ptr, siz ) : NULL;
}











//////////////////////////
/// depreciated - will be replaced!!
//////////////////////////
char *filename_newext( char *str , char *newext )
{
      char ptr[strlen(str)+1];
      int i,j=0;
      int foundpoint = 0; 
      for(i=strlen(str)-1 ; i!=-1 ; i--)
      {
          if ( str[i] == '.' ) foundpoint = i; 
      } 

     if ( foundpoint >= 1 ){
      int maxsize = strlen(str)+1+strlen(newext) ;
      char ptrnew[ maxsize ];
      strncpy( ptrnew, strcut( str, 1, foundpoint+1 ),  maxsize  ); 

      ptrnew[ foundpoint ] = '.';
      for(i=0 ; i<= strlen( newext)-1 ; i++)
         ptrnew[ foundpoint+1 +i ] = newext[ i ];
      ptrnew[ foundpoint +i+1] = '\0';

       size_t siz = sizeof ptrnew ; 
       char *r = malloc( sizeof ptrnew );
       return r ? memcpy(r, ptrnew, siz ) : NULL;
    } else return ""; 
}








///////////////////////////////////////////////////////////////////
////////// 
void nfileunimark( char *fileout, char *filein )
{
  char poolfilename[PATH_MAX];

  int fetchi;
  FILE *fp5;
  FILE *fp6;
  char fetchline[PATH_MAX];
  char fetchlinefoo[PATH_MAX];
  char fetchlinetmp[PATH_MAX];
  char fetchcmdline[PATH_MAX];
  int fetchcmdlinelen = 0;

  char charin[PATH_MAX];
  char charout[PATH_MAX];
  char lineout[PATH_MAX];

  char mkdirdir[PATH_MAX];
  char ndirfig[PATH_MAX];
  char usertextfieldone[PATH_MAX];
  char usertextfieleps[PATH_MAX];
  char usertextfieldtwo[PATH_MAX];
  char wgetcmd[PATH_MAX];
  char extcmd[PATH_MAX];
  int  fooc; 
  char fooccharo[PATH_MAX];

  int foundcode = 0; 
  int advancedcode = 1; 
  int commenton = 0; 
  int beginitemize = 0; 

  int itemlevel = 0; 

  /// im and bull
  int itemimlevel = 0;

  int beamerlevel = 0; 
  int numberinglevel = 0; 
  int unilistemptyline = 0; 
  int fooi; 
  //int fetchcmdpos=0;
  int foundcmd = 0;

  char foostr[PATH_MAX];
  int  foodo = 0;

  char mycurrenttag[PATH_MAX];
  strncpy( mycurrenttag, "", PATH_MAX );

  FILE *fpend;  // MAIN
  int export_skip = 0 ;
  int area_endnote = 0 ;

  /////////////////////////////////////////////////
  if ( fexist( filein ) == 1 )
  {
    fp5 = fopen( fileout , "ab");
    fp6 = fopen( filein , "rb");
    while( !feof(fp6) ) 
    {
          // vars
	  foundcode = 0; 
	  foundcmd = 0; 

	  // this fgets is there to be easy to port to any systems
	  // fgets can be easily ported to things such as PHP !!

          fgets( fetchlinetmp, PATH_MAX, fp6); 
          strncpy( fetchline , "" , PATH_MAX );
          strncpy( fetchcmdline , "" , PATH_MAX );
	  export_skip = 0;



          if ( fp_content_eof == 1 )
             foundcode = 1;


          //////////////////////////////////////
          if ( foundcode == 0 ) // low-level low level
          if ( fetchlinetmp[0] == '/' )
          if ( fetchlinetmp[1] == '/' )
          {
  	      foundcode = 1;
          }

          //////////////////////////////////
          //////////////////////////////////
          /// low-level comments
          //////////////////////////////////
          //////////////////////////////////
          if ( foundcode == 0 ) // low-level
          if ( fetchlinetmp[0] == '/' )
          if ( fetchlinetmp[1] == '/' )
          {
  	      foundcode = 1;
          }








	    /////////////////
            if ( foundcode == 0 ) // 
            if ( fetchline[0] == '#' ) // low-level
            //if ( fetchline[1] == ' ' ) // low-level
            if ( fetchline[1] != 'i' ) // different!!!
            if ( fetchline[2] != 'n' )
            if ( fetchline[3] != 'c' )
            if ( fetchline[4] != 'l' )
            if ( fetchline[5] != 'u' )
            if ( fetchline[6] != 'd' )
            if ( fetchline[7] != 'e' )
            {  
              /*
 	      fputs( "{\\color{blue}" , fp5 );
 	      fputs( strcut( fetchlinetmp, 0+2, strlen(fetchlinetmp)) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 ); */
              //datecom-20180202-002359, color was changed from red to blue
       	      //fputs( "\\textcolor{blue}{\\hl{" , fp5 );
       	      fputs( "\\textcolor{blue}{" , fp5 );
              fputs( "[", fp5 );
       	      //fputs( strcut( fetchline, 0+2, strlen( fetchline )) , fp5 );
              if ( txtrawcode == 1 )
       	         fputs(  strtxt2tex(strcut( fetchline, 0+2, strlen(fetchline))) , fp5 );
              else
       	         fputs( strcut( fetchline, 0+2, strlen(fetchline)) , fp5 );
              fputs( "]", fp5 );
              //fputs( "}}", fp5 );
              fputs( "}", fp5 );
              fputs( "\n", fp5 );
  	      foundcode = 1;
            } 









          // 20170811-180203
          // remove lf and more
          // there is only two modifiers !
          for( fetchi = 0 ; ( fetchi <= strlen( fetchlinetmp ) ); fetchi++ )
            if ( fetchlinetmp[ fetchi ] != '\n' )
	    {
              fetchline[fetchi]=fetchlinetmp[fetchi];
              if ( fetchlinetmp[ fetchi ] == '!' ) 
	         foundcmd = 1 ;
	    }




            ////////////////
            //if ( fetchcmdline[0] == '!' )
	    //if ( strcmp( fetchcmdline, "!EOF" ) == 0 )
            if ( foundcode == 0 )
            if ( fetchline[ 0 ] == '!' ) 
	    if ( fetchline[ 1 ] == 'E' )  
            if ( fetchline[ 2 ] == 'O' ) 
            if ( fetchline[ 3 ] == 'F' ) 
            {
              fp_content_eof = 1;
	      contentcode = 0;
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }



          ///////////////////////////////////////////////////////////
          ///////////////////////////////////////////////////////////
          ///////////////////////////////////////////////////////////
          ///////////////////////////////////////////////////////////
          ///////////////////////////////////////////////////////////
          /// EMBEDDED ENDNOTE START
          ///////////////////////////////////////////////////////////
	  ///if ( beamercode == 0 )
	  if ( fp_content_eof == 0 )
	  if ( fp_content_eod == 1 )
	  if ( foundcode == 0 )
	  {
           if ( ( fetchline[ 0 ] == '/' )  && ( fetchline[ 1 ] == '*' ) ) 
               commenton = 1;

           if ( ( fetchline[ 0 ] == '*' )  && ( fetchline[ 1 ] == '/' ) ) 
           {    commenton = 0;  export_skip = 1;     }

           if ( commenton ==  0 )
	   if ( export_skip == 0  )
           if ( fetchline[ 0 ] == '!' ) 
	   if ( fetchline[ 1 ] == 'f' )  
           if ( fetchline[ 2 ] == 'e' ) 
           if ( fetchline[ 3 ] == 'n' ) 
           if ( fetchline[ 4 ] == 'd' ) 
	   if ( fetchline[ 5 ] == '{' )  
	   {
               area_endnote = 0;
               printf( ">>>>> %s (found fend)", fetchline );
               printf( "\n" );
               foundcode = 1;
	   }

         ////////////////////////////////////////
         if ( commenton ==  0 )   // !fbegin{endnote}
	 if ( export_skip == 0  )
         if ( fetchline[ 0 ] == '!' ) 
	 if ( fetchline[ 1 ] == 'f' )  
	 if ( fetchline[ 2 ] == 'b' )  
         if ( fetchline[ 3 ] == 'e' ) 
         if ( fetchline[ 4 ] == 'g' ) 
         if ( fetchline[ 5 ] == 'i' ) 
	 if ( fetchline[ 6 ] == 'n' )  
	 if ( fetchline[ 7 ] == '{' )  
         {
	       // for increased security only "endnote.bib" will be created.
               area_endnote = 1;
               export_skip = 1;
               fpend = fopen(  "endnote.bib", "wb+" );
               fclose( fpend );
               printf( ">>>>> Create %s (found fbegin)\n", fetchline );
               foundcode = 1;
         }
         //////////////////////////////////////////////////////////////
         if ( area_endnote == 1 ) 
           printf( ">>>>> Endnote fp%d exp%d aend%d com%d (%s)\n", fp_content_eod, export_skip, area_endnote, commenton, fetchline );

         //////////////////////////////////////////////////////////////
         if ( fp_content_eod == 1 )
         if ( fp_content_eof == 0 )
         {
             if (  ( fetchline[ 0 ] == '/' ) && ( fetchline[ 1 ] == '/' )  )
	        export_skip = 1;

             if ( export_skip == 0 ) 
	     if ( area_endnote == 1 ) 
	     if ( commenton == 0 ) 
	     if ( foundcode == 0 ) 
	     if ( fp_content_eof == 0 ) 
	     if ( fetchline[ 0 ]  != '!' ) 
	     {
               printf( ">>>>> Write %s", fetchline );
               printf( "\n" );
               fpend = fopen(  "endnote.bib", "ab+" );
               fputs( fetchline , fpend );
               fputs( "\n" ,  fpend ); 
               fclose( fpend );
               foundcode = 1;
	     }
	    }
	   }
           // no skip because it will be shown in fin 
           /// EMBEDDED ENDNOTE END






	    /////////////////
            // quick, easy review work with adding just !# 
	    /////////////////
            if ( foundcode == 0 ) // for review
            if ( fetchline[0] == '!' ) // low-level
            if ( fetchline[1] == '#' )
            if ( fetchline[2] == ' ' )
            {
       	         fputs( "\\textcolor{blue}{" , fp5 );
        	 fputs( "[", fp5 );
                 if ( txtrawcode == 1 )
       	            fputs( strtxt2tex(strcut( fetchline, 2+2, strlen(fetchline))) , fp5 );
                 else
       	            fputs( strcut( fetchline, 2+2, strlen(fetchline)) , fp5 );
        	 fputs( "]", fp5 );
        	 fputs( "}", fp5 );
        	 fputs( "\n", fp5 );
  	         foundcode = 1;
            }


         



         /////// txtrawcode, activated with !beginraw
         // you may let this section
          if ( txtrawcode == 1 )
          {
             if ( fetchline[0] != '!' ) 
             if ( fetchline[0] != '>' ) 
             {
                 strncpy( fetchlinefoo, fetchline , PATH_MAX );
                 strncpy( fetchline , strtxt2tex( fetchlinefoo ) , PATH_MAX );
             }
          }

          //// make a cmdline
          strncpy( fetchcmdline, strtrim( fetchline ) , PATH_MAX );
          fetchcmdlinelen = strlen(fetchcmdline);









          if ( !feof(fp6) )
          if ( foundcode == 0 )
          {
            /////////////////////////////////////
            ////  for comment mycomment
	    ////  type 1 like in C language
            //////////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '/' )
            if ( fetchline[1] == '/' )
            {
  	      foundcode = 1;
            }


           ////////////////////////////////////
           if ( strcmp( fetchline, "" ) == 0 )
	        unilistemptyline++;
	      else
	        unilistemptyline = 0;



            //// closer, numbering itemize
            // not beamer here
            if ( foundcode == 0 )
	    if ( contentcode == 1 )
	    if ( numberinglevel >= 1 )
	    if ( unilistemptyline >= 1 )   // let set to one (1) line empty (testing)
            {
	      for ( fooi = 1 ; fooi <= numberinglevel ; fooi++)
	      {
                 if ( markup_output_format == 6 ) 
	           fputs( "\\end{enumerate}\n" , fp5 );
                 else
	           fputs( "\\end{itemize}\n" , fp5 );
	      }
 	      fputs( "\n" , fp5 );
 	      fputs( "\n" , fp5 );
	      numberinglevel = 0;
  	      foundcode = 1;
            }
	    if ( numberinglevel <= 0 ) numberinglevel = 0;






            /////////////////////////////////////////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '#' )   // bou like markdown :( 
            if ( fetchline[1] == ' ' ) 
            {
 	        fputs( "\\section{" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 1+2, strlen( fetchline ))) , fp5 );
  	        fputs( "}\n", fp5 );
  	      foundcode = 1;
            }
            /////////////////////////////////////////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '#' )   // bou like markdown :( 
            if ( fetchline[1] == '#' ) 
            if ( fetchline[2] == ' ' ) 
            {
 	        fputs( "\\subsection{" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 2+2, strlen( fetchline ))) , fp5 );
  	        fputs( "}\n", fp5 );
  	      foundcode = 1;
            }





            //////////////////////////////////
            //////////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '#' )
            if ( strstr( fetchline, "#include" ) == 0 )
            if ( strstr( fetchline, "#input" ) == 0 )
            {
  	      foundcode = 1;
            }




            //////////////////////////////////
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '/' )
            if ( fetchcmdline[1] == '/' )
            {
  	      foundcode = 1;
            }



            /////////////////////////////////////
            /////////////////////////////////////
            //////// COMMENTS !!!!!!!!!!
            /////////////////////////////////////
            /////////////////////////////////////
            if ( foundcode == 0 )
            if (( fetchcmdline[0] == '/' ) && ( fetchcmdline[1] == '*' ))
            {
  	      commenton = 1;
    	      foundcode = 1;
            }
            ////////////////////////////////////
            if ( foundcode == 0 )
            if ( ( fetchcmdline[ fetchcmdlinelen -2 ] == '*' ) && ( fetchcmdline[ fetchcmdlinelen -1 ] == '/' ))
            {
  	      commenton = 0;
    	      foundcode = 1;
            }

            ////////////////////////////////////
            if ( foundcode == 0 )
            if ( ( fetchcmdline[0] == '*' ) && ( fetchcmdline[1] == '/' ))
            {
  	      commenton = 0;
    	      foundcode = 1;
            }
	    //// active if needed
            if ( commenton == 1 )
            {
    	      foundcode = 1;
            }




            /////////////////////////////////////
            if ( foundcode == 0 ) // !lang de
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'l' )
            if ( fetchline[2] == 'a' )
            if ( fetchline[3] == 'n' )
            if ( fetchline[4] == 'g' )
            if ( fetchline[5] == ' ' )
            if ( fetchline[6] == 'd' )
            if ( fetchline[7] == 'e' )
            {
                markup_language = 3;
	        if ( contentcode == 0 ) 
                   fputs( "\\usepackage[figurename=Abb.]{caption}\n" , fp5 );
  	        foundcode = 1;
            }



            /////////
            if ( foundcode == 0 )  // !lang en+
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'l' ) 
            if ( fetchline[2] == 'a' ) 
            if ( fetchline[3] == 'n' ) 
            if ( fetchline[4] == 'g' ) 
            if ( fetchline[5] == ' ' ) 
            if ( fetchline[6] == 'e' ) 
            if ( fetchline[7] == 'n' ) 
            if ( fetchline[8] == '+' ) 
            {
              markup_language = 4; 
  	      foundcode = 1;
            }


            /////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'l' ) 
            if ( fetchline[2] == 'a' ) 
            if ( fetchline[3] == 'n' ) 
            if ( fetchline[4] == 'g' ) 
            if ( fetchline[5] == ' ' ) 
            if ( fetchline[6] == 'e' ) 
            if ( fetchline[7] == 'n' ) 
            {
              markup_language = 1; 
  	      foundcode = 1;
            }






            //////////////////////////////////////////////////////////////////////
            //////////////////////////////////////////////////////////////////////
            //////////////////////////////////////////////////////////////////////
            if ( foundcode == 0 )  // !pdf{ }, note that you may need !packages
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'p' ) 
            if ( fetchline[2] == 'd' ) 
            if ( fetchline[3] == 'f' ) 
            if ( fetchline[4] == '{' ) 
            {
 	      fputs( "\\includepdf{" , fp5 );
              fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }





            /////////////////////////////////
            /////////////////////////////////
            /////////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( markup_output_format == 8 ) 
            // int markup_output_format = 1; // type of doc: 1:tex, 2:html, 3:exam (pts), 4:book, 5:opendoc , 6:exam+ (with points) new and testing,    7: for maths with enumitem,  8: exam list i.e. the first approach, stable (exam in english), 
            // 6 is exam+, but above 8 is exam (regular one)
            // 6 is actually nicer to use.
            if ( fetchline[1] == 'q' ) // used for english type of questions (single question list, with pts)
            if ( fetchline[2] == 'u' )
            if ( fetchline[3] == ' ' )
            {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item[{\\bfseries {" , fp5 );
                fooc = snprintf( fooccharo, 50 , "%d", question_qucounter );
 	        fputs( fooccharo  , fp5 );
 	        fputs( "}}.)]{" , fp5 );
                question_qucounter++;
 	        fputs( strtrim( strcut( fetchline, 3+2, strlen(fetchline))) , fp5 );
                if      ( markup_language == 1 ) fputs( " (3 Points)}" , fp5 );  //the one that is usually being used.
                else if ( markup_language == 2 ) fputs( " (3 Pts.)}" , fp5 );
                else if ( markup_language == 3 ) fputs( " (3 Pkt.)}" , fp5 );
                else if ( markup_language == 0 ) fputs( "}" , fp5 );
 	        fputs( "\n" , fp5 );
 	        fputs( "\\end{itemize}\n" , fp5 );
 	        fputs( "\\vspace{4cm}\n" , fp5 );  // the trick is to have 4cm to give sufficient space for answers.
  	      foundcode = 1;
            }







            /////////////////////////////////////
            /////////////////////////////////////
            if ( foundcode == 0 ) // !answer on
            if ( fetchline[0] == '!' )  //answer
            if ( fetchline[1] == 'a' )
            if ( fetchline[2] == 'n' )
            if ( fetchline[3] == 's' )
            if ( fetchline[4] == 'w' )
            if ( fetchline[5] == 'e' )
            if ( fetchline[6] == 'r' )
            if ( fetchline[7] == ' ' )
            if ( fetchline[8] == 'o' )
            if ( fetchline[9] == 'n' )
            {
                answer_show = 1;
  	        foundcode = 1;
            }
            //// !an for exam, with possible !an answers below.
            //// !mathlist, which is too working with >> 
            if ( foundcode == 0 ) // !an 
            if ( answer_show == 1 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'a' )
            if ( fetchline[2] == 'n' )
            if ( fetchline[3] == ' ' )
            {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strcut( fetchline, 3+2, strlen(fetchline)) , fp5 );
 	        fputs( "\n" , fp5 );
 	        fputs( "\\end{itemize}\n" , fp5 );
  	        foundcode = 1;
            }
            //// !an for exam, with possible !an answers below.
            //// !mathlist, which is too working with >> 
            if ( foundcode == 0 )  // !an
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'a' )
            if ( fetchline[2] == 'n' )
            if ( fetchline[3] == ' ' )
            if ( answer_show == 0 )
            {
  	        foundcode = 1;
            }


            //// !list with !li for mit with for parameters in maths, with - before
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'l' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == ' ' )
            {
 	        fputs( "\\item " , fp5 );
 	        fputs( strcut( fetchline, 3+2, strlen(fetchline)) , fp5 );
 	        fputs( "\n" , fp5 );
  	        foundcode = 1;
            }

            //// !list with !ln for mit with for parameters in maths, without - 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'l' )
            if ( fetchline[2] == 'n' )
            if ( fetchline[3] == ' ' )
            {
 	        fputs( "\\item[] " , fp5 );
 	        fputs( strcut( fetchline, 3+2, strlen(fetchline)) , fp5 );
 	        fputs( "\n" , fp5 );
  	        foundcode = 1;
            }








            //// Math list 
            //// !mathlist, which is too working with >> 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'm' )
            if ( fetchline[2] == 'a' )
            if ( fetchline[3] == 't' )
            if ( fetchline[4] == 'h' )
            if ( fetchline[5] == 'l' )
            if ( fetchline[6] == 'i' )
            if ( fetchline[7] == 's' )
            if ( fetchline[8] == 't' )
            {
              markup_output_format = 7;
  	      foundcode = 1;
            } 
            if ( foundcode == 0 )
            if ( fetchline[0] == '>' )
            if ( fetchline[1] == '>' )
            if ( fetchline[2] == ' ' )
            if ( markup_output_format == 7 ) //!mathlist
            {
	      if ( numberinglevel == 1)  
	      {
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 2+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
		numberinglevel = 1;
                list_numbering++;
	      }
	      else if ( numberinglevel == 0)  
	      {
 	        //fputs( "\\begin{enumerate}[resume]\n" , fp5 );
 	        fputs( "\\begin{enumerate}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 2+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
		numberinglevel = 1;
                list_numbering++;
	      }
  	      foundcode = 1;
            }










            /// !nqu  to be rm
            if ( foundcode == 0 )  
            if ( beamercode == 0 ) 
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'n' )
            if ( fetchline[2] == 'q' )
            if ( fetchline[3] == 'u' )
            if ( fetchline[4] == ' ' )
            {
	      if ( numberinglevel == 2)  
	      {
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
		numberinglevel = 2;
                list_numbering++;
	      }
	      else if ( numberinglevel == 1)  
	      {
 	        fputs( "\\begin{enumerate}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
		numberinglevel = 2;
                list_numbering++;
	      }
  	      foundcode = 1;
            }



            ///////////////////////////////// to be rem
            ///////////////////////////////////////////////
            ///////////////////////////////////////////////
       /*   history
            if ( foundcode == 0 )   // questions, for type !exam+, but !nqu has no points (for custom change) 
            if ( beamercode == 0 ) 
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'n' )
            if ( fetchline[2] == 'q' )
            if ( fetchline[3] == 'u' )
            if ( fetchline[4] == ' ' )
            if ( markup_output_format == 6 ) //for !exam+
            {
	      if ( numberinglevel == 2)  
	      {
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
		numberinglevel = 2;
                list_numbering++;
	      }
	      else if ( numberinglevel == 1)  
	      {
 	        fputs( "\\begin{enumerate}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
		numberinglevel = 2;
                list_numbering++;
	      }
  	      foundcode = 1;
            }
            /////////////////////////////////
   */



            //
            //
            //
            /////////////////////////////////
            /// for exams, especially !exam+ 
            if ( foundcode == 0 )
            if ( beamercode == 0 )
            if ( fetchline[0] == '>' )
            if ( fetchline[1] == '>' )
            if ( fetchline[2] == ' ' )
            if ( markup_output_format == 6 ) //!exam+
            {
	      if ( numberinglevel == 1)  
	      {
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 2+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
		numberinglevel = 1;
                list_numbering++;
	      }
	      else if ( numberinglevel == 0)  
	      {
 	        fputs( "\\begin{enumerate}[resume]\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 2+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
		numberinglevel = 1;
                list_numbering++;
	      }
  	      foundcode = 1;
            }







            /////////////////////////////
            if ( foundcode == 0 )
            if ( beamercode == 0 )
            if ( fetchline[0] == '>' )
            if ( fetchline[1] == '>' )
            if ( fetchline[2] == ' ' )
            {
	      if ( itemlevel == 0)  
	      {
                mynumber = 1;
 	        fputs( "\\begin{itemize}[leftmargin=0cm,label={}]\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 2+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
	        itemlevel = 1;
	      }
  	      foundcode = 1;
             }







            /////////////////////////////////
            /////////////////////////////////
            // Try \begin{figure}[!htb]. In nearly all cases it helps.
            // % trick to easy figures (for beginners)
            // \usepackage[section]{placeins}
            /////////////////////////////////
            if ( foundcode == 0 )   // !placeins 
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'p' )
            if ( fetchline[2] == 'l' )
            if ( fetchline[3] == 'a' )
            if ( fetchline[4] == 'c' )
            if ( fetchline[5] == 'e' )
            if ( fetchline[6] == 'i' )
            if ( fetchline[7] == 'n' )
            if ( fetchline[8] == 's' )
            {
	      if ( contentcode == 0 ) 
              {
 	        fputs( "\n" , fp5 );
 	        fputs( "\\usepackage[section]{placeins}\n" , fp5 ); // new 
 	        fputs( "\n" , fp5 );
              }
  	      foundcode = 1;
            }











            // =================================
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '=' ) 
	    if ( fetchcmdline[1] == '=' ) 
	    if ( fetchcmdline[2] == '=' ) 
	    if ( fetchcmdline[3] == '=' ) 
	    if ( fetchcmdline[4] == '=' ) 
	    if ( fetchcmdline[5] == '=' ) 
	    if ( fetchcmdline[6] == '=' ) 
	    if ( fetchcmdline[7] == '=' ) 
	    if ( fetchcmdline[8] == '=' )
            {
  	      foundcode = 1;
            }





            // !institute text 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'i' )
            if ( fetchline[2] == 'n' )
            if ( fetchline[3] == 's' )
            if ( fetchline[4] == 't' )
            if ( fetchline[5] == 'i' )
            if ( fetchline[6] == 't' )
            if ( fetchline[7] == 'u' )
            if ( fetchline[8] == 't' )
            if ( fetchline[9] == 'e' )
            if ( fetchline[10] == ' ' )
            {
 	      fputs( "\\institute{" , fp5 );
 	      fputs( strcut( fetchline, 10+2, strlen(fetchline)) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }


            /// !inputline{ }
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'i' )
            if ( fetchline[2] == 'n' )
            if ( fetchline[3] == 'p' )
            if ( fetchline[4] == 'u' )
            if ( fetchline[5] == 't' )
            if ( fetchline[6] == 'l' )
            if ( fetchline[7] == 'i' )
            if ( fetchline[8] == 'n' )
            if ( fetchline[9] == 'e' )
            if ( fetchline[10] == '{' )
            {
              char fooreturnchar[PATH_MAX];
              char foofilefound[PATH_MAX];
              strncpy( foofilefound, strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX );
              if ( fexist( foofilefound ) == 1 ) 
              {
                strncpy( fooreturnchar , cat_returnline(  foofilefound , atoi( strdelimit( fetchline,  '{' ,'}' ,  2 )))  , PATH_MAX );
 	        fputs(   fooreturnchar , fp5 );
  	        fputs( "\n", fp5 );
              }
  	      foundcode = 1;
            }



            /// new, easy conv from beamer to mrk 
            // !nullclr      // this is easy to conv !clr to !nullskip, to skip line 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'n' )
            if ( fetchline[2] == 'u' )
            if ( fetchline[3] == 'l' )
            if ( fetchline[4] == 'l' )
            if ( fetchline[5] == 'c' )
            if ( fetchline[6] == 'l' )
            if ( fetchline[7] == 'r' )
            {
  	      foundcode = 1; //just skip
            }

            // !nullskip  // this is easy to conv !bigskip to !nullskip, to skip line 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'n' )
            if ( fetchline[2] == 'u' )
            if ( fetchline[3] == 'l' )
            if ( fetchline[4] == 'l' )
            if ( fetchline[5] == 's' )
            if ( fetchline[6] == 'k' )
            if ( fetchline[7] == 'i' )
            if ( fetchline[8] == 'p' )
            {
  	      foundcode = 1; //just skip
            }



            // !FILE , to tag and mark the doc (!FILE: will result in skip)
            // note: uppercase / this line: skip
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'F' )
            if ( fetchline[2] == 'I' )
            if ( fetchline[3] == 'L' )
            if ( fetchline[4] == 'E' )
            ///if ( ( fetchline[5] == ':' ) || ( fetchline[5] == ' ' ) )
            {
  	      foundcode = 1; //just skip
            }


            // !author text 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'a' )
            if ( fetchline[2] == 'u' )
            if ( fetchline[3] == 't' )
            if ( fetchline[4] == 'h' )
            if ( fetchline[5] == 'o' )
            if ( fetchline[6] == 'r' )
            if ( fetchline[7] == ' ' )
            {
 	      fputs( "\\author{" , fp5 );
 	      fputs( strcut( fetchline, 7+2, strlen(fetchline)) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }




            // !date text 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'd' )
            if ( fetchline[2] == 'a' )
            if ( fetchline[3] == 't' )
            if ( fetchline[4] == 'e' )
            if ( fetchline[5] == ' ' )
            {
 	      fputs( "\\date{" , fp5 );
 	      fputs( strcut( fetchline, 5+2, strlen(fetchline)) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }


            // !version text 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'v' )
            if ( fetchline[2] == 'e' )
            if ( fetchline[3] == 'r' )
            if ( fetchline[4] == 's' )
            if ( fetchline[5] == 'i' )
            if ( fetchline[6] == 'o' )
            if ( fetchline[7] == 'n' )
            if ( fetchline[8] == ' ' )
            {
              strncpy( doc_version, strcut( fetchline, 8+2, strlen(fetchline)) ,  PATH_MAX );
  	      foundcode = 1;
            }


            // force raw mode for given area/line
            // raw here 
            if ( foundcode == 0 )
            if ( fetchline[0] ==  '!' )
            if ( fetchline[1] ==  'r' ) 
            if ( fetchline[2] ==  'a' ) 
            if ( fetchline[3] ==  'w' ) 
            if ( fetchline[4] ==  ' ' ) 
            {
 	      fputs(  strtxt2tex( strcut( fetchline, 4+2, strlen( fetchline)) ) , fp5 );
  	      foundcode = 1;
            }



            // !title text 
            if ( foundcode == 0 )
            if ( (( fetchline[0] == '!' )
            && ( fetchline[1] == 't' )
            && ( fetchline[2] == 'i' )
            && ( fetchline[3] == 't' )
            && ( fetchline[4] == 'l' )
            && ( fetchline[5] == 'e' )
            && ( fetchline[6] == ' ' )))
            {
 	      fputs( "\\title{" , fp5 );
              if ( fetchline[0] == '!' )
 	        fputs( strcut( fetchline, 6+2, strlen(fetchline)) , fp5 );
              else
 	        fputs(  strtxt2tex( strcut( fetchline, 7+2, strlen(fetchline)) ) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }





            // !maketitle
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' )
            if ( fetchcmdline[1] == 'm' )
            if ( fetchcmdline[2] == 'a' )
            if ( fetchcmdline[3] == 'k' )
            if ( fetchcmdline[4] == 'e' )
            if ( fetchcmdline[5] == 't' )
            if ( fetchcmdline[6] == 'i' )
            if ( fetchcmdline[7] == 't' )
            if ( fetchcmdline[8] == 'l' )
            if ( fetchcmdline[9] == 'e' )
            {
 	      fputs( "\\maketitle" , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }




            /////////////////////////////////////
            /// for !lf line 
            /////////////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'l' )
            if ( fetchline[2] == 'f' )
            if ( fetchline[3] == ' ' )
            {
 	      fputs( strcut( fetchline , 3+2, strlen(  fetchline ))    , fp5 );
  	      fputs( "\\", fp5 );
  	      fputs( "\\", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }






            /////////////////////////////////
            if ( foundcode == 0 )  // !its 
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'i' ) 
            if ( fetchline[2] == 't' )
            if ( fetchline[3] == 's' )
            if ( fetchline[4] == ' ' )
            {
 	        fputs( "- " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , fp5 );
 	        fputs( "\\" , fp5 );
 	        fputs( "\\" , fp5 );
 	        fputs( "\n" , fp5 );
  	        foundcode = 1;
            }



            /////////////////////////////////////
            /// for !line 
            /////////////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'l' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == 'n' )
            if ( fetchline[4] == 'e' )
            if ( fetchline[5] == ' ' )
            {
 	      fputs( strcut( fetchline , 5+2, strlen(  fetchline ))    , fp5 );
  	      fputs( "\\", fp5 );
  	      fputs( "\\", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }
            /////////////////////////////////////
            /// for !linelf text   just line with lf 
            /////////////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'l' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == 'n' )
            if ( fetchline[4] == 'e' )
            if ( fetchline[5] == 'l' )
            if ( fetchline[6] == 'f' )
            if ( fetchline[7] == ' ' )
            {
 	      fputs( strcut( fetchline , 7+2, strlen(  fetchline ))    , fp5 );
  	      fputs( "\\", fp5 );
  	      fputs( "\\", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }




            if ( foundcode == 0 )  // !imtext   
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'i' )
            if ( fetchline[2] == 'm' )
            if ( fetchline[3] == 't' )
            if ( fetchline[4] == 'e' )
            if ( fetchline[5] == 'x' )
            if ( fetchline[6] == 't' )
            if ( fetchline[7] == ' ' )
            {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs(  "\\item " , fp5 );
 	        fputs(  strtext2tex(  strcut( fetchline , 7+2, strlen(  fetchline )) )   , fp5 );
 	        fputs( "\n" , fp5 );
 	        fputs( "\\end{itemize}\n" , fp5 );
  	        foundcode = 1;
            }





            if ( foundcode == 0 )  // !text   
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 't' )
            if ( fetchline[2] == 'e' )
            if ( fetchline[3] == 'x' )
            if ( fetchline[4] == 't' )
            if ( fetchline[5] == ' ' )
            {
 	        fputs(  strtext2tex(  strcut( fetchline , 5+2, strlen(  fetchline )) )   , fp5 );
 	        fputs( "\n" , fp5 );
  	        foundcode = 1;
            }




            /////////////////////////////////////
            /// for !centerline 
            /////////////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'c' )
            if ( fetchline[2] == 'e' )
            if ( fetchline[3] == 'n' )
            if ( fetchline[4] == 't' )
            if ( fetchline[5] == 'e' )
            if ( fetchline[6] == 'r' )
            if ( fetchline[7] == 'l' )
            if ( fetchline[8] == 'i' )
            if ( fetchline[9] == 'n' )
            if ( fetchline[10] == 'e' )
            if ( fetchline[11] == ' ' )
            {
              fputs( "\\begin{center}\n" , fp5 );
 	      fputs( strcut( fetchline, 11+2, strlen(  fetchline ))    , fp5 );
  	      fputs( "\\", fp5 );
  	      fputs( "\\", fp5 );
  	      fputs( "\n", fp5 );
              fputs( "\\end{center}\n" , fp5 );
  	      foundcode = 1;
            }




            /////////////////////////////////////
            /// for CSV or tables !!!!!!!!!!!!  !csv for tables
            /////////////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'c' )
            if ( fetchline[2] == 's' )
            if ( fetchline[3] == 'v' )
            if ( fetchline[4] == ' ' )
            {
  	      ///fputs( "\%csv\n", fp5 );   // this is csv !
 	      //fputs( strcsv2tex(  strtext2tex( strcut( fetchline , 4+2, strlen(  fetchline )) ) )   , fp5 );
 	      fputs( strcsv2tex(  strcut( fetchline , 4+2, strlen(  fetchline )) )    , fp5 );
  	      fputs( " ", fp5 );
  	      fputs( "\\", fp5 );
  	      fputs( "\\", fp5 );
  	      fputs( " \\hline ", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }




            /// !tsv 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 't' )
            if ( fetchline[2] == 's' )
            if ( fetchline[3] == 'v' )
            if ( fetchline[4] == ' ' )
            {
 	      fputs( strcsv2tex(  strtext2tex( strcut( fetchline , 4+2, strlen(  fetchline )) ) )   , fp5 );
  	      fputs( " ", fp5 );
  	      fputs( "\\", fp5 );
  	      fputs( "\\", fp5 );
  	      fputs( " \\hline ", fp5 );
  	      fputs( "\n", fp5 );
  	      fputs( " \\hline ", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }



            ///////////////////////////////////
            if ( foundcode == 0 )  //// !btable{  
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'b' )
            if ( fetchline[2] == 't' )
            if ( fetchline[3] == 'a' )
            if ( fetchline[4] == 'b' )
            if ( fetchline[5] == 'l' )
            if ( fetchline[6] == 'e' )
            if ( fetchline[7] == '{' )
            {
              fputs( "\\begin{center}\n" , fp5 );
              fputs( "\\begin{tabular}{|*{" , fp5 );
              fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
              fputs( "}{c|}}\n" , fp5 );
  	      fputs( "\\hline\n", fp5 );
  	      foundcode = 1;
            }
            ///////////////////////////////////
            if ( foundcode == 0 )  // !btable #colnbr
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'b' )
            if ( fetchline[2] == 't' )
            if ( fetchline[3] == 'a' )
            if ( fetchline[4] == 'b' )
            if ( fetchline[5] == 'l' )
            if ( fetchline[6] == 'e' )
            if ( fetchline[7] == ' ' )
            {
              fputs( "\\begin{center}\n" , fp5 );
              fputs( "\\begin{tabular}{|*{" , fp5 );
 	      fputs( strtrim( strcut( fetchline, 7+2, strlen( fetchline ))) , fp5 );
              table_col_nbr_max = atoi(  strtrim( strcut( fetchline, 7+2, strlen( fetchline ))) );
              fputs( "}{c|}}\n" , fp5 );
  	      fputs( "\\hline\n", fp5 );
  	      foundcode = 1;
            }

            ///////////////////////////////////
            if ( foundcode == 0 )   //// !etable 
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'e' )
            if ( fetchline[2] == 't' )
            if ( fetchline[3] == 'a' )
            if ( fetchline[4] == 'b' )
            if ( fetchline[5] == 'l' )
            if ( fetchline[6] == 'e' )
            {
 	      fputs( "\\end{tabular}\n" , fp5 );
              fputs( "\\end{center}\n" , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }









            /////////////////////////////////
            if ( foundcode == 0 )  // !vsp 
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'v' )
            if ( fetchline[2] == 's' )
            if ( fetchline[3] == 'p' )
            if ( fetchline[4] == ' ' )
            {
 	      fputs( "\\vspace{" , fp5 );
 	      fputs( strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , fp5 );
 	      fputs( "}" , fp5 );
  	      fputs( "\n", fp5 );
	      unilistemptyline++;
  	      foundcode = 1;
            }







            //// !toc   for table of contents
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' )
	    if ( strcmp( fetchcmdline, "!toc" ) == 0 )
            {
 	      fputs( "\\tableofcontents" , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            } 


            //// !tor   for the references (bib)
            //  \clearpage
            //  \bibliography{endnote}{}
            //  \bibliographystyle{ieeetr}
            if ( foundcode == 0 )
            if ( fetchline[ 0 ] == '!' ) 
	    if ( fetchline[ 1 ] == 't' )  
            if ( fetchline[ 2 ] == 'o' ) 
            if ( fetchline[ 3 ] == 'r' ) 
            {
 	      fputs( "\\bibliography{endnote}{}\n" , fp5 );
              if ( fexist( "/etc/wscons.conf" ) == 1 ) 
 	          fputs( "\\bibliographystyle{amsplain}\n" , fp5 );
              else
 	          fputs( "\\bibliographystyle{ieeetr}\n" , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            } 






            //fputs( "\\usepackage{wallpaper}\n", fp5 );
            if ( foundcode == 0 )   // !wallpaper
            if ( beamercode != 1 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'w' )
            if ( fetchline[2] == 'a' )
            if ( fetchline[3] == 'l' )
            if ( fetchline[4] == 'l' )
            if ( fetchline[5] == 'p' )
            if ( fetchline[6] == 'a' )
            if ( fetchline[7] == 'p' )
            if ( fetchline[8] == 'e' )
            if ( fetchline[9] == 'r' )
            {
 	      fputs( "\n" , fp5 );
 	      //fputs( "\\usepackage{hyperref}\n" , fp5 );   <- this is useful for cite 
 	      fputs( "\\usepackage{wallpaper}\n" , fp5 );
 	      fputs( "\n" , fp5 );
  	      foundcode = 1;
            }




  
            ////////////////////////////////// 
            //// !graphicx    
            if ( foundcode  == 0 )
            if ( beamercode != 1 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'g' )
            if ( fetchline[2] == 'r' )
            if ( fetchline[3] == 'a' )
            if ( fetchline[4] == 'p' )
            if ( fetchline[5] == 'h' )
            if ( fetchline[6] == 'i' )
            if ( fetchline[7] == 'c' )
            {
       	         fputs( "\n" , fp5 );
       	         fputs( "\\usepackage{graphicx}\n" , fp5 );
       	         fputs( "\n" , fp5 );
  	         foundcode = 1;
            } 


            ////////////////////////////////// 
            //// !sloppy    
            ////////////////////////////////// 
            if ( foundcode  == 0 )
            if ( beamercode != 1 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 's' )
            if ( fetchline[2] == 'l' )
            if ( fetchline[3] == 'o' )
            if ( fetchline[4] == 'p' )
            if ( fetchline[5] == 'p' )
            if ( fetchline[6] == 'y' )
            {
       	         fputs( "\n" , fp5 );
       	         fputs( "\\sloppy\n" , fp5 );  // for justified and keep inside margin
       	         fputs( "\n" , fp5 );
  	         foundcode = 1;
            } 



            if ( foundcode == 0 )   // !thankyou (easy addon)
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 't' )
            if ( fetchline[2] == 'h' )
            if ( fetchline[3] == 'a' )
            if ( fetchline[4] == 'n' )
            if ( fetchline[5] == 'k' )
            if ( fetchline[6] == 'y' )
            if ( fetchline[7] == 'o' )
            if ( fetchline[8] == 'u' )
            {
              fputs( "\\clearpage", fp5 );
              fputs( "\\begin{frame}", fp5 );
              fputs( "\\vspace{3.3cm}", fp5 );
              fputs( "\\begin{center}", fp5 );
              fputs( "{\\fontsize{30}{40}\\selectfont {\\it Thank you for your attention}}", fp5 );
              fputs( "\\end{center}", fp5 );
              fputs( "\\end{frame}", fp5 );
  	      foundcode = 1;
            }






            /////////////////////////////////////////
            /////////////////////////////////////////
            /////////////////////////////////////////
            if ( foundcode == 0 )   // !postit   
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'p' )
            if ( fetchline[2] == 'o' )
            if ( fetchline[3] == 's' )
            if ( fetchline[4] == 't' )
            if ( fetchline[5] == 'i' )
            if ( fetchline[6] == 't' )
            {
 	      //fputs( "\n" , fp5 );
              /// to cont
 	      //fputs( "\n" , fp5 );
  	      foundcode = 1;
            }


            /////////////////////////////////////////
            if ( foundcode == 0 )   // !reset section
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'r' )
            if ( fetchline[2] == 'e' )
            if ( fetchline[3] == 's' )
            if ( fetchline[4] == 'e' )
            if ( fetchline[5] == 't' )
	    if ( strcmp( fetchcmdline, "!reset section" ) == 0 )
            {
                 fputs(  "\n" , fp5 );
                 fputs( "\\setcounter{section}{0}", fp5 );
  	         fputs( "\n", fp5 );
  	         foundcode = 1;
            }




            /////////////////////////////////////////
            if ( foundcode == 0 )   // !part text
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'p' )
            if ( fetchline[2] == 'a' )
            if ( fetchline[3] == 'r' )
            if ( fetchline[4] == 't' )
            if ( fetchline[5] == ' ' )
            {
  	      fputs( "\\vspace{0.5cm}\n", fp5 );
 	      fputs( "\\noindent\n" , fp5 );
 	      fputs( "\\textit{" , fp5 );
 	      fputs( "{\\bfseries " , fp5 );
 	      fputs( strcut( fetchline, 5+2, strlen(fetchline)) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "}\n", fp5 );
  	      //fputs( "\\\\", fp5 );
  	      fputs( "\\vspace{0.2cm}\n", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }







            /////////////////////////////////////////
            /////////////////////////////////////////
            /////////////////////////////////////////
            if ( foundcode == 0 )   // !doc or !unidoc   <- auto document   
            if (( ( fetchline[0] == '!' ) 
            && ( fetchline[1] == 'd' )
            && ( fetchline[2] == 'o' )
            && ( fetchline[3] == 'c' )
	    && ( strcmp( fetchcmdline, "!doc" ) == 0 )) 
            || ( ( fetchline[0] == '!' ) 
            && ( fetchline[1] == 'u' )
            && ( fetchline[2] == 'n' )
            && ( fetchline[3] == 'i' )
            && ( fetchline[4] == 'd' )
	    && ( strcmp( fetchcmdline, "!unidoc" ) == 0 )) )
            {
                 fputs( "\n" , fp5 );
                 fputs( "\\documentclass[11pt]{article}\n", fp5 );
 	         fputs( "\\usepackage{grffile}\n" , fp5 );
 	         fputs( "\\usepackage{graphicx}\n" , fp5 );
 	         fputs( "\\usepackage{xcolor}\n" , fp5 );
                 fputs( "\\usepackage[utf8]{inputenc}\n", fp5 );
                 fputs( "\\begin{document}\n" , fp5 );
                 fputs( "\n" , fp5 );
  	         foundcode = 1;
            }

            /////////////////////////////////////////
            if ( foundcode == 0 )   // !unibook   <- auto document   
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'u' )
            if ( fetchline[2] == 'n' )
            if ( fetchline[3] == 'i' )
            if ( fetchline[4] == 'b' )
	    if ( strcmp( fetchcmdline, "!unibook" ) == 0 )
            {
                 fputs( "\n" , fp5 );
                 fputs( "\\documentclass[11pt]{book}\n", fp5 );
 	         fputs( "\\usepackage{grffile}\n" , fp5 );
 	         fputs( "\\usepackage{graphicx}\n" , fp5 );
 	         fputs( "\\usepackage{xcolor}\n" , fp5 );
                 fputs( "\\begin{document}\n" , fp5 );
                 fputs( "\n" , fp5 );
  	         foundcode = 1;
            }





            /////////////////////////////////////////
            /////////////////////////////////////////
            /////////////////////////////////////////
            if ( foundcode == 0 )   // !epstopdf  
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'e' )
            if ( fetchline[2] == 'p' )
            if ( fetchline[3] == 's' )
            if ( fetchline[4] == 't' )
            if ( fetchline[5] == 'o' )
            if ( fetchline[6] == 'p' )
            if ( fetchline[7] == 'd' )
            if ( fetchline[8] == 'f' )
            {
 	      fputs( "\n" , fp5 );
 	      fputs( "\\usepackage{epstopdf}\n" , fp5 );
 	      fputs( "\n" , fp5 );
  	      foundcode = 1;
            }


            ////////////////////////////////////////////
            if ( foundcode == 0 )   // !placeins  or !easy (same)
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'e' )
            if ( fetchline[2] == 'a' )
            if ( fetchline[3] == 's' )
            if ( fetchline[4] == 'y' )
            {
 	      fputs( "\n" , fp5 );
 	      fputs( "\\usepackage[section]{placeins}\n" , fp5 ); // new 
 	      fputs( "\n" , fp5 );
  	      foundcode = 1;
            }






            /////////////////////////////////
            /////////////////////////////////
            if ( foundcode == 0 )   // !space 
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 's' )
            if ( fetchline[2] == 'p' )
            if ( fetchline[3] == 'a' )
            if ( fetchline[4] == 'c' )
            if ( fetchline[5] == 'e' )
            {
 	      fputs( "\n" , fp5 );
              //fputs( "//\\renewcommand{\\baselinestretch}{1.5}\n", fp5);
              //fputs( "%//\\setlength{\\parindent}{10ex}\n", fp5);
              fputs( "\\setlength{\\parskip}{10pt plus 1pt minus 1pt}\n" , fp5 );
 	      fputs( "\n" , fp5 );
  	      foundcode = 1;
            }



            if ( foundcode == 0 )   // !tikz 
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 't' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == 'k' )
            if ( fetchline[4] == 'z' )
            {
 	      fputs( "\n" , fp5 );
 	      fputs( "\\usepackage{tikz}\n" , fp5 );
 	      fputs( "\n" , fp5 );
  	      foundcode = 1;
            }





            //////////////////////////////////
            //// !pdfpage
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) // for left at 0 char pos
            if ( fetchline[1] == 'p' )
            if ( fetchline[2] == 'd' )
            if ( fetchline[3] == 'f' )
            if ( fetchline[4] == 'p' )
            if ( fetchline[5] == 'a' )
            if ( fetchline[6] == 'g' )
            if ( fetchline[7] == 'e' )
            ////
            {
 	      fputs( "\n" , fp5 );
 	      fputs( "\\usepackage{pdfpages}\n" , fp5 );
 	      fputs( "\n" , fp5 );
  	      foundcode = 1;
            }




            ///////////// !pdf for pdfpages
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'p' )
            if ( fetchline[2] == 'd' )
            if ( fetchline[3] == 'f' )
            if ( fetchline[4] == '{' )
            {
  	      fputs( "\\includepdf{", fp5 );
 	      fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }



            //////////////////////////////////
            //// !pdfpage 
            if ( foundcode  == 0 )
            if ( fetchline[0] == '!' ) // for left at 0 char pos
            if ( fetchline[1] == 'p' )
            if ( fetchline[2] == 'd' )
            if ( fetchline[3] == 'f' )
            if ( fetchline[4] == 'p' )
            if ( fetchline[5] == 'a' )
            if ( fetchline[6] == 'g' )
            if ( fetchline[7] == 'e' )
            {
       	         fputs( "\\usepackage{pdfpages}\n" , fp5 );
  	         foundcode = 1;
            } 



            //////////////////////////////////
            //// !package !packages 
            if ( foundcode  == 0 )
            if ( fetchline[0] == '!' ) // for left at 0 char pos
            if ( fetchline[1] == 'p' )
            if ( fetchline[2] == 'a' )
            if ( fetchline[3] == 'c' )
            if ( fetchline[4] == 'k' )
            if ( fetchline[5] == 'a' )
            if ( fetchline[6] == 'g' )
            if ( fetchline[7] == 'e' )
            ////
            {
              if ( beamercode != 1 ) 
              { // necessary for bullets of beamer!, ideally !beamer !packages 
       	         fputs( "\n" , fp5 );
       	         fputs( "\\usepackage{url}\n" , fp5 );
       	         fputs( "\\usepackage{hyperref}\n" , fp5 );
       	         fputs( "\\usepackage{graphicx}\n" , fp5 );
       	         fputs( "\\usepackage{grffile}\n" , fp5 );
       	         fputs( "\\usepackage{pdfpages}\n" , fp5 );
       	         //fputs( "\\usepackage{gensymb}\n" , fp5 ); //for symbols
       	         fputs( "\\usepackage{wallpaper}\n" , fp5 );
       	         fputs( "\n" , fp5 );
       	         fputs( "\\usepackage{epstopdf}\n" , fp5 );
       	         fputs( "\\usepackage{enumitem}\n" , fp5 );  // for >> and items 
       	         fputs( "\n" , fp5 );
       	         fputs( "\\usepackage{soul}\n" , fp5 );      // for reviews
       	         fputs( "\n" , fp5 );
                 fputs( "\\sloppy\n", fp5 );
                 fputs( "\\usepackage[none]{hyphenat}\n", fp5 );
       	         fputs( "\n" , fp5 );
                 fputs( "\\usepackage[utf8]{inputenc}", fp5 );
       	         fputs( "\n" , fp5 );
       	         fputs( "\n" , fp5 );
       	         //fputs( "\\sloppy\n" , fp5 );  // for justified and keep inside margin
       	         fputs( "\n" , fp5 );
              }
  	      foundcode = 1;
            } 





            //////////////////////////////////
            //// !utf8 or !utf (utf8 is today working)
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' )
	    if ( strcmp( fetchcmdline, "!utf8" ) == 0 )
            {
  	      fputs( "\n", fp5 );
              fputs( "\\usepackage[utf8]{inputenc}\n", fp5 );
  	      fputs( "\n", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            } 
            //// !utf
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' )
	    if ( strcmp( fetchcmdline, "!utf" ) == 0 )
            {
              fputs( "\\usepackage[utf8]{inputenc}", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            } 







            /////////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'c' )
            if ( fetchline[2] == 'h' )
            if ( fetchline[3] == 'a' )
            if ( fetchline[4] == 'r' )
            if ( fetchline[5] == 'b' )
            if ( fetchline[6] == 'c' )
            if ( fetchline[7] == ' ' )
            {
 	        strncpy( foostr, strcut( fetchline, 7+2, strlen(fetchline)) , PATH_MAX );
 	        //strncpy( foostr, fetchline, PATH_MAX );
                foodo = snprintf( fooccharo, 50 , "%d", strcharcount( foostr ) );
 	        fputs( fooccharo , fp5 );
                fputs( ": "   , fp5 );
 	        fputs( foostr , fp5 );
 	        fputs( "\n"   , fp5 );
  	        foundcode = 1;
            } 







            //////////////////////////////////////////////
            // !rawline  with a lf
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'r' )
            if ( fetchline[2] == 'a' )
            if ( fetchline[3] == 'w' )
            if ( fetchline[4] == 'l' )
            if ( fetchline[5] == 'i' )
            if ( fetchline[6] == 'n' )
            if ( fetchline[7] == 'e' )
            if ( fetchline[8] == ' ' )
            {
       	         fputs( strtxt2tex(strcut( fetchline, 8+2, strlen(fetchline))) , fp5 );
  	         fputs( "\\", fp5 );
  	         fputs( "\\", fp5 );
  	         fputs( "\n", fp5 );
  	         foundcode = 1;
            }
            //////////////////////////////////////////////
            // !raw   my text for a given line 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'r' )
            if ( fetchline[2] == 'a' )
            if ( fetchline[3] == 'w' )
            if ( fetchline[4] == ' ' )
            {
       	         fputs( strtxt2tex(strcut( fetchline, 4+2, strlen(fetchline))) , fp5 );
        	 fputs( "\n", fp5 );
  	         foundcode = 1;
            }
            //////////////////////////////////////////////





            ////// !beginraw 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'b' )
            if ( fetchline[2] == 'e' )
            if ( fetchline[3] == 'g' )
            if ( fetchline[4] == 'i' )
            if ( fetchline[5] == 'n' )
            if ( fetchline[6] == 'r' )
            if ( fetchline[7] == 'a' )
            if ( fetchline[8] == 'w' )
            if ( fetchline[9] == ' ' )
            {
	      txtrawcode = 1;
  	      foundcode = 1;
            }
            // !endraw
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'e' )
            if ( fetchline[2] == 'n' )
            if ( fetchline[3] == 'd' )
            if ( fetchline[4] == 'r' )
            if ( fetchline[5] == 'a' )
            if ( fetchline[6] == 'w' )
            {
	      txtrawcode = 0;
  	      foundcode = 1;
            }







            // !input 
            if ( foundcode == 0 )
	    if ( 
            ( (  fetchline[0] ==  '!' ) || (  fetchline[0] ==  '#' ) )
            && ( fetchline[1] == 'i' )
            && ( fetchline[2] == 'n' )
            && ( fetchline[3] == 'p' )
            && ( fetchline[4] == 'u' )
            && ( fetchline[5] == 't' )
            && ( fetchline[6] == '{' )
	    )
            {
              fclose( fp5 );                 /// writer
              long saved = ftell( fp6 );     /// reader
              fclose( fp6 );                 /// reader

              printf( ">COMMAND INPUT<\n"); 
	      char fileinputsrc[PATH_MAX];
	      strncpy( fileinputsrc,  myinputspath , PATH_MAX );
              strncat( fileinputsrc , strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX - strlen( fileinputsrc ) -1 );
              printf( ">COMMAND INPUT Src %s<\n", fileinputsrc ); 

	        if ( fileinputsrc[0] == '~' )
	        {
	         strncpy( fileinputsrc, "" , PATH_MAX );
                 strncat( fileinputsrc , getenv( "HOME" ) , PATH_MAX - strlen( fileinputsrc ) -1 );
                 strncat( fileinputsrc , strdelimit( fetchline,  '~' ,'}' ,  1 ) , PATH_MAX - strlen( fileinputsrc ) -1 );
	        }
                //filetexiex( fileout, strdelimit( fetchline,  '{' ,'}' ,  1 ) );
		printf( "!input{%s} (fexist:%d) (...)\n", fileinputsrc , fexist( fileinputsrc ) );
                printf( "> READ FROM IPATH: %s\n", myinputspath );
                nfileunimark( fileout, fileinputsrc );
              fp5 = fopen( fileout , "ab+"); /// writer
              fp6 = fopen( filein , "r");  /// reader
              fseek( fp6 , saved , SEEK_SET); // reader 
  	      foundcode = 1;
            }










            ////////////////// 
            //// #include{file.mrk}  or !include{doc.mrk}
            //// it will load the content from the ~/include/mrk/ 
            //////////////////
            if ( foundcode == 0 )
	    if ( ( (  fetchline[0] ==  '!' ) || (  fetchline[0] ==  '#' ) )
            && ( fetchline[1] == 'i' )
            && ( fetchline[2] == 'n' )
            && ( fetchline[3] == 'c' )
            && ( fetchline[4] == 'l' )
            && ( fetchline[5] == 'u' )
            && ( fetchline[6] == 'd' )
            && ( fetchline[7] == 'e' )
            && ( fetchline[8] == '{' )
	    )
            {
              fclose( fp5 );                 /// writer
              long saved = ftell( fp6 );     /// reader
              fclose( fp6 );                 /// reader

	      char fileinputsrc[PATH_MAX];
	      strncpy( fileinputsrc, "", PATH_MAX );
              strncat( fileinputsrc , getenv( "HOME" ) , PATH_MAX - strlen( fileinputsrc ) -1 );
              strncat( fileinputsrc , "/include/mrk/" , PATH_MAX - strlen( fileinputsrc ) -1 );
              strncat( fileinputsrc , strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX - strlen( fileinputsrc ) -1 );
 	      printf( " =>!include{%s} (fexist:%d) (...)\n", fileinputsrc , fexist( fileinputsrc ) );
              nfileunimark( fileout, fileinputsrc );
              fp5 = fopen( fileout , "ab+"); /// writer
              fp6 = fopen( filein , "r");  /// reader
              fseek( fp6 , saved , SEEK_SET); // reader 
  	      foundcode = 1;
            }



	    /////////////////
            ////////////////
            //// !begin here
            ////////////////
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' )
	    if ( strcmp( fetchcmdline, "!begin" ) == 0 )  // !begin
            {
	      contentcode = 1;
 	      fputs( "\\begin{document}" , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }






            ////////////////
            ////////////////
            //// !enddoc here
            ////////////////
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' )
	    if ( strcmp( fetchcmdline, "!enddoc" ) == 0 )
            {
	      contentcode = 0;
 	      fputs( "\\end{document}" , fp5 );
  	      fputs( "\n", fp5 );
              fp_content_eod = 1;
  	      foundcode = 1;
            }





            ////////////////
            ////////////////
            //// !end here, to be compatible with rose (2019)
            ////////////////
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' )
	    if ( strcmp( fetchcmdline, "!end" ) == 0 )
            {
	      contentcode = 0;
 	      fputs( "\\end{document}" , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }







            ////////////////
            //// !EOD here, !EOD 
            //// end of document (not copying/usage of lines after this line for content but can work for endnote)
            ////////////////
            //if ( fetchcmdline[0] == '!' )
	    //if ( strcmp( fetchcmdline, "!EOD" ) == 0 )
            if ( foundcode == 0 )
            if ( fetchline[ 0 ] == '!' ) 
	    if ( fetchline[ 1 ] == 'E' )  
            if ( fetchline[ 2 ] == 'O' ) 
            if ( fetchline[ 3 ] == 'D' ) 
            {
              fp_content_eod = 1;
	      contentcode = 0;
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }





            //// !book  (content)      // !book start a book
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'b' )
            if ( fetchline[2] == 'o' )
            if ( fetchline[3] == 'o' )
            if ( fetchline[4] == 'k' )
            {
	      bookcode = 1;
              //\documentclass{book}
              fputs( "\\documentclass[11pt]{book}", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }



            //// !beamer      !beamer activate beamer 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'b' )
            if ( fetchline[2] == 'e' )
            if ( fetchline[3] == 'a' )
            if ( fetchline[4] == 'm' )
            if ( fetchline[5] == 'e' )
            if ( fetchline[6] == 'r' )
            {
	      beamercode = 1;
  	      foundcode = 1;
            }
            //// !:set beamer=0
            /*
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == ':' )
            if ( fetchline[2] == 'b' )
            if ( fetchline[3] == 'e' )
            if ( fetchline[4] == 'a' )
            if ( fetchline[5] == 'm' )
            if ( fetchline[6] == 'e' )
            if ( fetchline[7] == 'r' )
            if ( fetchline[8] == '=' )
            if ( fetchline[9] == '0' )
            {
	      beamercode = 0;
  	      foundcode = 1;
            }
            */

            //// !noter
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'n' )
            if ( fetchline[2] == 'o' )
            if ( fetchline[3] == 't' )
            if ( fetchline[4] == 'e' )
            if ( fetchline[5] == 'r' )
            {
	      notercode = 1;
  	      foundcode = 1;
            }
            ///////////////////////////////////
            //// !bhtml
            if ( foundcode == 0 )  //!bhtml 
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'b' )
            if ( fetchline[2] == 'h' )
            if ( fetchline[3] == 't' )
            if ( fetchline[4] == 'm' )
            if ( fetchline[5] == 'l' )
            {
              markup_output_format = 2;
  	      foundcode = 1;
            } 

            //// !html
            // 20180101-105417
            if ( foundcode == 0 )  //!html for simplicity
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'h' )
            if ( fetchline[2] == 't' )
            if ( fetchline[3] == 'm' )
            if ( fetchline[4] == 'l' )
            {
              markup_output_format = 2;
  	      foundcode = 1;
            } 


            //// !format 12
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'f' )
            if ( fetchline[2] == 'o' )
            if ( fetchline[3] == 'r' )
            if ( fetchline[4] == 'm' )
            if ( fetchline[5] == 'a' )
            if ( fetchline[6] == 't' )
            if ( fetchline[7] == ' ' )
            if ( fetchline[8] == '1' )
            if ( fetchline[9] == '2' )
            {
              markup_output_format = 12;   //format 10
  	      foundcode = 1;
            } 

            //// !format 14
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'f' )
            if ( fetchline[2] == 'o' )
            if ( fetchline[3] == 'r' )
            if ( fetchline[4] == 'm' )
            if ( fetchline[5] == 'a' )
            if ( fetchline[6] == 't' )
            if ( fetchline[7] == ' ' )
            if ( fetchline[8] == '1' )
            if ( fetchline[9] == '4' )
            {
              markup_output_format = 14;  
  	      foundcode = 1;
            } 

            /////////////////////////////////
            /////////////////////////////////
            /////////////////////////////////
            /////////////////////////////////
            //// !format 10 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'f' )
            if ( fetchline[2] == 'o' )
            if ( fetchline[3] == 'r' )
            if ( fetchline[4] == 'm' )
            if ( fetchline[5] == 'a' )
            if ( fetchline[6] == 't' )
            if ( fetchline[7] == ' ' )
            if ( fetchline[8] == '1' )
            if ( fetchline[9] == '0' )
            {
              // !format 10   
              // !format 10  will enable it.
              markup_output_format = 10;   //format 10
  	      foundcode = 1;
            } 

            //// !format{XXX} format{  format{, 11 is books
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'f' )
            if ( fetchline[2] == 'o' )
            if ( fetchline[3] == 'r' )
            if ( fetchline[4] == 'm' )
            if ( fetchline[5] == 'a' )
            if ( fetchline[6] == 't' )
            if ( fetchline[7] == '{' )
            {
 	      strncpy( fooccharo, strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX );
              markup_output_format = atoi( fooccharo );
  	      foundcode = 1;
            } 


            ////////////
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' )
            if ( fetchcmdline[1] == 'p' )
            if ( strstr( fetchcmdline, "!print format" ) != 0 ) 
            {
              fooc = snprintf( fooccharo, 250 , "CODE: The format is %d", markup_output_format );
 	      fputs( fooccharo , fp5 );
 	      fputs( "\n" , fp5 );
  	      foundcode = 1;
            } 





            /////////////////////////////////
            if ( foundcode == 0 )  // !im 
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'i' ) 
            if ( fetchline[2] == 'm' )
            if ( fetchline[3] == ' ' )
            if ( markup_output_format == 1 )  // note <--
            {
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 3+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
  	        foundcode = 1;
            }
            /////////////////////////////////
            /// they are here together
            /////////////////////////////////
            if ( foundcode == 0 )  // !im 
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'i' ) 
            if ( fetchline[2] == 'm' )
            if ( fetchline[3] == ' ' )
            {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item[{\\bfseries {" , fp5 );
                fooc = snprintf( fooccharo, 50 , "%d", question_qucounter );
 	        fputs( fooccharo  , fp5 );
 	        fputs( "}}.)]{" , fp5 );
                question_qucounter++;
 	        fputs( strtrim( strcut( fetchline, 3+2, strlen(fetchline))) , fp5 );
                if ( markup_output_format == 10 ) 
                    fputs( " (3 Pkt.)}" , fp5 );
                else if ( markup_output_format == 12 ) 
                    fputs( " (3 Pkt.)}" , fp5 );
                else 
                    fputs( "}" , fp5 );
 	        fputs( "\n" , fp5 );
 	        fputs( "\\end{itemize}\n" , fp5 );
 	        ///fputs( "\\vspace{4cm}\n" , fp5 );  // the trick is to have 4cm to allow answers.
  	        foundcode = 1;
            }
            /////////////////////////////////












            /////////////////////////////////
            if ( foundcode == 0 ) //!qu++  just increment +1 counter (qu)
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'q' )
            if ( fetchline[2] == 'u' )
            if ( fetchline[3] == '+' )
            if ( fetchline[4] == '+' )
            {
                question_qucounter++;
  	        foundcode = 1;
            }





            /////////////////////////////////
            if ( foundcode == 0 ) // !qun with number but without space, designed for images , sort of !qu no space  for IMAGES (about 18mm)
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'q' ) 
            if ( fetchline[2] == 'u' )
            if ( fetchline[3] == 'n' )
            if ( fetchline[4] == ' ' )
            {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item[{\\bfseries {" , fp5 );
                fooc = snprintf( fooccharo, 50 , "%d", question_qucounter );
 	        fputs( fooccharo  , fp5 );
 	        fputs( "}}.)]{" , fp5 );
                question_qucounter++;
 	        fputs( strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , fp5 );
                fputs( " (3 Pkt.)}" , fp5 );
 	        fputs( "\n" , fp5 );
 	        fputs( "\\end{itemize}\n" , fp5 );
  	        foundcode = 1;
            }
            /////////////////////////////////

            /////////////////////////////////
            /////////////////////////////////
            if ( foundcode == 0 ) // !qu with pkt 
            if ( markup_output_format == 10 ) 
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'q' ) 
            if ( fetchline[2] == 'u' )
            if ( fetchline[3] == ' ' )
            {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item[{\\bfseries {" , fp5 );
                fooc = snprintf( fooccharo, 50 , "%d", question_qucounter );
 	        fputs( fooccharo  , fp5 );
 	        fputs( "}}.)]{" , fp5 );
                question_qucounter++;
 	        fputs( strtrim( strcut( fetchline, 3+2, strlen(fetchline))) , fp5 );
                fputs( " (3 Pkt.)}" , fp5 );
 	        fputs( "\n" , fp5 );
 	        fputs( "\\end{itemize}\n" , fp5 );
 	        //fputs( "\\vspace{4cm}\n" , fp5 );  // the trick is to have 4cm to allow answers.
                //if ( markup_output_format == 10 ) 
 	        fputs( "\\vspace{4cm}\n" , fp5 );  // 4 qu per page, 6cm would be 3 qu per page
  	        foundcode = 1;
            }
            /////////////////////////////////
            /////////////////////////////////



            /////////////////////////////////
            /////////////////////////////////
            //// !format 10 end
            /////////////////////////////////
            /////////////////////////////////
            /////////////////////////////////


            /////////////////////////////////
            if ( foundcode == 0 ) // !qu with pkt 
            if ( markup_output_format == 11 ) 
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'q' ) 
            if ( fetchline[2] == 'u' )
            if ( fetchline[3] == ' ' )
            {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item[{\\bfseries {" , fp5 );
                fooc = snprintf( fooccharo, 50 , "%d", question_qucounter );
 	        fputs( fooccharo  , fp5 );
 	        fputs( "}}.)]{" , fp5 );
                question_qucounter++;
 	        fputs( strtrim( strcut( fetchline, 3+2, strlen(fetchline))) , fp5 );
                fputs( " (3 Pkt.)}" , fp5 );
 	        fputs( "\n" , fp5 );
 	        fputs( "\\end{itemize}\n" , fp5 );
 	        fputs( "\\vspace{6cm}\n" , fp5 );  // 3 qu per page
  	        foundcode = 1;
            }
            /////////////////////////////////
            /////////////////////////////////




            /////////////////////////////////
            if ( foundcode == 0 ) // !qu with pkt 
            if ( markup_output_format == 12 ) 
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'q' ) 
            if ( fetchline[2] == 'u' )
            if ( fetchline[3] == ' ' )
            {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item[{\\bfseries {" , fp5 );
                fooc = snprintf( fooccharo, 50 , "%d", question_qucounter );
 	        fputs( fooccharo  , fp5 );
 	        fputs( "}}.)]{" , fp5 );
                question_qucounter++;
 	        fputs( strtrim( strcut( fetchline, 3+2, strlen(fetchline))) , fp5 );
                fputs( " (3 Pkt.)}" , fp5 );
 	        fputs( "\n" , fp5 );
 	        fputs( "\\end{itemize}\n" , fp5 );
 	        fputs( "\\vspace{6cm}\n" , fp5 );  // 3 qu per page
  	        foundcode = 1;
            }
            /////////////////////////////////
            /////////////////////////////////


            /////////////////////////////////
            /////////////////////////////////
            if ( foundcode == 0 ) // !qu with pkt 
            if ( markup_output_format == 14 ) 
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'q' ) 
            if ( fetchline[2] == 'u' )
            if ( fetchline[3] == ' ' )
            {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item[{\\bfseries {" , fp5 );
                fooc = snprintf( fooccharo, 50 , "%d", question_qucounter );
 	        fputs( fooccharo  , fp5 );
 	        fputs( "}}.)]{" , fp5 );
                question_qucounter++;
 	        fputs( strtrim( strcut( fetchline, 3+2, strlen(fetchline))) , fp5 );
                fputs( " (3 Pkt.)}" , fp5 );
 	        fputs( "\n" , fp5 );
 	        fputs( "\\end{itemize}\n" , fp5 );
 	        fputs( "\\vspace{9cm}\n" , fp5 );  // 3 qu per page
  	        foundcode = 1;
            }
            /////////////////////////////////
            /////////////////////////////////








            //// !exam list   or !exam-list 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'e' )
            if ( fetchline[2] == 'x' )
            if ( fetchline[3] == 'a' )
            if ( fetchline[4] == 'm' )
            if (( fetchline[5] == ' ' ) || ( fetchline[5] == '-' ))
            if ( fetchline[6] == 'l' )
            if ( fetchline[7] == 'i' )
            if ( fetchline[8] == 's' )
            if ( fetchline[9] == 't' )
            {
              markup_output_format = 8;
  	      foundcode = 1;
            } 


            //////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'e' )
            if ( fetchline[2] == 'x' )
            if ( fetchline[3] == 'a' )
            if ( fetchline[4] == 'm' )
            if ( fetchline[5] == 'l' )
            if ( fetchline[6] == 'i' )
            if ( fetchline[7] == 's' )
            if ( fetchline[8] == 't' )
            {
              markup_output_format = 8;
  	      foundcode = 1;
            } 


            //// !exam+  //
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'e' )
            if ( fetchline[2] == 'x' )
            if ( fetchline[3] == 'a' )
            if ( fetchline[4] == 'm' )
            if ( fetchline[5] == '+' )
            {
              markup_output_format = 6;
  	      foundcode = 1;
            } 

            //// !exam  for en exams !!
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'e' )
            if ( fetchline[2] == 'x' )
            if ( fetchline[3] == 'a' )
            if ( fetchline[4] == 'm' )
            {
              markup_output_format = 3;
  	      foundcode = 1;
            } 



            if ( foundcode == 0 )  // !nopagemark 
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'n' )
            if ( fetchline[2] == 'o' )
            if ( fetchline[3] == 'p' )
            if ( fetchline[4] == 'a' )
            if ( fetchline[5] == 'g' )
            if ( fetchline[6] == 'e' )
            if ( fetchline[7] == 'm' )
            if ( fetchline[8] == 'a' )
            if ( fetchline[9] == 'r' )
            if ( fetchline[10] == 'k' )
            {
               printf( "==>No pagemark, %d\n", pagemark_mode_active );
               pagemark_mode_active = 0;
  	       foundcode = 1;
            } 







 /*
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 's' )
            if ( fetchline[2] == 't' )
            if ( fetchline[3] == 'b' )
            if ( fetchline[4] == 'o' )
            if ( fetchline[5] == 'o' )
            if ( fetchline[6] == 'k' )
            {
              // !stbook
              markup_output_format = 11 ;
  	      foundcode = 1; //just skip
            }
            ///////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '>' )
            if ( fetchline[1] == ' ' )
            if ( markup_output_format == 11 ) //!bookcode
            {
 	      strncpy( cursubsection,  strtrim( strcut( fetchline, 1+2, strlen(fetchline))) ,  PATH_MAX );
              if ( strcmp( cursubsection, lastsubsection ) != 0 ) 
              {
 	          fputs( "\%subsection320\n" , fp5 );
 	          fputs( "\\subsection{" , fp5 );
 	          fputs( cursubsection ,  fp5 );
 	          fputs( "}\n" , fp5 );
                  strncpy( lastsubsection, "", PATH_MAX );
              }
  	      foundcode = 1;
            } 

            ///////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '-' )
            if ( fetchline[1] == ' ' )
            if ( markup_output_format == 11 ) //!bookcode
            {
 	      fputs( strcut( fetchline, 1+2, strlen(fetchline)) , fp5 );
 	      fputs( "\n" , fp5 );
  	      foundcode = 1;
            } 
*/




   // !fild
   ////////////////////////////////////
   // beamer starts here 
   // beamer here
   // BEAMER HERE
   // it might work too with != 
   ////////////////////////////////////
   if ( foundcode == 0 )
   if ( beamercode == 1 )
   {
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'f' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == 'l' )
            if ( fetchline[4] == 'd' )
            if ( fetchline[5] == ' ' )
            {
                fputs( "\\begin{frame}\n" , fp5);
                fputs( "\\fitimage{\n" , fp5);
                fputs( "\\frametitle{\\thesection.~\\insertsection}\n" , fp5 );
                fputs( "\\begin{itemize}\n", fp5 );
                fputs( "\\item ", fp5 );
     	        fputs( strtxt2tex( strtrim( strcut( fetchline, 5+2, strlen( fetchline )))) , fp5 );
                fputs( "\n", fp5 );
                fputs( "\\end{itemize}\n", fp5 );
                fputs( "}{", fp5 );
     	        fputs( strtrim( strcut( fetchline, 5+2, strlen( fetchline ))) , fp5 );
                fputs( "}[]\n" , fp5 );
                fputs( "\\end{frame}\n" , fp5 );
  	        foundcode = 1;
            }
   }





   ////////////////////////////////////
   // beamer starts here 
   ////////////////////////////////////
   if ( foundcode == 0 )
   if ( beamercode == 1 )
   {
	    // opener !clr
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
            if ( ( fetchline[0] == '!' ) || ( fetchline[0] == '$' ) )
            if ( fetchline[1] == 'c' )
            if ( fetchline[2] == 'l' )
            if ( fetchline[3] == 'r' )
            {
              foxy++;//
              strncpy( slidebufferdata[foxy] , "\\begin{frame}" , PATH_MAX );
	      beamerlevel = 0;
  	      foundcode = 1;
            }


            if ( foundcode == 0 ) // !toc Inhalt
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 't' )
            if ( fetchline[2] == 'o' )
            if ( fetchline[3] == 'c' )
            if ( fetchline[4] == ' ' )
            {
 	      fputs( "\\clearpage\n" , fp5 );
 	      fputs( "\\begin{frame}\n" , fp5 );
 	      fputs( "\\frametitle{" , fp5 );
 	      fputs( strtrim( strcut( fetchline, 4+2, strlen( fetchline ))) , fp5 );
  	      fputs( "}\n", fp5 );
 	      fputs( "\\tableofcontents\n" , fp5 );
 	      fputs( "\\end{frame}\n" , fp5 );
 	      fputs( "\n" , fp5 );
 	      fputs( "\n" , fp5 );
	      beamerlevel = 0;
  	      foundcode = 1;
            }


            if ( foundcode == 0 ) // !frame 
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'f' )
            if ( fetchline[2] == 'r' )
            if ( fetchline[3] == 'a' )
            if ( fetchline[4] == 'm' )
            if ( fetchline[5] == 'e' )
            if ( fetchline[6] == ' ' )
	    if ( beamercode == 1 ) 
            {
              foxy++;
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\frametitle{"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 6+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , "}"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
  	      foundcode = 1;
            }


            ////////////////////
            // 20170930-175843 this is the default, without auto section numbering
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'h' )
            if ( fetchline[2] == 'e' )
            if ( fetchline[3] == 'a' )
            if ( fetchline[4] == 'd' )
            if ( fetchline[5] == 'e' )
            if ( fetchline[6] == 'r' )
            if ( fetchline[7] == ' ' )
	    if ( beamercode == 1 ) 
            {
              foxy++;
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\frametitle{"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 7+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , "}"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
  	      foundcode = 1;
            }



            // !note  
            if ( foundcode == 0 )
	    if ( beamercode == 1 ) 
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'n' )
            if ( fetchline[2] == 'o' )
            if ( fetchline[3] == 't' )
            if ( fetchline[4] == 'e' )
            if ( fetchline[5] == ' ' )
            {
              foxy++;
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\note{"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 5+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , "}"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
  	      foundcode = 1;
            }



            ////////////////////
            //// this is beamer
            ////////////////////
            // 20170930-175843 this is the advanced, with auto section numbering
            /*
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) // !sec sectionname for beamer
            if ( fetchline[1] == 's' )
            if ( fetchline[2] == 'e' )
            if ( fetchline[3] == 'c' )
            if ( fetchline[4] == ' ' )
	    if ( beamercode == 1 ) 
            {
              strncpy( slidemysection, strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , PATH_MAX );
  	      foundcode = 1;
            }
            */

            /////////////////////////////
            /// for beamer 
            /////////////////////////////
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
            if ( fetchline[0] == '>' )
            if ( fetchline[1] == ' ' )
            {
	      if ( beamerlevel == 1)  
	      {
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\item "  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , ""  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
	      }
	      else if ( beamerlevel == 2)  
	      {
              foxy++;//
              strncpy( slidebufferdata[foxy] , "\\end{itemize}" , PATH_MAX );
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\item "  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , ""  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////
	        beamerlevel = 1;
	      }
	      else if ( beamerlevel == 0)  
	      {
              foxy++;//
              strncpy( slidebufferdata[foxy] , "\\begin{itemize}" , PATH_MAX );
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\item "  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , ""  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////
	        beamerlevel = 1;
	      }
  	      foundcode = 1;
            }





            //////////////////////////////////
            // for beamer 
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
            if ( fetchline[0] == '*' )
            if ( fetchline[1] == ' ' )
            {
	      if ( beamerlevel == 2)  
	      {
              ///////////////
              foxy++;//
              strncpy( slidebufferdata[foxy] , "\\begin{itemize}" , PATH_MAX );
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\item "  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , ""  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////
		beamerlevel = 3;
	      }
	      else if ( beamerlevel == 3)  
	      {
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\item "  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , ""  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////
	        beamerlevel = 3;
	      }
	      else if ( beamerlevel == 1)  
	      {
              ///////////////
              foxy++;//
              strncpy( slidebufferdata[foxy] , "\\begin{itemize}" , PATH_MAX );
              foxy++;//
              strncpy( slidebufferdata[foxy] , "\\begin{itemize}" , PATH_MAX );
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\item "  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , ""  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////

	        beamerlevel = 3;
	      }
	      else if ( beamerlevel == 0)  
	      {
              ///////////////
              foxy++;//
              strncpy( slidebufferdata[foxy] , "\\begin{itemize}" , PATH_MAX );
              foxy++;//
              strncpy( slidebufferdata[foxy] , "\\begin{itemize}" , PATH_MAX );
              foxy++;//
              strncpy( slidebufferdata[foxy] , "\\begin{itemize}" , PATH_MAX );
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\item "  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , ""  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////
	        beamerlevel = 3;
	      }
  	      foundcode = 1;
            }





            /// the regular point
            /// beamer  for txt to tex !
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
            if (   (( fetchline[0] == '-' ) && ( fetchline[1] == ' ' ))
            || (( fetchline[0] == '|' )  && ( fetchline[1] == '-' ) && ( fetchline[2] == ' ' )) )   // |- blabla
            {
	     if ( beamerlevel == 1)  
	     {
              foxy++;//
              strncpy( slidebufferdata[foxy] , "\\begin{itemize}" , PATH_MAX );
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\item "  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              /////////////////////////////////
              char goofetchline[PATH_MAX];
              strncpy( goofetchline,  fetchline  , PATH_MAX);
              if ( fetchline[0] == '|' )  
                 strncat( slidebufferdata[foxy] , strtxt2tex( strtrim( strcut( goofetchline, 1+2, strlen( goofetchline )))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              else
                 strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , ""  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////

		beamerlevel = 2;
	      }
	      else if ( beamerlevel == 2)  
	      {
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\item "  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              /////////////////////////////////
              char goofetchline[PATH_MAX];
              strncpy( goofetchline,  strampersand2txt( fetchline ) , PATH_MAX);
              strncpy( goofetchline,  fetchline  , PATH_MAX);
              if ( fetchline[0] == '|' )  
                 strncat( slidebufferdata[foxy] , strtxt2tex( strtrim( strcut( goofetchline, 1+2, strlen( goofetchline )))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              else
                 strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , ""  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////

	        beamerlevel = 2;
	      }
	      else if ( beamerlevel == 3)  
	      {
              foxy++;//
              strncpy( slidebufferdata[foxy] , "\\end{itemize}" , PATH_MAX );
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\item "  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              /////////////////////////////////
              char goofetchline[PATH_MAX];
              strncpy( goofetchline,  strampersand2txt( fetchline ) , PATH_MAX);
              strncpy( goofetchline,  fetchline  , PATH_MAX);
              if ( fetchline[0] == '|' )  
                 strncat( slidebufferdata[foxy] , strtxt2tex( strtrim( strcut( goofetchline, 1+2, strlen( goofetchline )))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              else
                 strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , ""  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////
	        beamerlevel = 2;
	      }
	      else if ( beamerlevel == 0)  
	      {
              ///////////////
              foxy++;//
              strncpy( slidebufferdata[foxy] , "\\begin{itemize}" , PATH_MAX );
              foxy++;//
              strncpy( slidebufferdata[foxy] , "\\begin{itemize}" , PATH_MAX );
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\item "  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              /////////////////////////////////
              char goofetchline[PATH_MAX];
              strncpy( goofetchline,  strampersand2txt( fetchline ) , PATH_MAX);
              strncpy( goofetchline,  fetchline  , PATH_MAX);
              if ( fetchline[0] == '|' )  
                 strncat( slidebufferdata[foxy] , strtxt2tex( strtrim( strcut( goofetchline, 1+2, strlen( goofetchline )))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              else
                 strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , ""  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////
	        beamerlevel = 2;
	      }
  	      foundcode = 1;
            }





            // !info bla for beamer
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
	    if ( beamerlevel >= 1 )
            if ( fetchline[0] == '!' ) // !info without {} is for one
            if ( fetchline[1] == 'i' )
            if ( fetchline[2] == 'n' )
            if ( fetchline[3] == 'f' )
            if ( fetchline[4] == 'o' )
            if ( fetchline[5] == ' ' )
            {
              ///////////////
              //strncpy( slidebufferfignote,  strtrim( strcut( fetchline, 5+2, strlen( fetchline ))) , PATH_MAX );
 	      //fputs( "\\textit{" , fp5 );
              //strncpy( slidebufferfignote, "\\textit{"  , PATH_MAX );
              strncpy( slidebufferfignote, "\\begin{center}\\textit{"  , PATH_MAX );
              strncat( slidebufferfignote , 
              strtrim( strcut( fetchline, 5+2, strlen( fetchline ))) 
              , PATH_MAX - strlen( slidebufferfignote  ) -1 );
              //strncat( slidebufferfignote , "}" , PATH_MAX - strlen( slidebufferfignote  ) -1 );
              strncat( slidebufferfignote , "}\\end{center}" , PATH_MAX - strlen( slidebufferfignote  ) -1 );
              slidebuffernot = 1;
  	      foundcode = 1;
            }






            // !info{ for beamer, this will be !infoab implicit, !info with {} {} is for two right and left
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
	    if ( beamerlevel >= 1 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'i' )
            if ( fetchline[2] == 'n' )
            if ( fetchline[3] == 'f' )
            if ( fetchline[4] == 'o' )
            if ( fetchline[5] == '{' )
            {
              if ( markup_language == 3 )
              {
                ///////////////
                strncpy( slidebufferfignote,  ""  , PATH_MAX );
                strncat( slidebufferfignote , "\\begin{center}{\\small " , PATH_MAX - strlen( slidebufferfignote  ) -1 );
                strncat( slidebufferfignote , fbasenoext( strtxt2tex( strdelimit( fetchline,  '{' ,'}' ,  1 ) )) , PATH_MAX - strlen( slidebufferfignote  ) -1 );
  
                strncat( slidebufferfignote , " (Links) und " , PATH_MAX - strlen( slidebufferfignote  ) -1 );
  
                strncat( slidebufferfignote , fbasenoext(strtxt2tex( strdelimit( fetchline,  '{' ,'}' ,  2 ) ) ) , PATH_MAX - strlen( slidebufferfignote  ) -1 );
  
                strncat( slidebufferfignote , " (Rechts)" , PATH_MAX - strlen( slidebufferfignote  ) -1 );
                strncat( slidebufferfignote , "}\\end{center}" , PATH_MAX - strlen( slidebufferfignote  ) -1 );
                slidebuffernot = 1;
              }
              else
              {
                ///////////////
                strncpy( slidebufferfignote,  ""  , PATH_MAX );
                strncat( slidebufferfignote , "\\begin{center}{\\small " , PATH_MAX - strlen( slidebufferfignote  ) -1 );
                //strncat( slidebufferfignote , "{\\small " , PATH_MAX - strlen( slidebufferfignote  ) -1 );
                strncat( slidebufferfignote , fbasenoext( strtxt2tex( strdelimit( fetchline,  '{' ,'}' ,  1 ) )) , PATH_MAX - strlen( slidebufferfignote  ) -1 );
  
                strncat( slidebufferfignote , " (Left) and " , PATH_MAX - strlen( slidebufferfignote  ) -1 );
  
                strncat( slidebufferfignote , fbasenoext(strtxt2tex( strdelimit( fetchline,  '{' ,'}' ,  2 ) ) ) , PATH_MAX - strlen( slidebufferfignote  ) -1 );
  
                strncat( slidebufferfignote , " (Right)" , PATH_MAX - strlen( slidebufferfignote  ) -1 );
                //strncat( slidebufferfignote , "}" , PATH_MAX - strlen( slidebufferfignote  ) -1 );
                strncat( slidebufferfignote , "}\\end{center}" , PATH_MAX - strlen( slidebufferfignote  ) -1 );
                slidebuffernot = 1;
              }
  	      foundcode = 1;
            }







            // !fig for beamer (i.e. !fig{pic.png})
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'f' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == 'g' )
            if ( fetchline[4] == '{' )
            {
              slidebufferfig = 1; 
              ///////////////
              //char foofilefound[PATH_MAX];
              //strncpy( foofilefound, strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX );
              //if ( strstr( foofilefound , "/" ) != 0 ) 
              //if ( fexist( foofilefound ) == 1 ) 
              //{
              //}
	      if ( beamerlevel >= 1 )
              {
                  // if you wanna give regular slides
                  strncpy( slidebufferfigfile, strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX );
              }
	      else if ( strcount( fetchline, '}' ) >= 2 )
	      {
                  // or, new automatic, allows to build faster slides
                  strncpy( slidebufferfigfile, strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX );
                  // after pic, bring text
                  foxy++;//
                  strncpy( slidebufferdata[foxy] , "\\begin{itemize}" , PATH_MAX );

                  foxy++;//
                  strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
                  strncat( slidebufferdata[foxy] , "\\item "  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );

                  strncat( slidebufferdata[foxy] , strdelimit( fetchline,  '{' ,'}' ,  2 )   , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
                  strncat( slidebufferdata[foxy] , ""  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
                  //foxy++;//
                  //strncpy( slidebufferdata[foxy] , "\\end{itemize}" , PATH_MAX );
                  //beamerlevel = 0;
                  beamerlevel = 1;
              }
              else 
              {
                  // in any other choices
                  strncpy( slidebufferfigfile, strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX );
              }
              ////////////////
  	      foundcode = 1;
              slidebufferfig = 1; 
            }






            // !figab for beamer
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
	    if ( beamerlevel >= 1 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'f' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == 'g' )
            if ( fetchline[4] == 'a' )
            if ( fetchline[5] == 'b' )
            if ( fetchline[6] == '{' )
            {
              ///////////////
              char foofilefound[PATH_MAX];
              strncpy( foofilefound, strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX );
              if ( strstr( foofilefound , "/" ) != 0 ) 
              {
              }
              strncpy( slidebufferfigfile1 , strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX );
              strncpy( slidebufferfigfile2 , strdelimit( fetchline,  '{' ,'}' ,  2 ) , PATH_MAX );
  	      foundcode = 1;
              slidebufferfig = 2; 
            }





            // !figat for beamer, image and text
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
	    if ( beamerlevel >= 1 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'f' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == 'g' )
            if ( fetchline[4] == 'a' )
            if ( fetchline[5] == 't' )
            if ( fetchline[6] == '{' )
            {
              ///////////////
              char foofilefound[PATH_MAX];
              strncpy( foofilefound, strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX );
              if ( strstr( foofilefound , "/" ) != 0 ) 
              {
              }
              strncpy( slidebufferfigfile1 , strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX );
              strncpy( slidebufferfigfile2 , strdelimit( fetchline,  '{' ,'}' ,  2 ) , PATH_MAX );
  	      foundcode = 1;
              slidebufferfig = 3; 
            }





            // !textfig for beamer
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
	    if ( beamerlevel >= 1 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 't' )
            if ( fetchline[2] == 'e' )
            if ( fetchline[3] == 'x' )
            if ( fetchline[4] == 't' )
            if ( fetchline[5] == 'f' )
            if ( fetchline[6] == 'i' )
            if ( fetchline[7] == 'g' )
            if ( fetchline[8] == '{' )
            {
              slidebufferfig = 1; 
              ///////////////
              char foofilefound[PATH_MAX];
              strncpy( foofilefound, strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX );
              if ( strstr( foofilefound , "/" ) != 0 ) 
              if ( fexist( foofilefound ) == 1 ) 
              {
              }
              strncpy( slidebufferfigfile, strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX );
  	      foundcode = 1;
              slidebufferfig = 4; 
            }






            // !maketitle
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
            if ( fetchcmdline[0] == '!' )
            if ( fetchcmdline[1] == 'm' )
            if ( fetchcmdline[2] == 'a' )
            if ( fetchcmdline[3] == 'k' )
            if ( fetchcmdline[4] == 'e' )
            if ( fetchcmdline[5] == 't' )
            if ( fetchcmdline[6] == 'i' )
            if ( fetchcmdline[7] == 't' )
            if ( fetchcmdline[8] == 'l' )
            if ( fetchcmdline[9] == 'e' )
            {
              ///////////////
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\begin{frame}\\maketitle\\end{frame}"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////
  	      foundcode = 1;
            }




            // !box
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'b' )
            if ( fetchline[2] == 'o' )
            if ( fetchline[3] == 'x' )
            if ( fetchline[4] == ' ' )
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
            {
	     if ( beamerlevel == 1)  
	     {
              foxy++;//
              strncpy( slidebufferdata[foxy] , "\\begin{itemize}" , PATH_MAX );
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\item \\boxed{"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              /////////////////////////////////
              char goofetchline[PATH_MAX];
              strncpy( goofetchline,  fetchline  , PATH_MAX);
              if ( fetchline[0] == '|' )  
                 strncat( slidebufferdata[foxy] , strtxt2tex( strtrim( strcut( goofetchline, 4+2, strlen( goofetchline )))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              else
                 strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , ""  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , "}"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////

		beamerlevel = 2;
	      }

	      else if ( beamerlevel == 2)  
	      {
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\item \\boxed{"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              /////////////////////////////////
              char goofetchline[PATH_MAX];
              strncpy( goofetchline,  strampersand2txt( fetchline ) , PATH_MAX);
              strncpy( goofetchline,  fetchline  , PATH_MAX);
              if ( fetchline[0] == '|' )  
                 strncat( slidebufferdata[foxy] , strtxt2tex( strtrim( strcut( goofetchline, 4+2, strlen( goofetchline )))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              else
                 strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , ""  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , "}"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////

	        beamerlevel = 2;
	      }
	      else if ( beamerlevel == 3)  
	      {
              foxy++;//
              strncpy( slidebufferdata[foxy] , "\\end{itemize}" , PATH_MAX );
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\item \\boxed{"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              /////////////////////////////////
              char goofetchline[PATH_MAX];
              strncpy( goofetchline,  strampersand2txt( fetchline ) , PATH_MAX);
              strncpy( goofetchline,  fetchline  , PATH_MAX);
              if ( fetchline[0] == '|' )  
                 strncat( slidebufferdata[foxy] , strtxt2tex( strtrim( strcut( goofetchline, 4+2, strlen( goofetchline )))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              else
                 strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , ""  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , "}"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////
	        beamerlevel = 2;
	      }
	      else if ( beamerlevel == 0)  
	      {
              ///////////////
              foxy++;//
              strncpy( slidebufferdata[foxy] , "\\begin{itemize}" , PATH_MAX );
              foxy++;//
              strncpy( slidebufferdata[foxy] , "\\begin{itemize}" , PATH_MAX );
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\item \\boxed{"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              /////////////////////////////////
              char goofetchline[PATH_MAX];
              strncpy( goofetchline,  strampersand2txt( fetchline ) , PATH_MAX);
              strncpy( goofetchline,  fetchline  , PATH_MAX);
              if ( fetchline[0] == '|' )  
                 strncat( slidebufferdata[foxy] , strtxt2tex( strtrim( strcut( goofetchline, 4+2, strlen( goofetchline )))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              else
                 strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , ""  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , "}"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////
	        beamerlevel = 2;
	      }
  	      foundcode = 1;
            }
           // end of !box 





            // !equ 
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'e' )
            if ( fetchline[2] == 'q' )
            if ( fetchline[3] == 'u' )
            if ( fetchline[4] == ' ' )
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
            {
	     if ( beamerlevel == 1)  
	     {
              foxy++;//
              strncpy( slidebufferdata[foxy] , "\\begin{itemize}" , PATH_MAX );
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\item "  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              /////////////////////////////////
              char goofetchline[PATH_MAX];
              strncpy( goofetchline,  fetchline  , PATH_MAX);
              if ( fetchline[0] == '|' )  
                 strncat( slidebufferdata[foxy] , strtxt2tex( strtrim( strcut( goofetchline, 4+2, strlen( goofetchline )))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              else
                 strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , ""  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////

		beamerlevel = 2;
	      }
	      else if ( beamerlevel == 2)  
	      {
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\item "  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              /////////////////////////////////
              char goofetchline[PATH_MAX];
              strncpy( goofetchline,  strampersand2txt( fetchline ) , PATH_MAX);
              strncpy( goofetchline,  fetchline  , PATH_MAX);
              if ( fetchline[0] == '|' )  
                 strncat( slidebufferdata[foxy] , strtxt2tex( strtrim( strcut( goofetchline, 4+2, strlen( goofetchline )))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              else
                 strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , ""  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////

	        beamerlevel = 2;
	      }
	      else if ( beamerlevel == 3)  
	      {
              foxy++;//
              strncpy( slidebufferdata[foxy] , "\\end{itemize}" , PATH_MAX );
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\item "  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              /////////////////////////////////
              char goofetchline[PATH_MAX];
              strncpy( goofetchline,  strampersand2txt( fetchline ) , PATH_MAX);
              strncpy( goofetchline,  fetchline  , PATH_MAX);
              if ( fetchline[0] == '|' )  
                 strncat( slidebufferdata[foxy] , strtxt2tex( strtrim( strcut( goofetchline, 4+2, strlen( goofetchline )))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              else
                 strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , ""  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////
	        beamerlevel = 2;
	      }
	      else if ( beamerlevel == 0)  
	      {
              ///////////////
              foxy++;//
              strncpy( slidebufferdata[foxy] , "\\begin{itemize}" , PATH_MAX );
              foxy++;//
              strncpy( slidebufferdata[foxy] , "\\begin{itemize}" , PATH_MAX );
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\item "  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              /////////////////////////////////
              char goofetchline[PATH_MAX];
              strncpy( goofetchline,  strampersand2txt( fetchline ) , PATH_MAX);
              strncpy( goofetchline,  fetchline  , PATH_MAX);
              if ( fetchline[0] == '|' )  
                 strncat( slidebufferdata[foxy] , strtxt2tex( strtrim( strcut( goofetchline, 4+2, strlen( goofetchline )))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              else
                 strncat( slidebufferdata[foxy] , strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              strncat( slidebufferdata[foxy] , ""  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////
	        beamerlevel = 2;
	      }
  	      foundcode = 1;
            }
           // end of !equ 





            // !equ  (beamer)
            /*
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'e' )
            if ( fetchline[2] == 'q' )
            if ( fetchline[3] == 'u' )
            if ( fetchline[4] == ' ' )
            {
              ///////////////
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy], 
 	      strtrim( strcut( fetchline, 4+2, strlen( fetchline ))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////
  	      foundcode = 1;
            }
            */


            // !raw  (beamer)
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'r' )
            if ( fetchline[2] == 'a' )
            if ( fetchline[3] == 'w' ) // new, beta testing
            if ( fetchline[4] == ' ' )
            {
              ///////////////
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy], 
 	      strtrim( strcut( fetchline, 4+2, strlen( fetchline ))) , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////
  	      foundcode = 1;
            }



            // !linefeed (beamer)  
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'l' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == 'n' )
            if ( fetchline[4] == 'e' )
            if ( fetchline[5] == 'f' )
            if ( fetchline[6] == 'e' )
            if ( fetchline[7] == 'e' )
            if ( fetchline[8] == 'd' )
            {
              ///////////////
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\bigskip"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////
  	      foundcode = 1;
            }

            // !smallskip (beamer)
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
            if ( fetchcmdline[0] == '!' ) 
            if ( fetchcmdline[1] == 's' )
            if ( fetchcmdline[2] == 'm' )
            if ( fetchcmdline[3] == 'a' )
            if ( fetchcmdline[4] == 'l' )
            if ( fetchcmdline[5] == 'l' )
            if ( fetchcmdline[6] == 's' )
            if ( fetchcmdline[7] == 'k' )
            if ( fetchcmdline[8] == 'i' )
            if ( fetchcmdline[9] == 'p' )
            {
              ///////////////
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\smallskip"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////
  	      foundcode = 1;
            }



            // !medskip (beamer)
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
            if ( fetchcmdline[0] == '!' ) 
            if ( fetchcmdline[1] == 'm' )
            if ( fetchcmdline[2] == 'e' )
            if ( fetchcmdline[3] == 'd' )
            if ( fetchcmdline[4] == 's' )
            if ( fetchcmdline[5] == 'k' )
            if ( fetchcmdline[6] == 'i' )
            if ( fetchcmdline[7] == 'p' )
            {
              ///////////////
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\medskip"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////
  	      foundcode = 1;
            }


            

            ////////////////////////// 
            // !lxpagemark (beamer), for only BSD to fix the bug   // !lxpagemark
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'l' )
            if ( fetchline[2] == 'x' )
            if ( fetchline[3] == 'p' )
            if ( fetchline[4] == 'a' )
            if ( fetchline[5] == 'g' )
            if ( fetchline[6] == 'e' )
            if ( fetchline[7] == 'm' )
            if ( fetchline[8] == 'a' )
            if ( fetchline[9] ==  'r' )
            if ( fetchline[10] == 'k' )
            {
              if ( pagemark_mode_active == 1 ) 
              {
                if ( MYOS == 1 ) 
                {
                  pagemark_open = 1;
                }
                else 
                {
                }
                foxy++;
                strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              }
  	      foundcode = 1;
            }
            ////////////////////////// 
            ////////////////////////// 
            ////////////////////////// 




            // !pagemark (beamer), for always
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'p' )
            if ( fetchline[2] == 'a' )
            if ( fetchline[3] == 'g' )
            if ( fetchline[4] == 'e' )
            if ( fetchline[5] == 'm' )
            if ( fetchline[6] == 'a' )
            if ( fetchline[7] == 'r' )
            if ( fetchline[8] == 'k' )
            {
              if ( pagemark_mode_active == 1 ) 
              {
                pagemark_open = 1;
                foxy++;//
                strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
                ///////////////
                //strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
                //strncat( slidebufferdata[foxy] , "\\bigskip"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
                ///////////////
              }
  	      foundcode = 1;
            }





            // !bigskip (beamer)
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
            if ( fetchcmdline[0] == '!' ) 
            if ( fetchcmdline[1] == 'b' )
            if ( fetchcmdline[2] == 'i' )
            if ( fetchcmdline[3] == 'g' )
            if ( fetchcmdline[4] == 's' )
            if ( fetchcmdline[5] == 'k' )
            if ( fetchcmdline[6] == 'i' )
            if ( fetchcmdline[7] == 'p' )
            {
              ///////////////
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\bigskip"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////
  	      foundcode = 1;
            }


            //datecom-20180117-012026
            // !skip (beamer)
            /*
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
            if ( fetchcmdline[0] == '!' ) 
            if ( fetchcmdline[1] == 's' )
            if ( fetchcmdline[2] == 'k' )
            if ( fetchcmdline[3] == 'i' )
            if ( fetchcmdline[4] == 'p' )
            {
              ///////////////
              foxy++;//
              strncpy( slidebufferdata[foxy] , "" , PATH_MAX );
              strncat( slidebufferdata[foxy] , "\\bigskip"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
              ///////////////
  	      foundcode = 1;
            }*/





            // process the content of the slide
	    // closer (beamer)
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
	    if ( beamerlevel >= 1 )
	    if ( unilistemptyline >= 1 )
            {
	      printf ( " Found unilistemptyline (closer): beamer level %d \n", beamerlevel );
              if ( strcmp( slidebufferdata[foxy] , "" ) == 0 ) foxy--;   //attention
	      for ( fooi = 1 ; fooi <= beamerlevel ; fooi++)
	      {
                 foxy++;//
                 strncpy( slidebufferdata[foxy] , "\\end{itemize}" , PATH_MAX );
	      }







              //////////////////////////////////////////////
              // let's begin
              // let's begin to place the lines of slide content
              //////////////////////////////////////////////
              slidebufferfoundsection = 0;
	      for ( fooi = 1 ; fooi <= foxy ; fooi++)
	      {
                   if ( strstr( slidebufferdata[ fooi ] , "\\frametitle" ) != 0 )
                   if ( slidebufferdata[ fooi ][0] != '%' ) 
                   {
                      printf( "a frametitle found.\n" );
                      slidebufferfoundsection = 1;
                   }
              }



              if ( strcmp( slidemysection , "" ) != 0 )
              {
                      fputs( "\n" , fp5 );
                      fputs( "\%slidemysectionslide\n" , fp5 );
                      fputs( "\\section{"  , fp5 );
                      fputs( slidemysection , fp5 );
                      fputs( "}\n"  , fp5 );
              }
             



              ////////////////////////////////////////////////
              /// loop according to line content
	      printf ( " Print out foxy \n" );
	      for ( fooi = 1 ; fooi <= foxy ; fooi++)
	      {
                 fputs( slidebufferdata[ fooi ] , fp5 );

                 if ( slidebufferfig >= 1 )
                 if ( strcmp( slidebufferdata[ fooi ] , "\\begin{frame}" ) == 0 ) //ok
                 {
                      fputs( "\n" , fp5 );
                      if ( slidebufferfig == 1 )
                         fputs( "\\fitimage{"  , fp5 );    // one pic
                      else if ( slidebufferfig == 2 )
                         fputs( "\\fitimageab{"  , fp5 );  // two pics
                      else if ( slidebufferfig == 3 )
                         fputs( "\\fitimageat{"  , fp5 );  // pic and text
                      else if ( slidebufferfig == 4 )
                         fputs( "\\textfig{"  , fp5 );  // pic and text
                 }


                 if ( slidebufferfoundsection == 0 ) 
                 {
                      fputs(  "\n" , fp5 );
                      fputs(  "\\frametitle{\\thesection.~\\insertsection}"  , fp5 );
                      slidebufferfoundsection = 1; 
                 }
                 fputs( "\n" , fp5 );
	      } // end of loop



              if ( slidebufferfig == 4 ) //textfig
              {
                foxy++;//
                fputs( "\\begin{minipage}{0.5\\textwidth}\n" , fp5 );
                strncpy( slidebufferdata[foxy] , "\\includegraphics[width=\\textwidth]{" , PATH_MAX );
                strncat( slidebufferdata[foxy] ,  slidebufferfigfile  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 ); 
                strncat( slidebufferdata[foxy] , "}"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
                fooi = foxy ; 
                fputs( slidebufferdata[ fooi ] , fp5 );
                fputs( "\n" , fp5 );
                fputs( "\\end{minipage}\n" , fp5 );
                slidebufferfig=0;
              } 


              /// add fig fitimage if indicated
              if ( ( slidebufferfig == 1 ) || ( slidebufferfig == 4 ))
	      {
                if ( pagemark_open == 1 ) 
                {
                     fputs( "\\pagemark\n" , fp5 ); pagemark_open = 0 ; 
                }
                // one file
                foxy++;//
                strncpy( slidebufferdata[foxy] , "}{" , PATH_MAX );
                strncat( slidebufferdata[foxy] ,  slidebufferfigfile  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 ); 
                strncat( slidebufferdata[foxy] , "}["  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
                if ( slidebuffernot == 1 ) strncat( slidebufferdata[foxy] , slidebufferfignote  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
                strncat( slidebufferdata[foxy] , "]"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );

                fooi = foxy ; 
                fputs( slidebufferdata[ fooi ] , fp5 );
                fputs( "\n" , fp5 );
                slidebufferfig=0;
	      }

              else if (( slidebufferfig == 2 ) || ( slidebufferfig == 3 ))
	      {
                if ( pagemark_open == 1 ) { fputs( "\\pagemark\n" , fp5 ); pagemark_open = 0 ; }
                // two files
                foxy++;//
                strncpy( slidebufferdata[foxy] , "}{" , PATH_MAX );
                strncat( slidebufferdata[foxy] ,  slidebufferfigfile1  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 ); 
                strncat( slidebufferdata[foxy] , "}"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
                strncat( slidebufferdata[foxy] ,  "{"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 ); 
                strncat( slidebufferdata[foxy] ,  slidebufferfigfile2  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 ); 
                strncat( slidebufferdata[foxy] , "}["  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
                if ( slidebuffernot == 1 ) strncat( slidebufferdata[foxy] , slidebufferfignote  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );
                strncat( slidebufferdata[foxy] , "]"  , PATH_MAX - strlen( slidebufferdata[foxy]  ) -1 );

                fooi = foxy ; 
                fputs( slidebufferdata[ fooi ] , fp5 );
                fputs( "\n" , fp5 );
                slidebufferfig=0;
	      }


              /// close the frame
              if ( pagemark_open == 1 )  fputs( "\\pagemark\n" , fp5 );
 	      fputs( "\\end{frame}\n" , fp5 );
 	      fputs( "\n" , fp5 );
 	      fputs( "\n" , fp5 );

              /// reset slide values
              foxy = 0;
              slidebufferfig=0;
              slidebuffernot=0;
              pagemark_open = 0;
              strncpy( slidemysection, "", PATH_MAX );

	      beamerlevel = 0;
  	      foundcode = 1;
            }
            //// debugger
	    if ( beamerlevel <= 0 ) beamerlevel = 0;
      }
     // end of beamer
     // end of beamer







            // !hline  some html 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'h' )
            if ( fetchline[2] == 'l' )
            if ( fetchline[3] == 'i' )
            if ( fetchline[4] == 'n' )
            if ( fetchline[5] == 'e' )
            {
 	      fputs( "\\clearpage" , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }


            // !rem for a remark 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'r' )
            if ( fetchline[2] == 'e' )
            if ( fetchline[3] == 'm' )
            if ( fetchline[4] == ' ' )
            {
               foundcode = 1;
            }





         ///////////////////////////////////////
         /// SOME HTML  !url 
         ///////////////////////////////////////
            if ( foundcode == 0 )
            if ( markup_output_format == 2 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'u' )
            if ( fetchline[2] == 'r' )
            if ( fetchline[3] == 'l' )
            if ( fetchline[4] == ' ' )
            {
 	       fputs( "<a href=\"" , fp5 );
 	       fputs( strtrim( strcut( fetchline, 4+2, strlen( fetchline ))) , fp5 );
 	       fputs( "\">" , fp5 );
 	       fputs( "Link" , fp5 );
 	       fputs( "</a>" , fp5 );
  	       fputs( "<br>\n", fp5 );
               foundcode = 1;
            }











        ///////////////////////////////////////
        ///////////////////////////////////////
        // begin of html
        // begin of html
        ///////////////////////////////////////
        ///////////////////////////////////////
        ///////////////////////////////////////
        //Bullet list: (!ul)  <ul>
        //Numbered list: (!ol)  <ol>
        ///////////////////////////////////////
        /// SOME HTML !! ul li 
        ///////////////////////////////////////
            if ( foundcode == 0 )
            if ( markup_output_format == 2 ) // html 
            if ( fetchline[0] == '-' )
            if ( fetchline[1] == ' ' )
            {
	     if ( itemlevel == 1)  
             {
 	        fputs( "<li>" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 1+2, strlen( fetchline ))) , fp5 );
  	        fputs( "</li>\n", fp5 );
             }
             foundcode = 1;
           }
          ///////////////////////////////////////
          ///////////////////////////////////////
          ///////////////////////////////////////
           if ( foundcode == 0 )
           if ( markup_output_format == 2 )  //html 
           if ( fetchline[0] == '>' )
           if ( fetchline[1] == ' ' )
           {
	     if ( itemlevel == 0)  
             {
 	        fputs( "<ul>" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 1+2, strlen( fetchline ))) , fp5 );
  	        fputs( "\n", fp5 );
                itemlevel = 1 ;
             }
             foundcode = 1;
          }
          ///////////////////////////////////////
	  // item closer 
          ///////////////////////////////////////
            if ( foundcode == 0 )
            if ( markup_output_format == 2 ) //html 
	    if ( itemlevel >= 1 )
            if ( fetchline[0] != '\\' )
            if ( fetchline[0] != '!' )
            {
	      for ( fooi = 1 ; fooi <= itemlevel ; fooi++)
	      {
 	         fputs( "</ul>\n" , fp5 );
	      }
 	      fputs( "\n" , fp5 );
 	      fputs( "\n" , fp5 );
	      itemlevel = 0;
  	      foundcode = 1;
           }
         ///////////////////////////////////////
     // end of html
     // end of html










          ///////////////////////////////////////
          ///////////////////////////////////////
          ///////////////////////////////////////
          ///////////////////////////////////////
          ///////////////////////////////////////
            if ( foundcode == 0 )
            if ( markup_output_format == 3 )
            if ( fetchline[0] == '-' )
            if ( fetchline[1] == ' ' )
            {
	     if ( itemlevel == 1)  
             {
 	        fputs( "\\iexitem{" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 1+2, strlen( fetchline ))) , fp5 );
  	        fputs( "}", fp5 );
  	        fputs( "\n", fp5 );
             }
             foundcode = 1;
           }
          ///////////////////////////////////////
          ///////////////////////////////////////
          ///////////////////////////////////////
          ///////////////////////////////////////
           if ( foundcode == 0 )
           if ( markup_output_format == 3 ) //fleche
           if ( fetchline[0] == '>' )
           if ( fetchline[1] == ' ' )
           {
	     if ( itemlevel == 0)  
             {
 	        fputs( "\\iexfleche{{\\bfseries " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 1+2, strlen( fetchline ))) , fp5 );
  	        fputs( "}}\n", fp5 );
  	        fputs( "\\iexitembegin\n", fp5 );
                itemlevel = 1 ;
             }
             foundcode = 1;
          }
          ///////////////////////////////////////
          ///////////////////////////////////////
	  // item closer 
          ///////////////////////////////////////
          ///////////////////////////////////////
            if ( foundcode == 0 )
            if ( markup_output_format == 3 )
	    if ( itemlevel >= 1 )
            if ( fetchline[0] != '\\' )
            if ( fetchline[0] != '!' )
            {
	      for ( fooi = 1 ; fooi <= itemlevel ; fooi++)
	      {
 	         fputs( "\\iexitemend\n" , fp5 );
	      }
 	      fputs( "\n" , fp5 );
 	      fputs( "\n" , fp5 );
	      itemlevel = 0;
  	      foundcode = 1;
           }
         ///////////////////////////////////////
         // end of !exam
         ///////////////////////////////////////
         ///////////////////////////////////////
         ///////////////////////////////////////








            /////////////////////////////////////////////////////////////////
            if ( notercode == 1 ) 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == '=' ) 
            if ( fetchline[2] == ' ' ) 
            {
 	        fputs( "\%section249\n" , fp5 );
 	        fputs( "\\section{" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 2+2, strlen( fetchline ))) , fp5 );
  	        fputs( "}\n", fp5 );
  	      foundcode = 1;
            }







            /////////////////////////////
            /////////////////////////////
            /// notercode
            /////////////////////////////
            /////////////////////////////
            if ( notercode == 1 ) 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )  // !section 
            if ( fetchline[1] == 's' ) 
            if ( fetchline[2] == 'e' ) 
            if ( fetchline[3] == 'c' ) 
            if ( fetchline[4] == 't' ) 
            if ( fetchline[5] == 'i' ) 
            if ( fetchline[6] == 'o' ) 
            if ( fetchline[7] == 'n' ) 
            if ( fetchline[8] == ' ' ) 
            {
	        //if ( beamercode == 1 ) 
                fputs( "\%mysectioncontent251\n" , fp5 );
 	        fputs( "\\section{" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 8+2, strlen( fetchline ))) , fp5 );
  	        fputs( "}\n", fp5 );
  	        foundcode = 1;
            }


            /////////////////////////////
            /////////////////////////////
            if ( notercode == 1 ) 
            if ( foundcode == 0 )   // mysection 
            if ( fetchline[0] == '\\' ) 
            if ( fetchline[1] == 'm' ) 
            if ( fetchline[2] == 'y' ) 
            if ( fetchline[3] == 's' ) 
            if ( fetchline[4] == 'e' ) 
            if ( fetchline[5] == 'c' ) 
            if ( fetchline[6] == 't' ) 
            if ( fetchline[7] == 'i' ) 
            if ( fetchline[8] == 'o' ) 
            if ( fetchline[9] == 'n' ) 
            if ( fetchline[10] == '{' ) 
            {
 	        fputs( "\%section252\n" , fp5 );
  	        fputs( "\\section{", fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	        fputs( "}\n", fp5 );
  	        foundcode = 1;
            }








            /////////////////////////////
            /////////////////////////////
            //////// notercode
            /////////////////////////////
            /////////////////////////////
            if ( notercode == 1 ) 
            if ( foundcode == 0 ) // !note bla   , activated with !noter 
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'n' ) 
            if ( fetchline[2] == 'o' ) 
            if ( fetchline[3] == 't' ) 
            if ( fetchline[4] == 'e' ) 
            if ( fetchline[5] == ' ' ) 
            {
  	      fputs( "- ", fp5 );
 	      fputs( strtrim( strcut( fetchline, 5+2, strlen( fetchline ))) , fp5 );
  	      fputs( "\\\\", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }

            /////////////////////////////
            //////// notercode  \mysection{  } 
            //////// notercode
            if ( notercode == 1 ) 
            if ( foundcode == 0 ) 
            if ( fetchline[0] == '\\' ) 
            if ( fetchline[1] == 'm' ) 
            if ( fetchline[2] == 'y' ) 
            if ( fetchline[3] == 's' ) 
            if ( fetchline[4] == 'e' ) 
            if ( fetchline[5] == 'c' ) 
            if ( fetchline[6] == 't' ) 
            if ( fetchline[7] == 'i' ) 
            if ( fetchline[8] == 'o' ) 
            if ( fetchline[9] == 'n' ) 
            if ( fetchline[10] == '{' ) 
            {
 	        fputs( "\%section253\n" , fp5 );
  	        fputs( "\\section{", fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	        fputs( "}\n", fp5 );
  	        foundcode = 1;
            }


            /////////////////////////
            if ( notercode == 1 ) 
            if ( foundcode == 0 )
            {
  	      foundcode = 1;
            }
            //////// notercode
            //////// notercode
            /// anti note
            if ( notercode == 0 ) 
            if ( foundcode == 0 ) // !note bla
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'n' ) 
            if ( fetchline[2] == 'o' ) 
            if ( fetchline[3] == 't' ) 
            if ( fetchline[4] == 'e' ) 
            if ( fetchline[5] == ' ' ) 
            {
  	      foundcode = 1;
            }
     // end of noter
     // end of noter
     // end of noter
     // end of noter








    /*
            /////////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////
            if ( foundcode == 0 )  // deprecated, but ok, that's too modern
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == '=' ) 
            if ( fetchline[2] == ' ' ) 
            {
              if ( markup_output_format == 2 )
              {
 	        fputs( "<h1>" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 2+2, strlen( fetchline ))) , fp5 );
  	        fputs( "</h1>\n", fp5 );
              }
              else
              {
 	        //fputs( "\%section254\n" , fp5 );
 	        fputs( "\\section{" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 2+2, strlen( fetchline ))) , fp5 );
  	        fputs( "}\n", fp5 );
              }
  	      foundcode = 1;
            }

            /////////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////
            if ( foundcode == 0 ) // deprecated, but ok, that's too modern
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == '=' ) 
            if ( fetchline[2] == '=' ) 
            if ( fetchline[3] == ' ' ) 
            {
              if ( markup_output_format == 2 )
              {
 	        fputs( "<h2>" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 3+2, strlen( fetchline ))) , fp5 );
  	        fputs( "</h2>\n", fp5 );
              }
              else
              {
    	        fputs( "\\subsection{" , fp5 );
    	        fputs( strtrim( strcut( fetchline, 3+2, strlen( fetchline ))) , fp5 );
     	        fputs( "}\n", fp5 );
              }
  	      foundcode = 1;
            }


            /////////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////
            if ( foundcode == 0 ) // deprecated, but ok, that's too modern
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == '=' ) 
            if ( fetchline[2] == '=' ) 
            if ( fetchline[3] == '=' ) 
            if ( fetchline[4] == ' ' ) 
            {
              if ( markup_output_format == 2 )
              {
 	        fputs( "<h3>" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 4+2, strlen( fetchline ))) , fp5 );
  	        fputs( "</h3>\n", fp5 );
              }
              else
              {
    	        fputs( "\\subsubsection{" , fp5 );
    	        fputs( strtrim( strcut( fetchline, 4+2, strlen( fetchline ))) , fp5 );
     	        fputs( "}\n", fp5 );
              }
  	      foundcode = 1;
            }
           */














            ///////////////////////////////
            ///////////// regular !subsection 
            ///////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 's' )
            if ( fetchline[2] == 'u' )
            if ( fetchline[3] == 'b' )
            if ( fetchline[4] == 's' )
            if ( fetchline[5] == 'e' ) 
            if ( fetchline[6] == 'c' )
            if ( fetchline[7] == 't' )
            if ( fetchline[8] == 'i' )
            if ( fetchline[9] == 'o' )
            if ( fetchline[10] == 'n' )
            if ( fetchline[11] == ' ' )
            {
 	      fputs( "\\subsection{" , fp5 );
 	      fputs( strtrim( strcut( fetchline, 11+2, strlen(fetchline))) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }















            /////////////////////////////////////// set language
            /////////////////////////////////////// set language
            /////////////////////////////////////// set language
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( strcmp( strrlf( fetchline ) , "!:set lang=none" ) == 0 )
            {
                markup_language = 0;
  	        foundcode = 1;
            }
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( strcmp( strrlf( fetchline ) , "!:set lang=en" ) == 0 )
            {
                markup_language = 1;
  	        foundcode = 1;
            }
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( strcmp( strrlf( fetchline ) , "!:set lang=fr" ) == 0 )
            {
                markup_language = 2;
  	        foundcode = 1;
            }

            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( strcmp( strrlf( fetchline ) , "!:set lang=de" ) == 0 )
            {
                markup_language = 3;
  	        foundcode = 1;
            }






            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( strcmp( strrlf( fetchline ) , "!set item=1" ) == 0 )
            {
                markup_item = 1;
  	        foundcode = 1;
            }
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( strcmp( strrlf( fetchline ) , "!set item=2" ) == 0 )
            {
                markup_item = 2;
  	        foundcode = 1;
            }













            ///////////// !figab{myfigure.png} regular fig 
            ///////////// the regular figab to place figures side by side
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'f' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == 'g' )
            if ( fetchline[4] == 'a' )
            if ( fetchline[5] == 'b' )
            if ( fetchline[6] == '{' )
            {
  	        fputs( "\\begin{center}\n", fp5 );
  	        fputs( "\\begin{figure}\n", fp5 );
  	        fputs( "\\centering\n", fp5 );
  	        fputs( "\\includegraphics[width=0.48\\linewidth]{" , fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	        fputs( "}\n", fp5 );
  	        fputs( "~\n", fp5 );
  	        fputs( "\\includegraphics[width=0.48\\linewidth]{" , fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' ,  2 ) , fp5 );
  	        fputs( "}\n", fp5 );
  	        fputs( "\\end{figure}\n", fp5 );
  	        fputs( "\\end{center}\n", fp5 );
  	        foundcode = 1;
            }



 
            //////////////////////////////
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'r' ) 
            if ( fetchline[2] == 'a' ) 
            if ( fetchline[3] == 'w' ) 
            if ( fetchline[4] == 'l' ) 
            if ( fetchline[5] == 'i' ) 
            if ( fetchline[6] == 'n' ) 
            if ( fetchline[7] == 'e' ) 
            if ( fetchline[8] == ' ' ) 
            {
 	      fputs( strtxt2tex(  strcut( fetchline , 8+2, strlen(fetchline ))) , fp5 );
 	      //fputs( strcut( fetchline, 8+2, strlen(fetchline)) , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }




            ///////////// !fig{myfigure.png} regular fig 
            ///////////// the regular fig to place figures 
            ///////////// !fig{pic.png}{Text info}{ref for cite}
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'f' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == 'g' )
            if ( fetchline[4] == '{' )
            {
	      if ( strcount( fetchline, '}' ) >= 2 )
	      {
 	        fputs( "\\begin{figure}\n" , fp5 );
 	        fputs( "\\centering\n" , fp5 );
 	        fputs( "\\includegraphics[width=1.0\\textwidth,keepaspectratio]{" , fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	        fputs( "}\n", fp5 );

 	        fputs( "\\caption{" , fp5 );
	        //fputs( strtxt2tex( strdelimit(  fetchline  ,  '{' ,'}' , 2 ) ) , fp5 );
	        fputs(  strdelimit(  fetchline  ,  '{' ,'}' , 2 )  , fp5 );
  	        fputs( "}\n", fp5 );

                printf( "=> Previous label is %s.\n", strlabel );
                if ( strcmp( strlabel, strdelimit(  fetchline  ,  '{' ,'}' , 3 ) ) != 0 ) 
                {
  	           printf( "=> This is a new found label (%s).\n", strlabel );
                   strncpy( strlabel, strdelimit(  fetchline  ,  '{' ,'}' , 3 )  , PATH_MAX );
 	           fputs( "\\label{" , fp5 );
	           fputs( strlabel  , fp5 );
	           //fputs( strdelimit(  fetchline  ,  '{' ,'}' , 3 )  , fp5 );
  	           fputs( "}\n", fp5 );
                }
 	        fputs( "\\end{figure}\n" , fp5 );
	      }
	      else //normal
	      {
  	        fputs( "\\begin{center}\n", fp5 );
  	        fputs( "\\includegraphics[width=1.0\\textwidth]{" , fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	        fputs( "}\n", fp5 );
  	        fputs( "\\end{center}\n", fp5 );
	      }
  	      foundcode = 1;
            }


            ///////////// !float{pic.png}
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'f' )
            if ( fetchline[2] == 'l' )
            if ( fetchline[3] == 'o' )
            if ( fetchline[4] == 'a' )
            if ( fetchline[5] == 't' )
            if ( fetchline[6] == '{' )
            {
	      if ( strcount( fetchline, '}' ) >= 2 )
	      {
 	        fputs( "\%cmd float\n" , fp5 );
 	        fputs( "\\begin{figure}[H]\n" , fp5 );
 	        fputs( "\\centering\n" , fp5 );
 	        fputs( "\\includegraphics[width=1.0\\textwidth,keepaspectratio]{" , fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	        fputs( "}\n", fp5 );

 	        fputs( "\\caption{" , fp5 );
	        //fputs( strtxt2tex( strdelimit(  fetchline  ,  '{' ,'}' , 2 ) ) , fp5 );
	        fputs( strdelimit(  fetchline  ,  '{' ,'}' , 2 )  , fp5 );
  	        fputs( "}\n", fp5 );

                printf( "=> Previous label is %s.\n", strlabel );
                if ( strcmp( strlabel, strdelimit(  fetchline  ,  '{' ,'}' , 3 ) ) != 0 ) 
                {
  	           printf( "=> This is a new found label (%s).\n", strlabel );
                   strncpy( strlabel, strdelimit(  fetchline  ,  '{' ,'}' , 3 )  , PATH_MAX );
 	           fputs( "\\label{" , fp5 );
	           fputs( strlabel  , fp5 );
  	           fputs( "}\n", fp5 );
                }
 	        fputs( "\\end{figure}\n" , fp5 );
	      }
	      else //normal
	      {
  	        fputs( "\\begin{center}\n", fp5 );
  	        fputs( "\\includegraphics[width=1.0\\textwidth]{" , fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	        fputs( "}\n", fp5 );
  	        fputs( "\\end{center}\n", fp5 );
	      }
  	      foundcode = 1;
            }
            ///////////// !float{pic.png} for a quick float figure, force fig under text
          /*
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'f' )
            if ( fetchline[2] == 'l' )
            if ( fetchline[3] == 'o' )
            if ( fetchline[4] == 'a' )
            if ( fetchline[5] == 't' )
            if ( fetchline[6] == '{' )
            {
 	      fputs( "\\begin{figure}[H]\n" , fp5 );
  	      fputs( "\\begin{center}\n", fp5 );
  	      fputs( "\\includegraphics[width=1.0\\textwidth]{" , fp5 );
 	      fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	      fputs( "}\n", fp5 );
  	      fputs( "\\end{center}\n", fp5 );
  	      fputs( "\\end{figure}\n", fp5 );
  	      foundcode = 1;
            }
           */






            ///////////////////////////////////////////////////////////////////////
            ///////////////////////////////////////////////////////////////////////
            ///////////////////////////////////////////////////////////////////////
            ///////////// Unterlagen
            ///////////// Try \begin{figure}[!htb]. In nearly all cases it helps.
            ///////////// !figh{pic.png}{Text info}{ref for cite}
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'f' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == 'g' )
            if ( fetchline[4] == 'h' )
            if ( fetchline[5] == '{' )
            {
	      if ( strcount( fetchline, '}' ) >= 2 )
	      {
 	        fputs( "\\begin{figure}[!htb]\n" , fp5 );
 	        fputs( "\\centering\n" , fp5 );
 	        fputs( "\\includegraphics[height=0.33\\textheight,keepaspectratio]{" , fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	        fputs( "}\n", fp5 );

 	        fputs( "\\caption{" , fp5 );
	        fputs( strtxt2tex( strdelimit(  fetchline  ,  '{' ,'}' , 2 ) ) , fp5 );
  	        fputs( "}\n", fp5 );

 	        fputs( "\\label{" , fp5 );
	        fputs( strdelimit(  fetchline  ,  '{' ,'}' , 3 )  , fp5 );
  	        fputs( "}\n", fp5 );

 	        fputs( "\\end{figure}\n" , fp5 );
	      }
	      else //normal
	      {
  	        fputs( "\\begin{center}\n", fp5 );
  	        fputs( "\\includegraphics[height=1.0\\textheight]{" , fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	        fputs( "}\n", fp5 );
  	        fputs( "\\end{center}\n", fp5 );
	      }
  	      foundcode = 1;
            }
            ///////////////////////////////////////////////////////////////////////
            ///////////////////////////////////////////////////////////////////////
            ///////////////////////////////////////////////////////////////////////
            ///////////////////////////////////////////////////////////////////////







            ///////////// !unifig{myfigure.png} regular fig 
            ///////////// the regular fig to place figures 
     /*
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'u' )
            if ( fetchline[2] == 'n' )
            if ( fetchline[3] == 'i' )
            if ( fetchline[4] == 'f' )
            if ( fetchline[5] == 'i' )
            if ( fetchline[6] == 'g' )
            if ( fetchline[7] == '{' )
            {
	      if ( strcount( fetchline, '}' ) >= 2 )
	      {
 	        fputs( "\\unifigplus{" , fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	        fputs( "}{", fp5 );
	        fputs( strtxt2tex( strdelimit(  fetchline  ,  '{' ,'}' , 2 ) ) , fp5 );
  	        fputs( "}", fp5 );
  	        fputs( "{", fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' , 3 ) , fp5 );
		fputs( "}", fp5 );
		fputs( "{", fp5 ); //size
 	        fputs( strdelimit( fetchline,  '{' ,'}' , 4 ) , fp5 );
		fputs( "}", fp5 ); //size
		fputs( "{", fp5 ); //bottom note
 	        fputs( strdelimit( fetchline,  '{' ,'}' , 5 ) , fp5 );
		fputs( "}", fp5 ); //bottom note
  	        fputs( "\n", fp5 );
	      }
	      else
	      {
  	        fputs( "\\begin{center}\n", fp5 );
  	        fputs( "\\includegraphics[width=1.0\\textwidth]{" , fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	        fputs( "}\n", fp5 );
  	        fputs( "\\end{center}\n", fp5 );
	      }
  	      foundcode = 1;
            }
           */







            // !background{file.pdf}
            //fputs( "\\usepackage{wallpaper}\n", fp5 );
            //\CenterWallPaper{1}{background.pdf}
            if ( foundcode == 0 )
            if ( fetchline[0] ==  '!' ) 
            if ( fetchline[1] ==  'b' )
            if ( fetchline[2] ==  'a' )
            if ( fetchline[3] ==  'c' )
            if ( fetchline[4] ==  'k' ) 
            if ( fetchline[5] ==  'g' ) 
            if ( fetchline[6] ==  'r' )
            if ( fetchline[7] ==  'o' )
            if ( fetchline[8] ==  'u' )
            if ( fetchline[9] ==  'n' )
            if ( fetchline[10] == 'd' )
            if ( fetchline[11] == '{' )
            {
  	      fputs( "\\CenterWallPaper{1}{", fp5 );
 	      fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }





            // !ref 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'r' )
            if ( fetchline[2] == 'e' )
            if ( fetchline[3] == 'f' )
            if ( fetchline[4] == '{' )
            {
  	        fputs( "\\ref{" , fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	        fputs( "}\n", fp5 );
  	        foundcode = 1;
            }
            // !cite 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'c' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == 't' )
            if ( fetchline[4] == 'e' )
            if ( fetchline[5] == '{' )
            {
  	        fputs( "\\cite{" , fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	        fputs( "}\n", fp5 );
  	        foundcode = 1;
            }



            ///////////// !img[0.5]{ } 
            ///////////// !img[0.5]{image.png}  with 0.5 is the reduction level (width)
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'i' )
            if ( fetchline[2] == 'm' )
            if ( fetchline[3] == 'g' )
            if ( fetchline[4] == '[' )
            {
  	        fputs( "\\begin{center}\n", fp5 );
                //id-20191121-101719
  	        //fputs( "\\includegraphics[scale,height=" , fp5 );      removed because scale does not work on netbsd 
  	        fputs( "\\includegraphics[height=" , fp5 );
 	        fputs( strdelimit( fetchline,  '[' ,']' ,  1 ) , fp5 );
                fputs( "\\textheight]{" , fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	        fputs( "}\n", fp5 );
  	        fputs( "\\end{center}\n", fp5 );
  	        //fputs( "\\includegraphics[scale=" , fp5 );
  	        //fputs( "]{" , fp5 );
 	        //fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	        //fputs( "}\n", fp5 );
  	        foundcode = 1;
            }






               ////////////////////////////
               // !maths 
               ////////////////////////////
               if ( foundcode == 0 )
               if (  ( fetchline[ 0 ] == '!' ) 
               &&  ( fetchline[ 1 ] == 'm' ) 
               &&  ( fetchline[ 2 ] == 'a' ) 
               &&  ( fetchline[ 3 ] == 't' ) 
               &&  ( fetchline[ 4 ] == 'h' ) 
               &&  ( fetchline[ 5 ] == 's' ) 
               )
               {
                 fputs( "\\usepackage{amsmath}\n" , fp5);
                 fputs( "\\usepackage{graphicx}\n" , fp5);
                 fputs( "\\usepackage{epstopdf}\n" , fp5);
                 fputs( "\n" , fp5);
                 foundcode = 1;
               }


            ///////////// !img 
            ///////////// !img image.png, fast workaround 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'i' )
            if ( fetchline[2] == 'm' )
            if ( fetchline[3] == 'g' )
            if ( fetchline[4] == ' ' )
            {
  	        //fputs( "\\includegraphics[scale]{" , fp5 );
  	        fputs( "\\includegraphics[]{" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , fp5 );
  	        fputs( "}\n", fp5 );
  	      foundcode = 1;
            }


            //////////////////////////////
            /// simple use for publis
            //  \includegraphics[width=1\textwidth]{
            ///////////// !img{
            ///////////// !img{image.png}
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'i' )
            if ( fetchline[2] == 'm' )
            if ( fetchline[3] == 'g' )
            if ( fetchline[4] == '{' )
            {
  	        //fputs( "\\includegraphics[scale]{" , fp5 );
  	        //fputs( "\\includegraphics[width=1\\textwidth]{" , fp5 );
 	        //fputs( strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , fp5 );
  	        //fputs( "}\n", fp5 );
  	        //fputs( "\\begin{center}\n", fp5 );
  	        fputs( "\\includegraphics[width=1.0\\textwidth]{" , fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	        fputs( "}\n", fp5 );
  	        //fputs( "\\end{center}\n", fp5 );
  	        foundcode = 1;
            }





            if ( foundcode == 0 ) //!imgm pic.png
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'i' )
            if ( fetchline[2] == 'm' )
            if ( fetchline[3] == 'g' )
            if ( fetchline[4] == 'm' )
            if ( fetchline[5] == ' ' )
            {
  	        fputs( "\\includegraphics[height=90mm]{" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 5+2, strlen(fetchline))) , fp5 );
  	        fputs( "}\n", fp5 );
  	      foundcode = 1;
            }





            ///////////// !bfig 
            //id-20191006-234031  beginfigure 
            ///////////// !bfig{image.png}  to make a begin figure, to have it well in center
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'b' )
            if ( fetchline[2] == 'f' )
            if ( fetchline[3] == 'i' )
            if ( fetchline[4] == 'g' )
            if ( fetchline[5] == '{' )
            {
  	        //fputs( "\\includegraphics[]{" , fp5 );
 	        //fputs( strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , fp5 );
  	        //fputs( "}\n", fp5 );
  	        fputs( "\\begin{figure}\n", fp5 );    /// this is added to have it in center of !tex 
  	        fputs( "\\includegraphics[width=1.0\\textwidth]{" , fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	        fputs( "}\n", fp5 );
  	        fputs( "\\end{figure}\n", fp5 );
  	      foundcode = 1;
            }




            // !equ equation with number and line feed, for maths.
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'e' )
            if ( fetchline[2] == 'q' )
            if ( fetchline[3] == 'u' )
            if ( fetchline[4] == ' ' )
            {
	       if ( itemlevel >= 1)  
               {
  	         fputs( "\\item[ ] ", fp5 );
  	         fputs( "\\begin{center}", fp5 );
 	         fputs(  strcut( fetchline, 4+2, strlen(fetchline)) , fp5 );
  	         fputs( "\\end{center}", fp5 );
  	         fputs( "\n", fp5 );
               }
               else
               {
  	         fputs( "\\begin{center}", fp5 );
 	         fputs(  strcut( fetchline, 4+2, strlen(fetchline)) , fp5 );
  	         fputs( "\\end{center}", fp5 );
  	         fputs( "\n", fp5 );
               }
  	      foundcode = 1;
            }






            // !box equation with number and line feed, for maths.
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'b' )
            if ( fetchline[2] == 'o' )
            if ( fetchline[3] == 'x' )
            if ( fetchline[4] == ' ' )
            {
	       if ( itemlevel >= 1)  
               {
  	         fputs( "\\item[ ] ", fp5 );
  	         fputs( "\\begin{center}", fp5 );
  	         fputs( "\\boxed{", fp5 );
 	         fputs(  strcut( fetchline, 4+2, strlen(fetchline)) , fp5 );
  	         fputs( "}", fp5 );
  	         fputs( "\\end{center}", fp5 );
  	         fputs( "\n", fp5 );
               }
               else
               {
  	         fputs( "\\begin{center}", fp5 );
  	         fputs( "\\boxed{", fp5 );
 	         fputs(  strcut( fetchline, 4+2, strlen(fetchline)) , fp5 );
  	         fputs( "}", fp5 );
  	         fputs( "\\end{center}", fp5 );
  	         fputs( "\n", fp5 );
               }
  	      foundcode = 1;
            }




            ////////////////////////////////////////////////////////////
            //\includegraphics[angle=270,origin=c,width=1.0\textwidth]{20190323_080841.jpg}
            ///////////// !figr fig.png Quick fig !! (workaround), quick workaround for right rotate
            ///////////// !figr myfigure.png  //this is a fast fig 
            // widely used!
            ////////////////////////////////////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'f' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == 'g' )
            if ( fetchline[4] == 'r' )
            if ( fetchline[5] == ' ' )
            {
  	        fputs( "\\begin{center}\n", fp5 );
                fputs( "\\includegraphics[angle=270,origin=c,width=1.0\\textwidth]{", fp5 );
  	        /////fputs( "\\includegraphics[width=1.0\\textwidth]{" , fp5 );
 	        fputs( strcut( fetchline, 5+2, strlen(fetchline)) , fp5 );
  	        fputs( "}\n", fp5 );
  	        fputs( "\\end{center}\n", fp5 );
  	        foundcode = 1;
            }



            ///////////// !fig fig.png Quick fig !! (workaround), quick workaround
            ///////////// !fig myfigure.png  //this is a fast fig 
            // widely used!
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'f' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == 'g' )
            if ( fetchline[4] == ' ' )
            {
  	        fputs( "\\begin{center}\n", fp5 );
  	        fputs( "\\includegraphics[width=1.0\\textwidth]{" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , fp5 );
  	        fputs( "}\n", fp5 );
  	        fputs( "\\end{center}\n", fp5 );
  	      foundcode = 1;
            }









            ///////////// !figr fig.png Quick fig !! (workaround), quick workaround
            ///////////// !figr myfigure.png  //this is a fast fig 
            // widely used!
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'f' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == 'g' )
            if ( fetchline[4] == 'r' )
            if ( fetchline[5] == ' ' )
            {
  	        fputs( "\\begin{center}\n", fp5 );
  	        fputs( "\\includegraphics[angle=90,width=1.0\\textwidth]{" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 5+2, strlen(fetchline))) , fp5 );
  	        fputs( "}\n", fp5 );
  	        fputs( "\\end{center}\n", fp5 );
  	      foundcode = 1;
            }



            //![kittens!](http://placekitten.com/400/500 "Kitten from placekitten.com")
            // !()[] quick markdown workaround for figs
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == '[' )
            if ( strstr( fetchline , "]" ) != 0 ) 
            if ( strstr( fetchline , ")" ) != 0 ) 
            if ( strstr( fetchline , "(" ) != 0 ) 
            {
  	        fputs( "\\begin{center}\n", fp5 );
  	        fputs( "\\includegraphics[width=1.0\\textwidth]{" , fp5 );
 	        //fputs( strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , fp5 );
                fputs( strdelimit( fetchline,  '(' ,')' ,  1 ) , fp5 );
  	        fputs( "}\n", fp5 );
  	        fputs( "\\end{center}\n", fp5 );
  	      foundcode = 1;
            }





            if ( foundcode == 0 ) // !url{ }
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'u' )
            if ( fetchline[2] == 'r' )
            if ( fetchline[3] == 'l' )
            if ( fetchline[4] == '{' )
            {
 	       fputs( "\\url{" , fp5 );
 	       fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	       fputs( "}\n", fp5 );
               foundcode = 1;
            }


            ///////////// !pagemark in text mode 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'p' )
            if ( fetchline[2] == 'a' )
            if ( fetchline[3] == 'g' )
            if ( fetchline[4] == 'e' )
            if ( fetchline[5] == 'm' )
            if ( fetchline[6] == 'a' )
            if ( fetchline[7] == 'r' )
            if ( fetchline[8] == 'k' )
            {
               printf( "==>No pagemark, %d\n", pagemark_mode_active );
               if ( pagemark_mode_active == 0 ) 
               {
               }
               else
               {
                   /// to be added somehow
               }
  	       foundcode = 1;
            } 



            /////////////////////////////
            /////////////////////////////
            ///////////////////////////// for items, tabbed
            ///////////////////////////// !tab 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 't' )
            if ( fetchline[2] == 'a' )
            if ( fetchline[3] == 'b' )
            if ( fetchline[4] == ' ' )
            {
	      if ( numberinglevel == 1)  
	      {
       	        fputs( "\\item[ ] " , fp5 );
       	        fputs( strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , fp5 );
       	        fputs( "\n" , fp5 );
		numberinglevel = 1;
	      }
	      else if ( numberinglevel == 0)  
	      {
       	        fputs( "\\item[ ] " , fp5 );
       	        fputs( strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , fp5 );
       	        fputs( "\n" , fp5 );
		numberinglevel = 1;
	      }
 	      foundcode = 1;
            }





















            ////////////////////////
            //////// SIMPLE ITEMS
            /// !ol wash, it may remind you HTML !
            // Numbered list: (!ol)
            ////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'o' )  // for Ordered!
            if ( fetchline[2] == 'l' ) 
            if ( fetchline[3] == ' ' )
	    {
	        if ( itemlevel == 1) fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item[{\\bfseries " , fp5 );
                fooc = snprintf( fooccharo, 50 , "%d", mynumber );
 	        fputs( fooccharo , fp5 );
 	        fputs( ".}]{" , fp5 );
 	        fputs( strcut( fetchline, 3+2, strlen(fetchline)) , fp5 );
                fputs( "}" , fp5 );
 	        fputs( "\n" , fp5 );
                mynumber++;
                itemlevel = 2;
  	        foundcode = 1;
            }
            ////////////////////////
            //////// SIMPLE ITEMS
            /// !ul for bullet, it may remind you HTML !
            /// Bullet list: (!ul)
            ////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'u' ) // for bUllets
            if ( fetchline[2] == 'l' ) 
            if ( fetchline[3] == ' ' )
	    {
	        if ( itemlevel == 1) fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strcut( fetchline, 3+2, strlen(fetchline)) , fp5 );
 	        fputs( "\n" , fp5 );
                itemlevel = 2;
  	        foundcode = 1;
            }
            ////////////////////////
            //////// SIMPLE ITEMS
            /// !nu for none (null), no bullet, it may remind you HTML !
            /// null label list: (!nu)
            ////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'n' ) // for Null
            if ( fetchline[2] == 'u' ) 
            if ( fetchline[3] == ' ' )
	    {
	        if ( itemlevel == 1) fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item[]{" , fp5 );
 	        fputs( strcut( fetchline, 3+2, strlen(fetchline)) , fp5 );
 	        fputs( "}" , fp5 );
 	        fputs( "\n" , fp5 );
                itemlevel = 2;
  	        foundcode = 1;
            }










            /////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '>' )  //regular one 
            if ( fetchline[1] == ' ' )
            {
              mynumber = 1;
	      if ( itemlevel == 1)  
	      {
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
	      }
	      else if ( itemlevel == 2)  
	      {
 	        fputs( "\\end{itemize}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
	        itemlevel = 1;
	      }
	      else if ( itemlevel == 3)  
	      {
 	        fputs( "\\end{itemize}\n" , fp5 );
 	        fputs( "\\end{itemize}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
	        itemlevel = 1;
	      }
	      else if ( itemlevel == 0)  
	      {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
	        itemlevel = 1;
	      }
  	      foundcode = 1;
             }


            /////////////////////////////
            /////////////////////////////
            /////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )  //regular one, !bull historically kept.
            if ( fetchline[1] == 'b' )  
            if ( fetchline[2] == 'u' )  
            if ( fetchline[3] == 'l' )  
            if ( fetchline[4] == 'l' )
            if ( fetchline[5] == ' ' )
            {
              mynumber = 1;
	      if ( itemlevel == 1)  
	      {
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 5+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
	      }
	      else if ( itemlevel == 2)  
	      {
 	        fputs( "\\end{itemize}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 5+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
	        itemlevel = 1;
	      }
	      else if ( itemlevel == 3)  
	      {
 	        fputs( "\\end{itemize}\n" , fp5 );
 	        fputs( "\\end{itemize}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 5+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
	        itemlevel = 1;
	      }
	      else if ( itemlevel == 0)  
	      {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( "{\\bfseries " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 5+2, strlen(fetchline))) , fp5 );
 	        fputs( "}" , fp5 );
 	        fputs( "\n" , fp5 );
	        itemlevel = 1;
	      }
  	      foundcode = 1;
             }











            /// new!
            if ( foundcode == 0 )
            if ( fetchline[0] == '*' )
            if ( fetchline[1] == ' ' )
            {
	      if ( itemlevel == 1)  
	      {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
		itemlevel = 3;
	      }
	      else if ( itemlevel == 2)  
	      {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
		itemlevel = 3;
	      }
	      else if ( itemlevel == 3)  
	      {
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
	        itemlevel = 3;
	      }
	      else if ( itemlevel == 4)  
	      {
 	        fputs( "\\end{itemize}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
	        itemlevel = 3;
	      }
	      else if ( itemlevel == 0)  
	      {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
	        itemlevel = 3;
	      }
  	      foundcode = 1;
            }



            /// kinda for looking like tabulation for items 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 't' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == ' ' )
            {
	      if ( itemlevel == 1)  
	      {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item[ ] " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 3+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
		itemlevel = 2;
	      }
	      else if ( itemlevel == 2)  
	      {
 	        fputs( "\\item[ ] " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 3+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
	        itemlevel = 2;
	      }
	      else if ( itemlevel == 3)  
	      {
 	        fputs( "\\end{itemize}\n" , fp5 );
 	        fputs( "\\item[ ] " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 3+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
	        itemlevel = 2;
	      }
	      else if ( itemlevel == 0)  
	      {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item[ ] " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 3+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
	        itemlevel = 2;
	      }
  	      foundcode = 1;
            }






         ///////////////////////////////////////
         ///////////////////////////////////////
         ///////////////////////////////////////
         ///////////////////////////////////////
         ///////////////////////////////////////
            /// old and ok
            if ( foundcode == 0 )
            if ( fetchline[0] == '-' )
            if ( fetchline[1] == ' ' )
            {
	      if ( itemlevel == 1)  
	      {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , fp5 );
                if ( markup_item == 2 ) fputs( " (3 Pkt.)" , fp5 );
 	        fputs( "\n" , fp5 );
		itemlevel = 2;
	      }
	      else if ( itemlevel == 2)  
	      {
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , fp5 );
                if ( markup_item == 2 ) fputs( " (3 Pkt.)" , fp5 );
 	        fputs( "\n" , fp5 );
	        itemlevel = 2;
	      }
	      else if ( itemlevel == 3)  
	      {
 	        fputs( "\\end{itemize}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
	        itemlevel = 2;
	      }
	      else if ( itemlevel == 0)  
	      {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
	        itemlevel = 2;
	      }
  	      foundcode = 1;
            }
	    // the most important: the item closer  (old item, but very stable)
            if ( foundcode == 0 )
	    if ( itemlevel >= 1 )
            if ( fetchline[0] != '\\' )
            if ( fetchline[0] != '!' )
            if ( fetchline[0] != '|' )
            {
	      for ( fooi = 1 ; fooi <= itemlevel ; fooi++)
	      {
	         fputs( "\\end{itemize}\n" , fp5 );
	      }
 	      ///fputs( "\n" , fp5 );   <--bugfix
 	      fputs( "\n" , fp5 );
	      itemlevel = 0;
  	      foundcode = 1;
            }
         ///////////////////////////////////////
         ///////////////////////////////////////
         ///////////////////////////////////////
         ///////////////////////////////////////
         ///////////////////////////////////////


           ////////////////////////////////////
            /// old and ok
            if ( foundcode == 0 )
            if ( fetchline[0] == '|' )
            if ( fetchline[1] == '-' )
            if ( fetchline[2] == ' ' )
            {
	      if ( itemlevel == 1)  
	      {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs(  strtxt2tex(strtrim( strcut( fetchline, 2+2, strlen(fetchline)))) , fp5 );
                if ( markup_item == 2 ) fputs( " (3 Pkt.)" , fp5 );
 	        fputs( "\n" , fp5 );
		itemlevel = 2;
	      }
	      else if ( itemlevel == 2)  
	      {
 	        fputs( "\\item " , fp5 );
 	        fputs(  strtxt2tex(strtrim( strcut( fetchline, 2+2, strlen(fetchline)))) , fp5 );
                if ( markup_item == 2 ) fputs( " (3 Pkt.)" , fp5 );
 	        fputs( "\n" , fp5 );
	        itemlevel = 2;
	      }
	      else if ( itemlevel == 3)  
	      {
 	        fputs( "\\end{itemize}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs(  strtxt2tex(strtrim( strcut( fetchline, 2+2, strlen(fetchline)))) , fp5 );
 	        fputs( "\n" , fp5 );
	        itemlevel = 2;
	      }
	      else if ( itemlevel == 0)  
	      {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strtxt2tex( strtrim( strcut( fetchline, 2+2, strlen(fetchline)))) , fp5 );
 	        fputs( "\n" , fp5 );
	        itemlevel = 2;
	      }
  	      foundcode = 1;
            }
	    // the most important: the item closer  (old item, but very stable)
            if ( foundcode == 0 )
	    if ( itemlevel >= 1 )
            if ( fetchline[0] != '\\' )
            if ( fetchline[0] != '!' )
            if ( fetchline[0] != '|' )
            {
	      for ( fooi = 1 ; fooi <= itemlevel ; fooi++)
	      {
	         fputs( "\\end{itemize}\n" , fp5 );
	      }
 	      fputs( "\n" , fp5 );
 	      fputs( "\n" , fp5 );
	      itemlevel = 0;
  	      foundcode = 1;
            }
         ///////////////////////////////////////
         ///////////////////////////////////////
         ///////////////////////////////////////
         ///////////////////////////////////////
         ///////////////////////////////////////



            ////////////////
            //// !latex here
            ////////////////
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' )
	    if ( strcmp( fetchcmdline, "!latex" ) == 0 )
            {
              fputs( "\\documentclass[11pt]{article}", fp5 );
              fputs( "\\usepackage{graphicx}", fp5 );
              fputs( "\\usepackage{epstopdf}", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            } 




            //////////////////////////////////
            //// !tex
            ////////////////
            //// !tex here
            ////////////////
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' )
	    if ( strcmp( fetchcmdline, "!tex" ) == 0 )
            {
              fputs( "\\documentclass[11pt]{article}", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            } 
            //// !begintex
           /*
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' )
	    if ( strcmp( fetchcmdline, "!begintex" ) == 0 )
            {
              fputs( "\\documentclass[11pt]{article}\n", fp5 );
              fputs( "\\begin{document}\n", fp5 );
  	      foundcode = 1;
            } 
           */







            /* removed
            /////////////////////////////
            // >> text, main
            // ![nu] text1 (with auto numbering)
            // ![nu] text2
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == '[' )
            if ( fetchline[2] == 'n' ) 
            if ( fetchline[3] == 'u' )
            if ( fetchline[4] == ']' )
            if ( fetchline[5] == ' ' )
	    {
	        if ( numberinglevel == 0) fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item[{\\bfseries " , fp5 );
                fooc = snprintf( fooccharo, 50 , "%d", mynumber );
 	        fputs( fooccharo , fp5 );
 	        fputs( ".}]{" , fp5 );
 	        fputs( strcut( fetchline, 5+2, strlen(fetchline)) , fp5 );
                fputs( "}" , fp5 );
 	        fputs( "\n" , fp5 );
                mynumber++;
		numberinglevel = 1;
  	        foundcode = 1;
            }
            */









            /*
            /////// FOR EXAMS
            ///////////////////////////// for questions with points
            /////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == '[' )
            if ( fetchline[2] == 'q' )
            if ( fetchline[3] == 't' )  // for question topics
            if ( fetchline[4] == ']' )
            if ( fetchline[5] == ' ' )
            {
              fputs( "\\iexflechelf{{\\bfseries ", fp5 );
 	      fputs( strtrim( strcut( fetchline, 5+2, strlen(fetchline))) , fp5 );
              fputs( "}}\\\\", fp5 );
 	      fputs( "\n" , fp5 );
  	      numberinglevel = 1;
  	      foundcode = 1;
            }
            */




            ///////////////////////////// for questions with points
            /////////////////////////////
            /*
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == '[' )
            if ( fetchline[2] == 'q' ) // used for english type of questions (single question list, with pts)
            if ( fetchline[3] == ']' )
            if ( fetchline[4] == ' ' )
            {
	      if ( numberinglevel == 1)  
	      {
 	        fputs( "\\item[{\\bfseries {\\arabic{unibullcounter}}}.)]{" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , fp5 );
                if ( markup_language == 1 )      fputs( " (3 Points)}" , fp5 );
                else if ( markup_language == 2 ) fputs( " (3 Pts.)}" , fp5 );
                else if ( markup_language == 3 ) fputs( " (3 Pkt.)}" , fp5 );
                else if ( markup_language == 0 ) fputs( "}" , fp5 );
 	        fputs( "\n" , fp5 );
                fputs( "\\addtocounter{unibullcounter}{1}\n" , fp5 );
		numberinglevel = 1;
	      }


	      else if ( numberinglevel == 0)  
	      {
 	        fputs( "\\begin{itemize}\n" , fp5 );

 	        fputs( "\\item[{\\bfseries {" , fp5 );
                fooc = snprintf( fooccharo, 50 , "%d", question_qucounter );
 	        fputs( fooccharo  , fp5 );
 	        fputs( "}}.)]{" , fp5 );
                question_qucounter++;

 	        //fputs( "\\item[{\\bfseries {\\arabic{unibullcounter}}}.)]{" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , fp5 );
                if ( markup_language == 1 )      fputs( " (3 Points)}" , fp5 );
                else if ( markup_language == 2 ) fputs( " (3 Pts.)}" , fp5 );
                else if ( markup_language == 3 ) fputs( " (3 Pkt.)}" , fp5 );
                else if ( markup_language == 0 ) fputs( "}" , fp5 );
 	        fputs( "\n" , fp5 );
                fputs( "\\addtocounter{unibullcounter}{1}\n" , fp5 );
		//numberinglevel = 1;
 	        fputs( "\\end{itemize}\n" , fp5 );
 	        fputs( "\\vspace{4cm}\n" , fp5 );
	      }
  	      foundcode = 1;
            }
            */

            





            /// FOR EXERCISES
            ///////////////////////////// 
            /// free numbering question
            /// for exr !! (example: ...)
            /// sometimes useful
            ///////////////////////////// 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == '[' )
            if ( fetchline[2] == 'e' )
            if ( fetchline[3] == ']' )
            if ( fetchline[4] == ' ' )
            {
	      if ( numberinglevel == 1)  
	      {
 	        fputs( "\\item[{\\bfseries {\\arabic{unibullcounter}}}.)]{" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , fp5 );
 	        fputs( "}\n" , fp5 );
                fputs( "\\addtocounter{unibullcounter}{1}\n" , fp5 );
		numberinglevel = 1;
	      }
	      else if ( numberinglevel == 0)  
	      {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item[{\\bfseries {\\arabic{unibullcounter}}}.)]{" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , fp5 );
 	        fputs( "}\n" , fp5 );
 	        fputs( "\n" , fp5 );
                fputs( "\\addtocounter{unibullcounter}{1}\n" , fp5 );
		numberinglevel = 1;
	      }
  	      foundcode = 1;
            }









            ///////////////////////////// 
            /// sometimes useful, with !qu 
            /// Just the regular 
            /// Simple, and relatively easy
            ///////////////////////////// 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'q' )
            if ( fetchline[2] == 'u' )
            if ( fetchline[3] == ' ' )
            if ( markup_output_format != 6 )
            if ( markup_output_format != 7 )
            {
	      if ( numberinglevel == 1)  
	      {
 	        fputs( "\\item[{\\bfseries {" , fp5 );
                fooc = snprintf( fooccharo, 50 , "%d", list_numbering );
 	        fputs( fooccharo  , fp5 );
 	        fputs( "}}.)]{" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 3+2, strlen(fetchline))) , fp5 );
 	        fputs( "}\n" , fp5 );
 	        fputs( "\n" , fp5 );
		numberinglevel = 1;
                list_numbering++;
	      }
	      else if ( numberinglevel == 0)  
	      {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item[{\\bfseries {" , fp5 );
                fooc = snprintf( fooccharo, 50 , "%d", list_numbering );
 	        fputs( fooccharo  , fp5 );
 	        fputs( "}}.)]{" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 3+2, strlen(fetchline))) , fp5 );
 	        fputs( "}\n" , fp5 );
 	        fputs( "\n" , fp5 );
		numberinglevel = 1;
                list_numbering++;
	      }
  	      foundcode = 1;
            }

            /////////////////////////////////
            if ( foundcode == 0 ) // !qt with pkt and space  // !qt
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'q' ) 
            if ( fetchline[2] == 't' )
            if ( fetchline[3] == ' ' )
            {
 	        fputs( "\\begin{itemize}\n" , fp5 );
 	        fputs( "\\item[{\\bfseries {" , fp5 );
                if ( markup_output_format == 10 ) 
                   fooc = snprintf( fooccharo, 50 , "%d", question_qucounter++ );
                else 
                   fooc = snprintf( fooccharo, 50 , "%d", list_numbering++ );
 	        fputs( fooccharo  , fp5 );
 	        fputs( "}}.)]{" , fp5 );
                //question_qucounter++;
                //list_numbering++;
 	        fputs( strtext2tex( strtrim( strcut( fetchline, 3+2, strlen(fetchline)))) , fp5 );
                if ( markup_output_format == 10 ) 
                   fputs( " (3 Pkt.)}" , fp5 );
                else 
                   fputs( "}" , fp5 );
 	        fputs( "\n" , fp5 );
 	        fputs( "\\end{itemize}\n" , fp5 );
                if ( markup_output_format == 10 ) 
 	           fputs( "\\vspace{4cm}\n" , fp5 );  // the trick is to have 4cm to give space for answers.
  	        foundcode = 1;
            }




            ////////////////////////////////////////////
            ////////////////////////////////////////////
            ////////////////////////////////////////////
            // format 7, maths area
            if ( foundcode == 0 )         // !qu  (main for maths)
            if ( beamercode == 0 ) 
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'q' )
            if ( fetchline[2] == 'u' )
            if ( fetchline[3] == ' ' )       // ! for maths with enumitems,... could be removed?
            if ( markup_output_format == 7 )
            {
	      if ( numberinglevel == 2)  
	      {
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 3+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
		numberinglevel = 2;
                list_numbering++;
	      }
	      else if ( numberinglevel == 1)  
	      {
 	        fputs( "\\begin{enumerate}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 3+2, strlen(fetchline))) , fp5 );
 	        fputs( "\n" , fp5 );
		numberinglevel = 2;
                list_numbering++;
	      }
  	      foundcode = 1;
            }





            ///////////////////////////////////////////////
            ///////////////////////////////////////////////
            if ( foundcode == 0 )   // !qu questions, for type !exam+ 
            if ( beamercode == 0 ) 
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'q' )
            if ( fetchline[2] == 'u' )
            if ( fetchline[3] == ' ' )
            if ( markup_output_format == 6 ) //for !exam+  // important area, exam+, to keep
            {
	      if ( numberinglevel == 2)  
	      {
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 3+2, strlen(fetchline))) , fp5 );
                if ( question_setpts == 1 )
                {
                  if      ( markup_language == 4 )    fputs( " (3 points)" , fp5 );
                  else if ( markup_language == 3 )    fputs( " (3 Pkt.)" , fp5 );
                  else if ( markup_language == 1 )    fputs( " (3 points)" , fp5 );
                  else fputs( " (3 Pkt.)" , fp5 );
                }
 	        fputs( "\n" , fp5 );
		numberinglevel = 2;
                list_numbering++;
	      }
	      else if ( numberinglevel == 1)  
	      {
 	        fputs( "\\begin{enumerate}\n" , fp5 );
 	        fputs( "\\item " , fp5 );
 	        fputs( strtrim( strcut( fetchline, 3+2, strlen(fetchline))) , fp5 );
                if ( question_setpts == 1 )
                {
                  if      ( markup_language == 4 )    fputs( " (3 points)" , fp5 );
                  else if ( markup_language == 1 )    fputs( " (3 points)" , fp5 );
                  else if ( markup_language == 3 )    fputs( " (3 Pkt.)" , fp5 );
                  else fputs( " (3 Pkt.)" , fp5 );
                }
 	        fputs( "\n" , fp5 );
		numberinglevel = 2;
                list_numbering++;
	      }
  	      foundcode = 1;
            }







            // please keep it
            if ( foundcode == 0 )
            if ( ( fetchline[0] == '!' ) || ( fetchline[0] == '\\' )  )
            if ( fetchline[1] == 'm' ) 
            if ( fetchline[2] == 'y' ) 
            if ( fetchline[3] == 's' ) 
            if ( fetchline[4] == 'e' ) 
            if ( fetchline[5] == 'c' ) 
            if ( fetchline[6] == 't' ) 
            if ( fetchline[7] == 'i' ) 
            if ( fetchline[8] == 'o' ) 
            if ( fetchline[9] == 'n' ) 
            if ( fetchline[10] == '{' ) 
            {
 	        fputs( "\%section272\n" , fp5 );
  	        fputs( "\\section{", fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	        fputs( "}\n", fp5 );
  	        foundcode = 1;
            }



            ////////////////////////////
            if ( foundcode == 0 )
            if ( beamercode == 1 )
            //if ( fetchcmdline[0] == '!' ) 
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 's' )
            if ( fetchline[2] == 'e' )
            if ( fetchline[3] == 'c' )
            if ( fetchline[4] == 't' )
            if ( fetchline[5] == 'i' )
            if ( fetchline[6] == 'o' )
            if ( fetchline[7] == 'n' )
            if ( fetchline[8] == ' ' )
            {  
 	      fputs( "\%section281\n" , fp5 );
 	      fputs( "\\section{" , fp5 );
 	      //fputs( strtrim( strcut( fetchcmdline, 8+2, strlen(fetchcmdline))) , fp5 );
 	      fputs( strtrim( strcut( fetchline, 8+2, strlen(fetchline))) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }



            /// new mysection
            // (why !, because it can be into the standard 250 chars)  
            if ( foundcode == 0 )
            //if ( fetchcmdline[0] == '!' ) 
	    //if ( strcmp( strcut(fetchcmdline, 2, 9) , "section " ) == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 's' )
            if ( fetchline[2] == 'e' )
            if ( fetchline[3] == 'c' )
            if ( fetchline[4] == 't' )
            if ( fetchline[5] == 'i' )
            if ( fetchline[6] == 'o' )
            if ( fetchline[7] == 'n' )
            if ( fetchline[8] == ' ' )
            {  
 	      fputs( "\%section260\n" , fp5 );
 	      fputs( "\\section{" , fp5 );
 	      //fputs( strtrim( strcut( fetchcmdline, 8+2, strlen(fetchcmdline))) , fp5 );
 	      fputs( strtrim( strcut( fetchline, 8+2, strlen(fetchline))) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }





            ///////////////////////////////
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' ) 
            if ( fetchcmdline[1] == '=' ) 
            if ( fetchcmdline[2] == ' ' ) 
            {
 	      //fputs( "\%section263\n" , fp5 );
 	      fputs( "\%new-section\n" , fp5 );
 	      fputs( "\\section{" , fp5 );
 	      fputs( strtrim( strcut( fetchcmdline, 2+2, strlen(fetchcmdline))) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }


            ///////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )   // !head for bold  and linelf
            if ( fetchline[1] == 'h' ) 
            if ( fetchline[2] == 'e' ) 
            if ( fetchline[3] == 'a' ) 
            if ( fetchline[4] == 'd' ) 
            if ( fetchline[5] == ' ' ) 
            {
 	      fputs( "{\\bfseries " , fp5 );
 	      fputs( strtrim( strcut( fetchline , 5+2, strlen(  fetchline ))) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\\\\", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }
            ///////////////////////////////




            ///////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )   // !sec 
            if ( fetchline[1] == 's' ) 
            if ( fetchline[2] == 'e' ) 
            if ( fetchline[3] == 'c' ) 
            if ( fetchline[4] == ' ' ) 
            {
 	      fputs( "\%seconlysec12\n" , fp5 );
 	      fputs( "\\section{" , fp5 );
 	      fputs( strtrim( strcut( fetchline , 4+2, strlen(  fetchline ))) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }
            ///////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )   // !ssec  for subsection 
            if ( fetchline[1] == 's' ) 
            if ( fetchline[2] == 's' ) 
            if ( fetchline[3] == 'e' ) 
            if ( fetchline[4] == 'c' ) 
            if ( fetchline[5] == ' ' ) 
            {
 	      fputs( "\%seconlysec15\n" , fp5 );
 	      fputs( "\\subsection{" , fp5 );
 	      fputs( strtrim( strcut( fetchline , 5+2, strlen(  fetchline ))) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }
            ///////////////////////////////
            ///////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )   // !sssec  for subsubsection 
            if ( fetchline[1] == 's' ) 
            if ( fetchline[2] == 's' ) 
            if ( fetchline[3] == 's' ) 
            if ( fetchline[4] == 'e' ) 
            if ( fetchline[5] == 'c' ) 
            if ( fetchline[6] == ' ' ) 
            {
 	      fputs( "\%seconlysec17\n" , fp5 );
 	      fputs( "\\subsubsection{" , fp5 );
 	      fputs( strtrim( strcut( fetchline , 6+2, strlen(  fetchline ))) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }
            ///////////////////////////////




            /////////////////////////////
            if ( foundcode == 0 )
	    if ( beamercode == 1 )
	    if ( contentcode == 1 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == '=' )
            if ( fetchline[2] == ' ' )
            {
              // this is for beamer here
 	      fputs( "\%section282\n" , fp5 );
 	      fputs( "\\section{" , fp5 );
 	      fputs( strtrim( strcut( fetchline, 2+2, strlen(fetchline))) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }


            ///////////////////////////////
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' ) 
            if ( fetchcmdline[1] == '=' ) 
            if ( fetchcmdline[2] == ' ' ) 
            {
              fputs( "\%mysectioncontent2\n" , fp5 );
 	      fputs( "\\section{" , fp5 );
 	      fputs( strtrim( strcut( fetchcmdline, 2+2, strlen(fetchcmdline))) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }



            ///////////////////////////////
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' ) 
	    if ( strcmp( strcut(fetchcmdline, 2, 9+3) , "!subsection " ) == 0 )
            {
 	      fputs( "\\subsection{" , fp5 );
 	      fputs( strtrim( strcut( fetchcmdline, 8+3+2, strlen(fetchcmdline))) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }

            ///////////////////////////////
            if ( foundcode == 0 )
            if ( ( fetchcmdline[0] == '!' ) || ( fetchcmdline[0] == '$' ))
	    if ( strcmp( strcut(fetchcmdline, 2, 5+3) , "subsec " ) == 0 )
            {
 	      fputs( "\\subsection{" , fp5 );
 	      fputs( strtrim( strcut( fetchcmdline, 4+3+2, strlen(fetchcmdline))) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }



	    /////////////////
            if ( foundcode == 0 )
            if ( ( fetchcmdline[0] == '!' ) || ( fetchcmdline[0] == '$' ))
	    if ( strcmp( strcut(fetchcmdline, 2, 9+3+3) , "!subsubsection " ) == 0 )
            {
 	      fputs( "\\subsubsection{" , fp5 );
 	      fputs( strtrim( strcut( fetchcmdline, 8+3+3+2, strlen(fetchcmdline))) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }


	    ////  function !chapter text / works always
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'c' )
            if ( fetchline[2] == 'h' )
            if ( fetchline[3] == 'a' )
            if ( fetchline[4] == 'p' )
            if ( fetchline[5] == 't' )
            if ( fetchline[6] == 'e' )
            if ( fetchline[7] == 'r' )
            if ( fetchline[8] == ' ' )
            {
 	      fputs( "\\chapter{" , fp5 );
 	      fputs( strtrim( strcut( fetchline, 8+2, strlen(fetchline))) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }



           
	    /////////////////
            if ( foundcode == 0 ) //    !- item into script
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == '-' )
            if ( fetchline[2] == ' ' )
            {
 	      fputs( "- " , fp5 );
 	      fputs( strcut( fetchline, 2+2, strlen(fetchline)) , fp5 );
  	      fputs( "\\\\", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }




            if ( foundcode == 0 ) // !it text
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'i' )
            if ( fetchline[2] == 't' )
            if ( fetchline[3] == ' ' )
            {
 	      fputs( "\\textit{" , fp5 );
 	      fputs( strcut( fetchline, 3+2, strlen(fetchline)) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }


	    /////////////////
	    /////////////////
	    /////////////////
            if ( foundcode == 0 ) // !italic thing
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'i' )
            if ( fetchline[2] == 't' )
            if ( fetchline[3] == 'a' )
            if ( fetchline[4] == 'l' )
            if ( fetchline[5] == 'i' )
            if ( fetchline[6] == 'i' )
            if ( fetchline[7] == 'c' )
            if ( fetchline[8] == ' ' )
            {
 	      fputs( "\\textit{" , fp5 );
 	      fputs( strcut( fetchline, 8+2, strlen(fetchline)) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }


	    /////////////////
	    /////////////////
	    /////////////////
            if ( foundcode == 0 ) // !normal to do normal thing
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'n' )
            if ( fetchline[2] == 'o' )
            if ( fetchline[3] == 'r' )
            if ( fetchline[4] == 'm' )
            if ( fetchline[5] == 'a' )
            if ( fetchline[6] == 'l' )
            if ( fetchline[7] == ' ' )
            {
 	      fputs( strcut( fetchline, 7+2, strlen(fetchline)) , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }



	    /////////////////
	    /////////////////
	    /////////////////
            if ( foundcode == 0 ) // !trim to do normal and trim line 
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 't' )
            if ( fetchline[2] == 'r' )
            if ( fetchline[3] == 'i' )
            if ( fetchline[4] == 'm' )
            if ( fetchline[5] == ' ' )
            {
 	      fputs(  strtrim( strcut( fetchline, 5+2, strlen(fetchline)) ) , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }

	    /////////////////
	    /////////////////
            if ( foundcode == 0 ) // !code to paste code, in dev
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'c' )
            if ( fetchline[2] == 'o' )
            if ( fetchline[3] == 'd' )
            if ( fetchline[4] == 'e' )
            if ( fetchline[5] == ' ' )
            {
 	      fputs(  strtrim( strcut( fetchline, 5+2, strlen(fetchline)) ) , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }

            if ( foundcode == 0 ) // !center 
            if ( fetchcmdline[0] == '!' )
            if ( fetchcmdline[1] == 'c' )
            if ( fetchcmdline[2] == 'e' )
            if ( fetchcmdline[3] == 'n' )
            if ( fetchcmdline[4] == 't' )
            if ( fetchcmdline[5] == 'e' )
            if ( fetchcmdline[6] == 'r' )
            if ( fetchcmdline[7] == ' ' )
            {
 	      fputs( "\\begin{center}" , fp5 );
 	      fputs( strcut( fetchcmdline, 7+2, strlen(fetchcmdline)) , fp5 );
 	      fputs( "\\end{center}" , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }







	   /////////////////
	   /////////////////
           if ( foundcode == 0 ) // !linux   for a linux command
           if ( fetchline[0] == '!' )
           if ( fetchline[1] == 'l' )
           if ( fetchline[2] == 'i' )
           if ( fetchline[3] == 'n' )
           if ( fetchline[4] == 'u' )
           if ( fetchline[5] == 'x' )
           if ( fetchline[6] == ' ' )
           {
              if ( MYOS == 1 ) 
              {
 	         fputs( " " , fp5 );
 	         fputs( strcut( fetchline, 6+2, strlen( fetchline )) , fp5 );
  	         fputs( " ", fp5 );
  	         fputs( "\n", fp5 );
              }
              else
              {
 	         printf( "> !linux command.\n"  );
 	         printf( "> OS: Non Linux\n" );
              }
  	      foundcode = 1;
           }





	    /////////////////
	    /////////////////
	    /////////////////
            if ( foundcode == 0 ) // !bold, without line feed of tex !
            if ( fetchcmdline[0] == '!' )
            if ( fetchcmdline[1] == 'b' )
            if ( fetchcmdline[2] == 'o' )
            if ( fetchcmdline[3] == 'l' )
            if ( fetchcmdline[4] == 'd' )
            if ( fetchcmdline[5] == ' ' )
            {
 	      fputs( "{\\bfseries " , fp5 );
 	      fputs( strcut( fetchcmdline, 5+2, strlen(fetchcmdline)) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }


            if ( foundcode == 0 ) // !italic  text  
            if ( fetchcmdline[0] == '!' )
            if ( fetchcmdline[1] == 'i' )
            if ( fetchcmdline[2] == 't' )
            if ( fetchcmdline[3] == 'a' )
            if ( fetchcmdline[4] == 'l' )
            if ( fetchcmdline[5] == 'i' )
            if ( fetchcmdline[6] == 'c' )
            if ( fetchcmdline[7] == ' ' )
            {
 	      fputs( "{\\it " , fp5 );
 	      fputs( strcut( fetchcmdline, 7+2, strlen(fetchcmdline)) , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }




	    /////////////////
	    /////////////////
	    /////////////////
            if ( foundcode == 0 ) // !blue
            if ( fetchcmdline[0] == '!' )
            if ( fetchcmdline[1] == 'b' )
            if ( fetchcmdline[2] == 'l' )
            if ( fetchcmdline[3] == 'u' )
            if ( fetchcmdline[4] == 'e' )
            if ( fetchcmdline[5] == ' ' )
            {
 	      //fputs( "{\\color{blue}" , fp5 );
 	      //fputs( strcut( fetchcmdline, 5+2, strlen(fetchcmdline)) , fp5 );
  	      //fputs( "}", fp5 );
  	      //fputs( "\n", fp5 );
	      if ( varset_colors == 1 ) 
	      {
 	        fputs( "{\\color{blue}" , fp5 );
 	        fputs( strcut( fetchcmdline, 5+2, strlen(fetchcmdline)) , fp5 );
  	        fputs( "}", fp5 );
	      }
	      else
 	        fputs( strcut( fetchcmdline, 5+2, strlen(fetchcmdline)) , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }




	    /////////////////
	    /////////////////
	    /////////////////
            if ( foundcode == 0 ) // !red
            if ( fetchcmdline[0] == '!' )
            if ( fetchcmdline[1] == 'r' )
            if ( fetchcmdline[2] == 'e' )
            if ( fetchcmdline[3] == 'd' )
            if ( fetchcmdline[4] == ' ' )
            {
 	      //fputs( "{\\color{red}" , fp5 );
 	      //fputs( strcut( fetchcmdline, 4+2, strlen(fetchcmdline)) , fp5 );
  	      //fputs( "}", fp5 );
  	      //fputs( "\n", fp5 );
	      if ( varset_colors == 1 ) 
	      {
 	        fputs( "{\\color{red}" , fp5 );
 	        fputs( strcut( fetchcmdline, 4+2, strlen(fetchcmdline)) , fp5 );
  	        fputs( "}", fp5 );
	      }
	      else
 	        fputs( strcut( fetchcmdline, 4+2, strlen(fetchcmdline)) , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }


	    /////////////////
	    /////////////////
	    /////////////////
            if ( foundcode == 0 ) // !green
            if ( fetchcmdline[0] == '!' )
            if ( fetchcmdline[1] == 'g' )
            if ( fetchcmdline[2] == 'r' )
            if ( fetchcmdline[3] == 'e' )
            if ( fetchcmdline[4] == 'e' )
            if ( fetchcmdline[5] == 'n' )
            if ( fetchcmdline[6] == ' ' )
            {
 	      //fputs( "{\\color{green}" , fp5 );
 	      //fputs( strcut( fetchcmdline, 6+2, strlen(fetchcmdline)) , fp5 );
  	      //fputs( "}", fp5 );
  	      //fputs( "\n", fp5 );
	      if ( varset_colors == 1 ) 
	      {
 	        fputs( "{\\color{green}" , fp5 );
 	        fputs( strcut( fetchcmdline, 6+2, strlen(fetchcmdline)) , fp5 );
  	        fputs( "}", fp5 );
	      }
	      else
 	        fputs( strcut( fetchcmdline, 6+2, strlen(fetchcmdline)) , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }


            /////////////////////////////////////////////////////////////////////////////////////
            // !nocolor is a new function to bring all black, useful for last steps of submission
            /////////////////////////////////////////////////////////////////////////////////////
            if ( foundcode == 0 )  // !nocolors 
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'n' )
            if ( fetchline[2] == 'o' )
            if ( fetchline[3] == 'c' )
            if ( fetchline[4] == 'o' )
            if ( fetchline[5] == 'l' )
            if ( fetchline[6] == 'o' )
            if ( fetchline[7] == 'r' )
	    {
  	      varset_colors = 0;
  	      foundcode = 1;
            }


            if ( foundcode == 0 ) // !pink    will be purple 
            if ( fetchcmdline[0] == '!' )
            if ( fetchcmdline[1] == 'p' )
            if ( fetchcmdline[2] == 'i' )
            if ( fetchcmdline[3] == 'n' )
            if ( fetchcmdline[4] == 'k' )
            if ( fetchcmdline[5] == ' ' )
            {
	      if ( varset_colors == 1 ) 
	      {
 	        fputs( "{\\color{purple}" , fp5 );
 	        fputs( strcut( fetchcmdline, 5+2, strlen(fetchcmdline)) , fp5 );
  	        fputs( "}", fp5 );
	      }
	      else
 	        fputs( strcut( fetchcmdline, 5+2, strlen(fetchcmdline)) , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }







	    /////////////////
	    /////////////////
	    /////////////////
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' )
            if ( fetchcmdline[1] == 'b' )
            if ( fetchcmdline[2] == 'c' )
            if ( fetchcmdline[3] == 'o' )
            if ( fetchcmdline[4] == 'd' )
            if ( fetchcmdline[5] == 'e' )
            {
 	      fputs( "\\begin{verbatim}\n" , fp5 );
  	      foundcode = 1;
            }
	    /////////////////
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' )
            if ( fetchcmdline[1] == 'e' )
            if ( fetchcmdline[2] == 'c' )
            if ( fetchcmdline[3] == 'o' )
            if ( fetchcmdline[4] == 'd' )
            if ( fetchcmdline[5] == 'e' )
            {
 	      fputs( "\\end{verbatim}\n" , fp5 );
  	      foundcode = 1;
            } 








	    /////////////////
	    /////////////////
	    /////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'c' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == 't' )
            if ( fetchline[4] == 'e' )
            if ( fetchline[5] == ' ' )
            {
 	        fputs( "\\cite{" , fp5 );
 	        fputs( strtrim( strcut( fetchline, 5+2, strlen( fetchline ))) , fp5 );
  	        fputs( "}\n", fp5 );
  	        foundcode = 1;
            } 
	    /////////////////
	    /////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 't' )
            if ( fetchline[2] == 'o' )
            if ( fetchline[3] == 'r' )
            {
                 fputs( "\\bibliography{endnote}{}\n", fp5 );
                 fputs( "\\bibliographystyle{ieeetr}\n", fp5 );
  	         foundcode = 1;
            } 
            //////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'b' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == 'b' )
            if ( fetchline[4] == 'l' )
            if ( fetchline[5] == 'i' )
            if ( fetchline[6] == 'o' )
            if ( fetchline[7] == 'g' )
            if ( fetchline[8] == 'r' )
            if ( fetchline[9] == 'a' )
            if ( fetchline[10] == 'p' )
            if ( fetchline[11] == 'h' )
            if ( fetchline[12] == 'y' )
            {
                 fputs( "\\bibliography{mybib}{}\n", fp5 );
                 fputs( "\\bibliographystyle{ieeetr}\n", fp5 );
  	         foundcode = 1;
            } 







            ////////////////
            ///////// new! for review !rev my-review
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'r' ) 
            if ( fetchline[2] == 'e' )
            if ( fetchline[3] == 'v' ) 
            if ( fetchline[4] == ' ' ) 
            {
       	         //fputs( "\\textcolor{blue}{" , fp5 );
        	 //fputs( "[", fp5 );
       	         //fputs( strcut( fetchline, 4+2, strlen(fetchline)) , fp5 );
        	 //fputs( "]", fp5 );
        	 //fputs( "}", fp5 );
        	 //fputs( "\n", fp5 );
	         if ( varset_colors == 1 ) 
	         {
 	           fputs( "{\\color{blue}[" , fp5 );
 	           fputs( strcut( fetchcmdline, 4+2, strlen(fetchcmdline)) , fp5 );
  	           fputs( "]}", fp5 );
	         }
	         else
 	           fputs( strcut( fetchcmdline, 4+2, strlen(fetchcmdline)) , fp5 );
  	         fputs( "\n", fp5 );
  	         foundcode = 1;
            }










	    /////////////////
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' )
            if ( fetchcmdline[1] == 'b' )
	    if ( strcmp( fetchcmdline, "!bverbatim" ) == 0 )
            {
 	      fputs( "\\begin{verbatim}" , fp5 );
  	      fputs( "\n", fp5 );
  	         foundcode = 1;
            }










	    /////////////////
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' )
            if ( fetchcmdline[1] == 'b' )
	    if ( strcmp( fetchcmdline, "!bverbatim" ) == 0 )
            {
 	      fputs( "\\begin{verbatim}" , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }
	    /////////////////
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' )
            if ( fetchcmdline[1] == 'e' )
	    if ( strcmp( fetchcmdline, "!everbatim" ) == 0 )
            {
 	      fputs( "\\end{verbatim}" , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }


	    /////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
	    if ( strcmp( fetchline, "!smallskip" ) == 0 )
            {
 	      fputs( "\\smallskip" , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }


	    /////////////////
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' )
	    if ( strcmp( fetchcmdline, "!bigskip" ) == 0 )
            {
 	      fputs( "\\bigskip" , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }




            //// !maketitle
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' ) 
	    if ( strcmp( fetchcmdline, "!maketitle" ) == 0 ) //here begin
            {
 	      fputs( "\\maketitle" , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }




            //// !clr
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' ) 
	    if ( strcmp( fetchcmdline, "!clr" ) == 0 ) //here begin
            {
 	      fputs( "\\clearpage" , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }

       



          /*
            //// ! clr ! Bigskip from converting
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' ) 
	    if ( strcmp( fetchcmdline, "! clr" ) == 0 ) //here begin
            {
 	      fputs( "\\clearpage" , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }
            //// ! clr ! Bigskip from converting
            if ( foundcode == 0 )
            if ( fetchcmdline[0] == '!' ) 
	    if ( strcmp( fetchcmdline, "! Bigskip" ) == 0 ) //here begin
            {
 	      fputs( "\\bigskip" , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }
         */








            ///////////////////////////
            if ( foundcode == 0 ) // !gartl{} for quick background
            if ( ( fetchline[0] ==  '!' ) && ( fetchline[1] == 'g' ) && ( fetchline[2] == 'a' )
	    && ( fetchline[3] == 'r' ) && ( fetchline[4] == 't' ) && ( fetchline[5] == 'l' ) 
	    && ( fetchline[6] == '{' ) )
            {
	      char fileinputsrc[PATH_MAX];
	      strncpy( fileinputsrc, "", PATH_MAX );
              strncat( fileinputsrc , strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX - strlen( fileinputsrc ) -1 );
	      if ( fileinputsrc[0] == '~' )
	      {
	         strncpy( fileinputsrc, "", PATH_MAX );
                 strncat( fileinputsrc , getenv( "HOME" ) , PATH_MAX - strlen( fileinputsrc ) -1 );
                 strncat( fileinputsrc , strdelimit( fetchline,  '~' ,'}' ,  1 ) , PATH_MAX - strlen( fileinputsrc ) -1 );
	      }
              if ( fileinputsrc[ strlen( fileinputsrc) -1 ] != '/' )
              {
                printf( "!gback: This is the location of item: %s\n" , fileinputsrc );
              }
              fputs( "\%path for graphics\n", fp5 );
              //fputs( "\\usebackgroundtemplate{\\includegraphics[width=\\paperwidth,height=\\paperheight]{", fp5 );
              //%\documentclass[journal,article,submit,moreauthors,pdftex]{
              fputs( "\\documentclass[journal,article,submit,moreauthors,pdftex]{" , fp5 );
  	      fputs( fileinputsrc  , fp5 );
  	      fputs( "}", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }


            ///////////////////////////
            ///////////////////////////
            ///////////////////////////
            //// this will create... 
            ////\usebackgroundtemplate{\includegraphics[width=\paperwidth,height=\paperheight]{$HOME/include/img/beamer.jpg}}
            ///////////////////////////
            if ( foundcode == 0 ) // !gback{} for quick background
            if ( ( fetchline[0] ==  '!' ) && ( fetchline[1] == 'g' ) && ( fetchline[2] == 'b' )
	    && ( fetchline[3] == 'a' ) && ( fetchline[4] == 'c' ) && ( fetchline[5] == 'k' ) 
	    && ( fetchline[6] == '{' ) )
            {
	      char fileinputsrc[PATH_MAX];
	      strncpy( fileinputsrc, "", PATH_MAX );
              strncat( fileinputsrc , strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX - strlen( fileinputsrc ) -1 );
	      if ( fileinputsrc[0] == '~' )
	      {
	         strncpy( fileinputsrc, "", PATH_MAX );
                 strncat( fileinputsrc , getenv( "HOME" ) , PATH_MAX - strlen( fileinputsrc ) -1 );
                 strncat( fileinputsrc , strdelimit( fetchline,  '~' ,'}' ,  1 ) , PATH_MAX - strlen( fileinputsrc ) -1 );
	      }
              if ( fileinputsrc[ strlen( fileinputsrc) -1 ] != '/' )
              {
                printf( "!gback: This is the location of item: %s\n" , fileinputsrc );
                //printf( "graphicspath: PC must add / for tailing\n" );
                //strncat( fileinputsrc , "/" , PATH_MAX - strlen( fileinputsrc ) -1 );
              }
              fputs( "\%path for graphics\n", fp5 );
              fputs( "\\usebackgroundtemplate{\\includegraphics[width=\\paperwidth,height=\\paperheight]{", fp5 );
              //include/img/beamer.jpg}}
	      //graphicspath{{", fp5 );
  	      fputs( fileinputsrc  , fp5 );
  	      fputs( "}}", fp5 );
  	      fputs( "\n", fp5 );
              //strncpy( mygraphicspath, fileinputsrc , PATH_MAX );
  	      foundcode = 1;
            }







            ///////////////////////////
            ///////////////////////////
            ///////////////////////////
            if ( foundcode == 0 ) // !gpath{}
            if ( ( fetchline[0] ==  '!' ) && ( fetchline[1] == 'g' ) && ( fetchline[2] == 'p' ) && ( fetchline[3] == 'a' ) && ( fetchline[4] == 't' ) && ( fetchline[5] == 'h' ) && ( fetchline[6] == '{' ) )
            {
	      char fileinputsrc[PATH_MAX];
	      strncpy( fileinputsrc, "", PATH_MAX );
              strncat( fileinputsrc , strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX - strlen( fileinputsrc ) -1 );
	      if ( fileinputsrc[0] == '~' )
	      {
	         strncpy( fileinputsrc, "", PATH_MAX );
                 strncat( fileinputsrc , getenv( "HOME" ) , PATH_MAX - strlen( fileinputsrc ) -1 );
                 strncat( fileinputsrc , strdelimit( fetchline,  '~' ,'}' ,  1 ) , PATH_MAX - strlen( fileinputsrc ) -1 );
	      }
                
              if ( fileinputsrc[ strlen( fileinputsrc) -1 ] != '/' )
              {
                printf( "graphicspath: PC must add / for tailing\n" );
                strncat( fileinputsrc , "/" , PATH_MAX - strlen( fileinputsrc ) -1 );
              }

              fputs( "\%path for graphics\n", fp5 );
              fputs( "\\graphicspath{{", fp5 );
  	      fputs( fileinputsrc  , fp5 );
  	      fputs( "}}", fp5 );
  	      fputs( "\n", fp5 );

              strncpy( mygraphicspath, fileinputsrc , PATH_MAX );
  	      foundcode = 1;
            }









            ///////////////////////////////////////////////
            ///////////////////////////////////////////////
            ///////////////////////////////////////////////
            /////// !gfxpath for OS Linux  only !!!
            ///////////////////////////////////////////////
            ///////////////////////////////////////////////
            if ( foundcode == 0 ) // !gfxpath{}
            if ( ( fetchline[0] ==  '!' ) && ( fetchline[1] == 'g' ) && ( fetchline[2] == 'f' ) && ( fetchline[3] == 'x' ) && ( fetchline[4] == 'p' ) && ( fetchline[5] == 'a' )  && ( fetchline[6] == 't' ) && ( fetchline[7] == 'h' )  && ( fetchline[8] == '{' ))
	    if ( MYOS == 1 )  
	    {
	      char fileinputsrc[PATH_MAX];
	      strncpy( fileinputsrc, "", PATH_MAX );
              strncat( fileinputsrc , strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX - strlen( fileinputsrc ) -1 );
	      if ( fileinputsrc[0] == '~' )
	      {
	         strncpy( fileinputsrc, "", PATH_MAX );
                 strncat( fileinputsrc , getenv( "HOME" ) , PATH_MAX - strlen( fileinputsrc ) -1 );
                 strncat( fileinputsrc , strdelimit( fetchline,  '~' ,'}' ,  1 ) , PATH_MAX - strlen( fileinputsrc ) -1 );
	      }
                
              if ( fileinputsrc[ strlen( fileinputsrc) -1 ] != '/' )
              {
                printf( "graphicspath: PC must add / for tailing\n" );
                strncat( fileinputsrc , "/" , PATH_MAX - strlen( fileinputsrc ) -1 );
              }
              fputs( "\%path for gfx graphics\n", fp5 );
              fputs( "\\graphicspath{{", fp5 );
  	      fputs( fileinputsrc  , fp5 );
  	      fputs( "}}", fp5 );
  	      fputs( "\n", fp5 );

              strncpy( mygraphicspath, fileinputsrc , PATH_MAX );
  	      foundcode = 1;
	    }



            /////////////////////////////////
            /////////////////////////////////
            // \usepackage{url}
            // \usepackage{hyperref}
            // \usepackage{graphicx}
            // \usepackage{grffile}
            //  xcolor ? for xfig fig2dev
            /////////////////////////////////
            /////////////////////////////////
            if ( foundcode == 0 )   // !gfx, improved
            if ( beamercode != 1 )
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'g' )
            if ( fetchline[2] == 'f' )
            if ( fetchline[3] == 'x' )
            {
 	      fputs( "\n" , fp5 );
 	      fputs( "\\usepackage{url}\n" , fp5 );
 	      fputs( "\\usepackage{hyperref}\n" , fp5 );
 	      fputs( "\\usepackage{grffile}\n" , fp5 );
 	      fputs( "\\usepackage{graphicx}\n" , fp5 );
 	      fputs( "\\usepackage{xcolor}\n" , fp5 );
 	      fputs( "\n" , fp5 );
  	      foundcode = 1;
            }





            ///////////// !mgpath{ath.png}  the minium gpath
            if ( foundcode == 0 ) // security mode
            if ( fetchline[0] == '!' ) 
            if ( fetchline[1] == 'm' )
            if ( fetchline[2] == 'g' )
            if ( fetchline[3] == 'p' )
            if ( fetchline[4] == 'a' )
            if ( fetchline[5] == 't' )
            if ( fetchline[6] == 'h' )
            if ( fetchline[7] == '{' )
            {
              fputs( "%%%%%% !gpath-(2)\n", fp5 );
              fputs( "\\graphicspath{{", fp5 );
 	      fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	      fputs( "}}", fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }








            ///////////////////////////
            ///////////////////////////
            ///////////////////////////
            ///////////////////////////
            if ( foundcode == 0 ) // !ipath{}
            if (( fetchline[0] ==  '!' ) && ( fetchline[1] == 'i' ) && ( fetchline[2] == 'p' ) && ( fetchline[3] == 'a' ) && ( fetchline[4] == 't' ) && ( fetchline[5] == 'h' ) && ( fetchline[6] == '{' ))

            { 
	      char fileinputsrc[PATH_MAX];
	      strncpy( fileinputsrc, "", PATH_MAX );
              strncat( fileinputsrc , strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX - strlen( fileinputsrc ) -1 );
	      if ( fileinputsrc[0] == '~' )
	      {
	         strncpy( fileinputsrc, "", PATH_MAX );
                 strncat( fileinputsrc , getenv( "HOME" ) , PATH_MAX - strlen( fileinputsrc ) -1 );
                 strncat( fileinputsrc , strdelimit( fetchline,  '~' ,'}' ,  1 ) , PATH_MAX - strlen( fileinputsrc ) -1 );
	      }
              if ( fileinputsrc[ strlen( fileinputsrc) -1 ] != '/' )
              {
                printf( "> path: PC must add / for tailing\n" );
                strncat( fileinputsrc , "/" , PATH_MAX - strlen( fileinputsrc ) -1 );
              }
              strncpy( myinputspath, fileinputsrc , PATH_MAX );
              printf( "> SET IPATH: %s\n", myinputspath );
  	      foundcode = 1;
            }
















        //////////////////////////////////////////////
	/// always working
        //////////////////////////////////////////////
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'm' )
            if ( fetchline[2] == 's' )
            if ( fetchline[3] == 'g' )
            if ( fetchline[4] == '{' )
            {
	      // !msg   
 	      strncpy( usertextfieldone, strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX );
 	      strncpy( usertextfieldtwo, strdelimit( fetchline,  '{' ,'}' ,  2 ) , PATH_MAX );
	      if ( strcmp( usertextfieldone, "" ) != 0 )
	      if ( strcmp( usertextfieldtwo, "0" ) != 0 )
	        printf( "<USER MSG: %s>\n", usertextfieldone );
  	      foundcode = 1;
            }







        //////////////////////////////////////////////
            if ( foundcode == 0 )
	    if ( option_system_call == 1 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'i' )
            if ( fetchline[2] == 'e' )
            if ( fetchline[3] == 'x' )
            if ( fetchline[4] == '{' )
            {
	      // !iex for texiex     (it will convert an iex to tex, and create its tex) 
 	      strncpy( usertextfieldone, strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX );
 	      strncpy( usertextfieldtwo, strdelimit( fetchline,  '{' ,'}' ,  2 ) , PATH_MAX );
	      if ( strcmp( usertextfieldone, "" ) != 0 )
	      if ( strcmp( usertextfieldtwo, "0" ) != 0 )
	      {
                 strncpy( wgetcmd, "",  PATH_MAX );
                 strncat( wgetcmd , " texiex  " , PATH_MAX - strlen( wgetcmd ) -1 );
                 strncat( wgetcmd ,  "  \""  , PATH_MAX - strlen( wgetcmd ) -1 );
                 strncat( wgetcmd ,  usertextfieldone  , PATH_MAX - strlen( wgetcmd ) -1 );
                 strncat( wgetcmd ,  "\""  , PATH_MAX - strlen( wgetcmd ) -1 );
   	         printf( " texiex : %s\n" , wgetcmd );
	         // secured or unsecured??
		    system( wgetcmd );
	      }
  	      foundcode = 1;
            }







        //////////////////////////////////////////////
            if ( foundcode == 0 )
	    if ( option_system_call == 1 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'c' )
            if ( fetchline[2] == 'm' )
            if ( fetchline[3] == 'd' )
            if ( fetchline[4] == '{' )
            {
              // magic to run cmd as well.
              foundcode = 1;
            }



        //////////////////////////////////////////////
            if ( foundcode == 0 )
	    if ( option_system_call == 1 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'w' )
            if ( fetchline[2] == 'g' )
            if ( fetchline[3] == 'e' )
            if ( fetchline[4] == 't' )
            if ( fetchline[5] == '{' )
            {
	      // !wget
 	      strncpy( usertextfieldone, strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX );
 	      strncpy( usertextfieldtwo, strdelimit( fetchline,  '{' ,'}' ,  2 ) , PATH_MAX );
	      if ( strcmp( usertextfieldone, "" ) != 0 )
	      if ( strcmp( usertextfieldtwo, "" ) != 0 )
	      if ( fexist( usertextfieldtwo ) == 0 )
	      {
                 strncpy( wgetcmd, "",  PATH_MAX );
                 strncat( wgetcmd , " wget " , PATH_MAX - strlen( wgetcmd ) -1 );
                 strncat( wgetcmd ,  "  \""  , PATH_MAX - strlen( wgetcmd ) -1 );
                 strncat( wgetcmd ,  usertextfieldone  , PATH_MAX - strlen( wgetcmd ) -1 );
                 strncat( wgetcmd ,  "\""  , PATH_MAX - strlen( wgetcmd ) -1 );
                 strncat( wgetcmd , " -O "  , PATH_MAX - strlen( wgetcmd ) -1 );
                 strncat( wgetcmd ,  "  \""  , PATH_MAX - strlen( wgetcmd ) -1 );
                 strncat( wgetcmd ,  usertextfieldtwo  , PATH_MAX - strlen( wgetcmd ) -1 );
                 strncat( wgetcmd ,  "\" "  , PATH_MAX - strlen( wgetcmd ) -1 );
   	         printf( " wgetcmd: %s\n" , wgetcmd );
	         // secured or unsecured??
   	            system( wgetcmd );
	      }
  	      foundcode = 1;
            }








            // !fin !fin 
	    if ( foundcode == 0 )
	    if ( foundcode == 0 )
	    {
	        if ( beginitemize == 1 )
		{
		  fputs( "\\iexitemend\n" , fp5 ); 
		  fputs( "\n" , fp5 ); 
		}

 	        fputs( fetchline , fp5 );

                if ( markup_output_format == 2 )
 	            fputs( "<br>" , fp5 );

  	        fputs( "\n", fp5 );
	        beginitemize = 0;
            }

	 }
     }
     fclose( fp5 );
     fclose( fp6 );
   }
}











void show_unimark_logo()
{
         printf("================= \n");
         printf("|||- UNIMARK -||| \n");
         printf("================= \n");
}







////////////////////////////////
/// check for enddoc 
////////////////////////////////
int cat_fdinfo_end( char *filein )
{
  char fetchlinetmp[4096];
  char fetchline[4096];
  char buf[4096];
  char ptr[4096];
  ssize_t nread;
  int i,j,k;
  i = 0 ; j = 0;
  int beginend = 0;
    FILE *fp6;
    fp6 = fopen( filein , "rb");
    while( !feof(fp6) ) 
    {
          fgets(fetchlinetmp, 4096, fp6); 
          strncpy( fetchline, "" , 4096 );
          for( i = 0 ; ( i <= strlen( fetchlinetmp ) ); i++ )
            if ( fetchlinetmp[ i ] != '\n' )
              fetchline[i]=fetchlinetmp[i];

         if ( !feof(fp6) )
         {
              if ( strcmp( fetchline , "!enddoc" ) == 0 )
                   beginend++;
              else if ( strcmp( fetchline , "\\end{document}" ) == 0 ) 
                   beginend++;
              else if ( strcmp( fetchline , "!EOF" ) == 0 )
                   beginend++;
	 }
     }
     fclose( fp6 );

  printf( "Info Begin+End: %d \n" , beginend );
  return beginend;
}

int cat_fdinfo_begin( char *filein )
{
  char fetchlinetmp[4096];
  char fetchline[4096];
  char buf[4096];
  char ptr[4096];
  ssize_t nread;
  int i,j,k;
  i = 0 ; j = 0;
  int beginend = 0;
    FILE *fp6;
    fp6 = fopen( filein , "rb");
    while( !feof(fp6) ) 
    {
          fgets(fetchlinetmp, 4096, fp6); 
          strncpy( fetchline, "" , 4096 );
          for( i = 0 ; ( i <= strlen( fetchlinetmp ) ); i++ )
            if ( fetchlinetmp[ i ] != '\n' )
              fetchline[i]=fetchlinetmp[i];

         if ( !feof(fp6) )
         {
              if ( strcmp( fetchline , "!begin" ) == 0 )
                   beginend++;
              else if ( strcmp( fetchline , "\\begin{document}" ) == 0 ) 
                   beginend++;
	 }
     }
     fclose( fp6 );

  printf( "Info Begin+End: %d \n" , beginend );
  return beginend;
}












//////////////////////////////
 void npdflatex( char *thefile ) 
 {
       char tfileout[PATH_MAX];
       strncpy( tfileout ,   fbasenoext( thefile ) , PATH_MAX );
       strncat( tfileout , ".tex" , PATH_MAX - strlen( tfileout ) -1 );
       /// there was few lines here... to mrk 
       nrunwith( " pdflatex -shell-escape ", tfileout );
       nrunwith( " pdflatex -shell-escape ", tfileout );
 }






//////////////////////////////
void makedoc_simple_doc( char *thefile )
{
      if ( fexist( thefile ) == 1 )
      {
              char mytargetfile[PATH_MAX];
              strncpy( mytargetfile, getenv( "HOME" ) , PATH_MAX );
              strncat( mytargetfile , "/" , PATH_MAX - strlen( mytargetfile ) - 1);
              strncat( mytargetfile , "doc.mrk" , PATH_MAX - strlen( mytargetfile ) - 1);
              ncp( mytargetfile , thefile );
	      system( " cd ; unibeam doc.mrk  ; pdflatex -shell-escape --interaction=nonstopmode      doc.tex ; pdflatex    -shell-escape --interaction=nonstopmode      doc.tex ;   mupdf doc.pdf   " );
     }
}





//////////////////////////////
//////////////////////////////
void makedoc_simple_pub( char *thefile )
{
      // this is a special method for pubs with embedded bib file.
      // !fopen{}  !fclose{}  
      char foocmd[PATH_MAX];
      if ( fexist( thefile ) == 1 )
      {
              char mytargetfile[PATH_MAX];
              strncpy( mytargetfile, getenv( "HOME" ) , PATH_MAX );
              strncat( mytargetfile , "/" , PATH_MAX - strlen( mytargetfile ) - 1);
              strncat( mytargetfile , "doc.mrk" , PATH_MAX - strlen( mytargetfile ) - 1);
              ncp( mytargetfile , thefile );
	      strncpy( foocmd,  " cd ; bsdfile doc.mrk  ;  bsdbib endnote.enk ; unibeam doc.mrk ; unibeam doc.mrk doc.dat  ; pdflatex -shell-escape --interaction=nonstopmode      doc ;                         bibtex doc ;    pdflatex    -shell-escape --interaction=nonstopmode      doc ; pdflatex    -shell-escape --interaction=nonstopmode         doc ;   mupdf doc.pdf   ", PATH_MAX  );
	      printf( "CMD: %s\n" , foocmd );
	      system( foocmd );
     }
}






////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
char envhome[PATH_MAX];
////////////////////////////////////////
int main( int argc, char *argv[])
{
    strncpy( envhome, getenv( "HOME" ), PATH_MAX );

    strncpy( strlabel, "", PATH_MAX );
    strncpy( lastsubsection, "", PATH_MAX );
    strncpy( cursubsection , "", PATH_MAX ); 
    char charo[PATH_MAX];



    ////////////////////////////////////////////////////////
    if  ( argc == 3 )
    if  ( strcmp(argv[1], "--lf" ) == 0 )
    if  ( strcmp(argv[2], "beamer" ) == 0 )
    {
       system( " cd  /usr/share/texlive/texmf-dist/tex/latex/beamer/ ; lfmmc "  );
       return 0;
    }


    ////////////////////////////////////////////////////////
    if ( argc >= 2)
    if ( ( strcmp(argv[1], "-color" ) == 0 ) ||  ( strcmp(argv[1], "--color" ) == 0 ) )
    {
          printf( " xcolor:  black  cyan      green      orange  violet blue   darkgray  lightgray  purple  white  brown  gray      magenta    red     yellow    \n" );
          return 0;
    }



    ////////////////////////////////////////////////////////
    if ( argc >= 2)
    if ( strcmp(argv[1], "-t" ) == 0 )
    {
            snprintf( charo, PATH_MAX , "%s%d",  "Time: ", (int)time(NULL));
	    printf( "%s\n", charo ); 
            return 0;
    }


    ////////////////////////////////////////////////////////
    if ( argc >= 2)
    if ( strcmp(argv[1], "--version" ) == 0 )
    {
	  printf( "OS version:      %d\n", MYOS );
	  if ( MYOS == 1 ) printf( "OS version: Linux \n" );
	  if ( MYOS == 4 ) printf( "OS version: BSD \n"   );
          return 0;
    }



    ////////////////////////////////////////////////////////
    if ( argc >= 2)
    if ( strcmp(argv[1], "--format" ) == 0)
    {
          printf( "-FORMAT-\n" );
          printf( "- format 10, 4 questions per page\n" );
          printf( "- format 12, 3 questions per page\n" );
          printf( "- format 14, 2 questions per page\n" );
          return 0;
    }




    ////////////////////////////////////////////////////////
    if ( argc == 3)
      if ( strcmp( argv[1] , "--install" ) ==  0 ) 
      if ( strcmp( argv[2] , "latex" ) ==  0 ) 
      {
	  system( " apt-get update " );
	  system( " apt-get install --no-install-recommends  -y  texlive   " );
	  system( " apt-get install --no-install-recommends  -y  texlive texlive-latex-extra texlive-font-utils " );
	  system( " apt-get install -y ghostscript " );
	  printf( " On Debian Texlive, there are likely improvements of sty for the directory beamer.\n" );
          return 0;
      }





    char targetfile[PATH_MAX];
    char cmdi[PATH_MAX];
    strncpy( slidemysection, "", PATH_MAX );
    strncpy( mygraphicspath, "" , PATH_MAX );
    strncpy( myinputspath , "" , PATH_MAX );
    FILE *fpout;
    int i ; 


    ////////////////////////////////////////////////////////
    if ( argc >= 2)
    if ( strcmp( argv[ 1 ] , "--doc"  ) == 0  ) 
    {
	  if ( fexist( argv[ 2 ] ) == 1 )
              makedoc_simple_doc( argv[ 2 ] );
          return 0;
    }

    ////////////////////////////////////////////////////////
    if ( argc >= 2)
    if ( strcmp( argv[ 1 ] , "--pub"  ) == 0  ) 
    {
	  if ( fexist( argv[ 2 ] ) == 1 )
              makedoc_simple_pub( argv[ 2 ] );
          return 0;
    }



    ////////////////////////////////////////////////////////
    /// rescue and debugging function
    ////////////////////////////////////////////////////////
    if ( argc == 3)
      if ( strcmp( argv[1] , "--cat" ) ==  0 ) 
      if ( fexist( argv[2] )  == 1 )
      {
         ncat_static( argv[ 2 ] );
         return 0;
      }




    char cwd[PATH_MAX];
    ////////////////////////////////////////////////////////
    if ( argc == 2)
    if ( ( strcmp( argv[1] , "--readme" ) ==  0 ) 
    || ( strcmp( argv[1] , "--help" ) ==  0 ) 
    || ( strcmp( argv[1] , "-help" ) ==  0 ) )
    {
        
	 show_unimark_logo();
         return 0;
    }










    /////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////
    printf("================= \n");
    printf("|||- MRK2TEX -||| \n");
    printf("================= \n");


    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
      if ( argc == 3)
      if ( strcmp( argv[1], "--auto" ) == 0 )
      if ( fexist( argv[2] ) == 1 )
      {
          strncpy( targetfile, fbasenoext( argv[ 2 ] ) , PATH_MAX );
          strncat( targetfile , ".tex" , PATH_MAX - strlen( targetfile ) -1 );
          printf( "Target: %s\n" , targetfile );

          int therebeginline = cat_fdinfo_begin( argv[ 2 ] );
          int therebeginend =  cat_fdinfo_end(   argv[ 2 ] );

          printf("  >SRC: %s => TRG: %s \n", argv[ 2 ] , targetfile  );

          if ( therebeginline == 0 ) 
               filenew_begin( targetfile );
          else
               filenew( targetfile );

          nfileunimark( targetfile , argv[2] );

          if ( markup_output_format == 1 ) 
          if ( therebeginend == 0 )  
          {
               printf( "File Append: End (TeX) \n" );
               fileappendend( targetfile );
          }
          printf( "-End of Unimark/Unibearm (OK).-\n" );
          printf( "===============================\n" );
          printf( "\n" );

          return 0;
      }



    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
      if ( argc == 4)
      if ( strcmp( argv[1] , "--pdf" ) == 0 )
      if ( fexist( argv[2] ) == 1 )
      {
          // 1: --pdf 
          // 2: source 
          // 3: target 
          printf( "Mode with --pdf, direct resulting tex: 1 => 2 (2 args).\n" );
          printf( "STEP:Catinfo \n" );
          int therebeginend = cat_fdinfo_end( argv[ 2 ] );
          printf( "STEP: info \n" );
          printf("  >SRC: %s => TRG: %s \n", argv[2] , argv[3] );
          printf( "STEP: filenew \n" );
          filenew( argv[3] );
          printf( "STEP: unimark \n" );
          nfileunimark( argv[3] , argv[2] );
          printf( "STEP: fileappend \n" );
          strncpy( targetfile,  argv[ 3 ]  , PATH_MAX );
          printf( "Target: %s\n" , targetfile );
          if ( markup_output_format == 1 ) 
            if ( therebeginend == 0 )  
            {
               printf( "File Append: End (TeX) \n" );
               fileappendend( targetfile );
            }
          printf( "-End of Unimark/Unibearm (OK).-\n" );
          printf( "===============================\n" );
          printf( "\n" );
          return 0;
      }





    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
      if ( argc == 3)
      if ( fexist( argv[1] ) == 1 )
      {
          // 1: source 
          // 2: target 
          printf( "Mode: 1 => 2 (2 args).\n" );
          printf( "STEP:Catinfo \n" );
          int therebeginend = cat_fdinfo_end( argv[ 1 ] );
          printf( "STEP: info \n" );
          printf("  >SRC: %s => TRG: %s \n", argv[1] , argv[2] );
          printf( "STEP: filenew \n" );
          filenew( argv[2] );
          printf( "STEP: unimark \n" );
          nfileunimark( argv[2] , argv[1] );
          printf( "STEP: fileappend \n" );
          strncpy( targetfile,  argv[ 2 ]  , PATH_MAX );
          printf( "Target: %s\n" , targetfile );

          if ( markup_output_format == 1 ) 
            if ( therebeginend == 0 )  
            {
               printf( "File Append: End (TeX) \n" );
               fileappendend( targetfile );
            }
          printf( "-End of Unimark/Unibearm (OK).-\n" );
          printf( "===============================\n" );
          printf( "\n" );
          return 0;
      }





    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////
    if ( argc == 2)
      if ( fexist( argv[1] ) == 1 )
      {
          // 1: source 
          // 2: target, created.
          printf( "Mode: 1 => create 1 (1 args).\n" );
          strncpy( targetfile, fbasenoext( argv[ 1 ] ) , PATH_MAX );
          strncat( targetfile , ".tex" , PATH_MAX - strlen( targetfile ) -1 );
          printf( "Target: %s\n" , targetfile );

          int therebeginend  = cat_fdinfo_end( argv[ 1 ] );

          printf("  >SRC: %s => TRG: %s \n", argv[1] , targetfile  );
          filenew( targetfile );
          nfileunimark( targetfile , argv[1] );

          /// append
          if ( markup_output_format == 1 ) 
          if ( therebeginend == 0 )  
          {
               printf( "File Append: End (TeX) \n" );
               fileappendend( targetfile );
          }

          printf( "-End of Unimark/Unibearm (OK).-\n" );
          printf( "===============================\n" );
          printf( "\n" );

          return 0;
      }



    if ( argc == 2)      printf( "Usage: unimark filein.mrk fileout.tex \n" );
    else if ( argc == 1) printf( "Usage: unimark filein.mrk fileout.tex \n" );

    return 0;

}





/// this is missing on linux devuan, but it works on NetBSD !
/*
Cite and beamer? Danger of usage of tex !

This is not working: 

x ii  texlive                                      2016.20170123-5                            all          TeX Live: A decent selection of the TeX Live packages
x ii  texlive-base                                 2016.20170123-5                            all          TeX Live: Essential programs and files
ii  texlive-bibtex-extra                         2016.20170123-5                            all          TeX Live: BibTeX additional styles
x ii  texlive-binaries                             2016.20160513.41080.dfsg-2+deb9u1          i386         Binaries for TeX Live
x ii  texlive-font-utils                           2016.20170123-5                            all          TeX Live: Graphics and font utilities
x ii  texlive-fonts-recommended                    2016.20170123-5                            all          TeX Live: Recommended fonts
x ii  texlive-latex-base                           2016.20170123-5                            all          TeX Live: LaTeX fundamental packages
x ii  texlive-latex-extra                          2016.20170123-5                            all          TeX Live: LaTeX additional packages
x ii  texlive-latex-recommended                    2016.20170123-5                            all          TeX Live: LaTeX recommended packages
x ii  texlive-pictures                             2016.20170123-5                            all          TeX Live: Graphics, pictures, diagrams
on Linux 4.9.0-6-686-pae #1 SMP Debian 4.9.88-1+deb9u1 (2018-05-07) i686 GNU/Linux
(refs non working !!)

it gives during compilation:
l.529 \end{frame}
                 
? ! Undefined control sequence.
\beamer@todo ... >0 \edef \inserttocsectionnumber 
                                                  {\the \beamer@tempcount }\...
l.529 \end{frame}
                 
? ! Undefined control sequence.
\beamer@todo ...mber {}\fi \def \inserttocsection 
                                                  {\hyperlink {Navigation20}...
l.529 \end{frame}
                 
? ! Undefined control sequence.
\beamer@todo ... >0 \edef \inserttocsectionnumber 
                                                  {\the \beamer@tempcount }\...
l.529 \end{frame}
                 
? ! Undefined control sequence.
\beamer@todo ...mber {}\fi \def \inserttocsection 
                                                  {\hyperlink {Navigation20}...
l.529 \end{frame}



//id-20200204-213424
  Investigate with :
  /usr/share/texlive $ find -iname "*" | while read -r i ; do cat "$i" | grep inserttocsectionnumber     ; done  

it shall have:
$ less /usr/share/texlive/texmf-dist/tex/latex/beamer/beamerbasesection.sty
  inserttocsectionnumber !!
*/




/*
THIS IS WORKING - because it is now ok and fixed
on Linux raspberrypi 4.19.75-v7+ #1270 SMP Tue Sep 24 18:45:11 BST 2019 armv7l GNU/Linux
deb http://raspbian.raspberrypi.org/raspbian/ buster main contrib non-free rpi

ii  texlive                              2018.20190227-2                 all          TeX Live: A decent selection of the TeX Live packages
ii  texlive-base                         2018.20190227-2                 all          TeX Live: Essential programs and files
ii  texlive-binaries                     2018.20181218.49446-1           armhf        Binaries for TeX Live
ii  texlive-font-utils                   2018.20190227-2                 all          TeX Live: Graphics and font utilities
ii  texlive-fonts-recommended            2018.20190227-2                 all          TeX Live: Recommended fonts
ii  texlive-latex-base                   2018.20190227-2                 all          TeX Live: LaTeX fundamental packages
ii  texlive-latex-extra                  2018.20190227-2                 all          TeX Live: LaTeX additional packages
ii  texlive-latex-recommended            2018.20190227-2                 all          TeX Live: LaTeX recommended packages
ii  texlive-pictures                     2018.20190227-2                 all          TeX Live: Graphics, pictures, diagrams

*/

